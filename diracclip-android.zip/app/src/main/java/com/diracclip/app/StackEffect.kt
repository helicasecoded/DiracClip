package com.diracclip.app

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/**
 * Shows two regions of the source frame stacked vertically in a 1080x1920 output.
 * src0 / src1 = (x, y, w, h) normalised, origin top-left. split = fraction (from top) where panel 0 ends.
 */
class StackEffect(
    private val src0: FloatArray,
    private val src1: FloatArray,
    private val split: Float
) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram {
        return StackProgram(useHdr, src0, src1, split)
    }
}

class StackProgram(
    useHdr: Boolean,
    private val src0: FloatArray,
    private val src1: FloatArray,
    private val split: Float
) : BaseGlShaderProgram(useHdr, 1) {

    private val program: GlProgram = GlProgram(VERTEX, FRAGMENT)

    init {
        program.setBufferAttribute(
            "aFramePosition",
            GlUtil.getNormalizedCoordinateBounds(),
            GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
        )
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        return Size(1080, 1920)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        program.use()
        program.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
        program.setFloatsUniform("uSrc0", src0)
        program.setFloatsUniform("uSrc1", src1)
        program.setFloatUniform("uSplit", split)
        program.bindAttributesAndUniforms()
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GlUtil.checkGlError()
    }

    override fun release() {
        super.release()
        program.delete()
    }

    companion object {
        private const val VERTEX = """
attribute vec4 aFramePosition;
varying vec2 vTexSamplingCoord;
void main() {
  gl_Position = aFramePosition;
  vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
}
"""
        private const val FRAGMENT = """
precision mediump float;
uniform sampler2D uTexSampler;
uniform vec4 uSrc0;
uniform vec4 uSrc1;
uniform float uSplit;
varying vec2 vTexSamplingCoord;
void main() {
  vec2 uv = vTexSamplingCoord;
  float fromTop = 1.0 - uv.y;
  vec4 r;
  float local;
  if (fromTop < uSplit) {
    r = uSrc0;
    local = fromTop / uSplit;
  } else {
    r = uSrc1;
    local = (fromTop - uSplit) / (1.0 - uSplit);
  }
  float sx = r.x + uv.x * r.z;
  float sy = r.y + local * r.w;
  gl_FragColor = texture2D(uTexSampler, vec2(sx, 1.0 - sy));
}
"""
    }
}
