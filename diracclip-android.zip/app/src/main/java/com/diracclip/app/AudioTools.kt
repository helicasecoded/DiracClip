package com.diracclip.app

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

object AudioTools {
    /** Decodes audio to 16 kHz mono WAV. Returns loudness (RMS) per 20 ms. */
    fun extractWav(ctx: Context, src: Uri, out: File, durationSec: Double, log: (String) -> Unit): FloatArray {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, src, null)
        var track = -1
        for (i in 0 until ex.trackCount) {
            val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
            if (m.startsWith("audio/")) {
                track = i
                break
            }
        }
        if (track < 0) {
            ex.release()
            throw ApiException("This video has no audio track.")
        }
        ex.selectTrack(track)
        val fmt = ex.getTrackFormat(track)
        val mime = fmt.getString(MediaFormat.KEY_MIME)!!
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()

        var srcRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = maxOf(1, fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
        var isFloat = false
        val outRate = 16000
        val raf = RandomAccessFile(out, "rw")
        raf.setLength(0)
        raf.write(ByteArray(44))
        val outBuf = ByteBuffer.allocate(64 * 1024).order(ByteOrder.LITTLE_ENDIAN)
        var dataLen = 0L
        var pos = 1.0
        var prev = 0f
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        var lastPct = -25

        var eBuf = FloatArray(1 shl 16)
        var eN = 0
        var sumSq = 0.0
        var eCount = 0

        try {
            while (!outputDone) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val ib = codec.getInputBuffer(ii)!!
                        val n = ex.readSampleData(ib, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10000)
                if (oi >= 0) {
                    if (info.size > 0) {
                        val ob = codec.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        ob.order(ByteOrder.LITTLE_ENDIAN)
                        val frames: Int
                        val mono: FloatArray
                        if (isFloat) {
                            val fb = ob.asFloatBuffer()
                            frames = fb.remaining() / channels
                            mono = FloatArray(frames)
                            for (f in 0 until frames) {
                                var sum = 0f
                                for (c in 0 until channels) sum += fb.get() * 32768f
                                mono[f] = sum / channels
                            }
                        } else {
                            val sb = ob.asShortBuffer()
                            frames = sb.remaining() / channels
                            mono = FloatArray(frames)
                            for (f in 0 until frames) {
                                var sum = 0f
                                for (c in 0 until channels) sum += sb.get().toFloat()
                                mono[f] = sum / channels
                            }
                        }
                        val e = FloatArray(frames + 1)
                        e[0] = prev
                        System.arraycopy(mono, 0, e, 1, frames)
                        val step = srcRate.toDouble() / outRate
                        while (pos <= frames.toDouble()) {
                            val i0 = pos.toInt()
                            val frac = (pos - i0).toFloat()
                            val a = e[i0]
                            val b = if (i0 + 1 <= frames) e[i0 + 1] else a
                            var v = a + (b - a) * frac
                            if (v > 32767f) v = 32767f
                            if (v < -32768f) v = -32768f
                            if (outBuf.remaining() < 2) {
                                raf.write(outBuf.array(), 0, outBuf.position())
                                dataLen += outBuf.position()
                                outBuf.clear()
                            }
                            outBuf.putShort(v.toInt().toShort())
                            sumSq += (v * v).toDouble()
                            eCount++
                            if (eCount == 320) {
                                if (eN == eBuf.size) eBuf = eBuf.copyOf(eN * 2)
                                eBuf[eN++] = Math.sqrt(sumSq / 320.0).toFloat()
                                sumSq = 0.0
                                eCount = 0
                            }
                            pos += step
                        }
                        pos -= frames.toDouble()
                        if (frames > 0) prev = e[frames]
                        if (durationSec > 0) {
                            val pct = ((info.presentationTimeUs / 1_000_000.0) / durationSec * 100).toInt()
                            if (pct >= lastPct + 25) {
                                lastPct = pct
                                log("Audio $pct%")
                            }
                        }
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    srcRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = maxOf(1, of.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
                    isFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                }
            }
            if (outBuf.position() > 0) {
                raf.write(outBuf.array(), 0, outBuf.position())
                dataLen += outBuf.position()
            }
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray())
            h.putInt((36 + dataLen).toInt())
            h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray())
            h.putInt(16)
            h.putShort(1)
            h.putShort(1)
            h.putInt(outRate)
            h.putInt(outRate * 2)
            h.putShort(2)
            h.putShort(16)
            h.put("data".toByteArray())
            h.putInt(dataLen.toInt())
            raf.seek(0)
            raf.write(h.array())
        } finally {
            try {
                codec.stop()
            } catch (e: Exception) {
            }
            codec.release()
            ex.release()
            raf.close()
        }
        return eBuf.copyOf(eN)
    }
}
