package com.diracclip.app

object Beats {
    class Result(val bpm: Double, val beats: List<Double>)

    /** Finds tempo and beat grid from a loudness map (20 ms per value). */
    fun analyze(energy: FloatArray): Result? {
        val hop = Planner.HOP
        val n = energy.size
        if (n < 500) return null
        val onset = FloatArray(n)
        var prev = Math.log(1.0 + energy[0]).toFloat()
        for (i in 1 until n) {
            val x = Math.log(1.0 + energy[i]).toFloat()
            onset[i] = maxOf(0f, x - prev)
            prev = x
        }
        val sm = FloatArray(n)
        for (i in 1 until n - 1) sm[i] = (onset[i - 1] + 2f * onset[i] + onset[i + 1]) / 4f

        val limitT = minOf(n * hop, 120.0)
        var bestScore = -1.0
        var bestP = 0.5
        var bestPh = 0.0
        var p = 0.34
        while (p <= 0.86) {
            val bpm = 60.0 / p
            val w = if (bpm in 85.0..160.0) 1.0 else 0.85
            var ph = 0.0
            while (ph < p) {
                var s = 0.0
                var k = 0
                var t = ph
                while (t < limitT - 0.1) {
                    val idx = (t / hop).toInt()
                    if (idx in sm.indices) s += sm[idx]
                    k++
                    t += p
                }
                if (k > 0) {
                    val sc = s / k * w
                    if (sc > bestScore) {
                        bestScore = sc
                        bestP = p
                        bestPh = ph
                    }
                }
                ph += hop
            }
            p += 0.0005
        }
        if (bestScore <= 0.0) return null
        val beats = ArrayList<Double>()
        var t = bestPh
        val total = n * hop
        while (t < total) {
            beats.add(t)
            t += bestP
        }
        return Result(60.0 / bestP, beats)
    }

    /** Start time (a beat) of the most energetic stretch of the song that is clipDur long. */
    fun bestStart(res: Result, energy: FloatArray, clipDur: Double): Double {
        val hop = Planner.HOP
        val musicDur = energy.size * hop
        if (res.beats.isEmpty()) return 0.0
        if (clipDur >= musicDur - 1.0) return res.beats[0]
        val pre = DoubleArray(energy.size + 1)
        for (i in energy.indices) pre[i + 1] = pre[i] + energy[i]
        var best = res.beats[0]
        var bestAvg = -1.0
        for ((idx, b) in res.beats.withIndex()) {
            if (idx % 4 != 0) continue
            if (b + clipDur > musicDur) break
            val i0 = (b / hop).toInt()
            val i1 = minOf(energy.size, ((b + clipDur) / hop).toInt())
            if (i1 <= i0) continue
            val avg = (pre[i1] - pre[i0]) / (i1 - i0)
            if (avg > bestAvg) {
                bestAvg = avg
                best = b
            }
        }
        return best
    }

    /** Nudges the cut points between pieces so they land on beats (beatsRel = beat times from clip start). */
    fun syncCuts(pieces: List<Piece>, beatsRel: List<Double>, videoDur: Double): List<Piece> {
        if (beatsRel.isEmpty() || pieces.size < 2) return pieces
        val out = pieces.toMutableList()
        var t = 0.0
        for (j in out.indices) {
            var p = out[j]
            var end = t + Planner.outDuration(p)
            if (j < out.size - 1 && p.speed == 1.0) {
                var tgt = -1.0
                var bestD = 1e9
                for (b in beatsRel) {
                    val d = Math.abs(b - end)
                    if (d < bestD) {
                        bestD = d
                        tgt = b
                    }
                }
                if (tgt >= 0 && bestD <= 0.35) {
                    val newEnd = p.end + (tgt - end)
                    val nextStart = out[j + 1].start
                    if (newEnd - p.start >= 0.8 && newEnd <= nextStart - 0.02 && newEnd <= videoDur) {
                        p = Piece(p.start, newEnd, p.speaker, p.speed)
                        out[j] = p
                        end = tgt
                    }
                }
            }
            t = end
        }
        return out
    }
}
