package com.diracclip.app

object Json {
    /** Pulls the JSON object out of a model reply (removes <think> blocks, fences and extra prose). */
    fun extract(raw: String): String {
        var t = raw.trim()
        t = t.replace(Regex("(?s)<think>.*?</think>"), "").trim()
        if (t.startsWith("```")) {
            t = t.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        }
        val a = t.indexOf('{')
        val b = t.lastIndexOf('}')
        return if (a >= 0 && b > a) t.substring(a, b + 1) else t
    }
}
