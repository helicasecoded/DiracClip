package com.diracclip.app

enum class Provider(val label: String, val base: String) {
    GEMINI("Gemini", ""),
    XAI("xAI Grok", "https://api.x.ai/v1"),
    GROQ("Groq", "https://api.groq.com/openai/v1"),
    OPENROUTER("OpenRouter", "https://openrouter.ai/api/v1"),
    OPENAI("OpenAI", "https://api.openai.com/v1"),
    CEREBRAS("Cerebras", "https://api.cerebras.ai/v1")
}

data class KeyInfo(val provider: Provider, val key: String)

object Keys {
    fun detect(k: String): Provider? = when {
        k.startsWith("AIza") || k.startsWith("AQ.") -> Provider.GEMINI
        k.startsWith("xai-") -> Provider.XAI
        k.startsWith("gsk_") -> Provider.GROQ
        k.startsWith("sk-or-") -> Provider.OPENROUTER
        k.startsWith("csk-") -> Provider.CEREBRAS
        k.startsWith("sk-ant-") -> null
        k.startsWith("sk-") -> Provider.OPENAI
        else -> null
    }

    /** Returns (recognised keys, ignored tokens). Keys may be separated by new lines, spaces or commas. */
    fun parse(text: String): Pair<List<KeyInfo>, List<String>> {
        val ok = ArrayList<KeyInfo>()
        val bad = ArrayList<String>()
        for (tok in text.split(Regex("[\\s,;]+"))) {
            val k = tok.trim()
            if (k.length < 12) continue
            val p = detect(k)
            if (p != null) {
                if (ok.none { it.key == k }) ok.add(KeyInfo(p, k))
            } else {
                bad.add(k.take(6) + "...")
            }
        }
        return Pair(ok, bad)
    }

    fun summary(keys: List<KeyInfo>): String {
        if (keys.isEmpty()) return "No valid key detected yet."
        return keys.groupBy { it.provider }.entries.joinToString("  |  ") { "${it.key.label} x${it.value.size}" }
    }
}
