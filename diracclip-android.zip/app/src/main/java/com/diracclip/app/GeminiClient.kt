package com.diracclip.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class ApiException(message: String) : Exception(message)

object GeminiClient {
    private const val BASE = "https://generativelanguage.googleapis.com"

    private fun readBody(c: HttpURLConnection): String {
        val stream = try {
            if (c.responseCode in 200..299) c.inputStream else c.errorStream
        } catch (e: Exception) {
            c.errorStream
        }
        return stream?.bufferedReader()?.use { it.readText() } ?: ""
    }

    /** Uploads a file via the Gemini File API. Returns Pair(fileName, fileUri). */
    fun uploadFile(apiKey: String, file: File, mime: String, log: (String) -> Unit): Pair<String, String> {
        val size = file.length()

        val start = URL("$BASE/upload/v1beta/files").openConnection() as HttpURLConnection
        start.requestMethod = "POST"
        start.doOutput = true
        start.connectTimeout = 30000
        start.readTimeout = 60000
        start.setRequestProperty("x-goog-api-key", apiKey)
        start.setRequestProperty("X-Goog-Upload-Protocol", "resumable")
        start.setRequestProperty("X-Goog-Upload-Command", "start")
        start.setRequestProperty("X-Goog-Upload-Header-Content-Length", size.toString())
        start.setRequestProperty("X-Goog-Upload-Header-Content-Type", mime)
        start.setRequestProperty("Content-Type", "application/json")
        start.outputStream.use { it.write("""{"file":{"display_name":"diracclip_audio"}}""".toByteArray()) }
        if (start.responseCode !in 200..299) {
            throw ApiException("Upload start failed (${start.responseCode}): ${readBody(start).take(500)}")
        }
        val uploadUrl = start.getHeaderField("X-Goog-Upload-URL")
            ?: throw ApiException("Upload URL missing in response")
        start.disconnect()

        log("Audio upload ho raha hai (${size / 1024 / 1024} MB)...")
        val up = URL(uploadUrl).openConnection() as HttpURLConnection
        up.requestMethod = "POST"
        up.doOutput = true
        up.connectTimeout = 30000
        up.readTimeout = 600000
        up.setFixedLengthStreamingMode(size)
        up.setRequestProperty("X-Goog-Upload-Offset", "0")
        up.setRequestProperty("X-Goog-Upload-Command", "upload, finalize")
        file.inputStream().use { input ->
            up.outputStream.use { output -> input.copyTo(output, 64 * 1024) }
        }
        val upBody = readBody(up)
        if (up.responseCode !in 200..299) {
            throw ApiException("Upload failed (${up.responseCode}): ${upBody.take(500)}")
        }
        up.disconnect()

        val fileJson = JSONObject(upBody).getJSONObject("file")
        val name = fileJson.getString("name")
        val uri = fileJson.getString("uri")
        var state = fileJson.optString("state", "ACTIVE")

        var tries = 0
        while (state == "PROCESSING" && tries < 90) {
            Thread.sleep(4000)
            val g = URL("$BASE/v1beta/$name").openConnection() as HttpURLConnection
            g.setRequestProperty("x-goog-api-key", apiKey)
            g.connectTimeout = 30000
            g.readTimeout = 60000
            val body = readBody(g)
            if (g.responseCode in 200..299) {
                state = JSONObject(body).optString("state", "ACTIVE")
            }
            g.disconnect()
            tries++
        }
        if (state != "ACTIVE") throw ApiException("Gemini file state: $state")
        return Pair(name, uri)
    }

    /** Calls generateContent with the uploaded audio and a text prompt. Returns the raw text. */
    fun generate(apiKey: String, model: String, fileUri: String, mime: String, prompt: String, log: (String) -> Unit): String {
        val body = JSONObject()
        val parts = JSONArray()
        parts.put(JSONObject().put("file_data", JSONObject().put("mime_type", mime).put("file_uri", fileUri)))
        parts.put(JSONObject().put("text", prompt))
        body.put("contents", JSONArray().put(JSONObject().put("parts", parts)))
        body.put(
            "generationConfig",
            JSONObject().put("responseMimeType", "application/json").put("temperature", 0.3)
        )

        var attempt = 0
        while (true) {
            attempt++
            val c = URL("$BASE/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 30000
            c.readTimeout = 900000
            c.setRequestProperty("x-goog-api-key", apiKey)
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val text = readBody(c)
            c.disconnect()
            if (code in 200..299) {
                val cands = JSONObject(text).optJSONArray("candidates")
                    ?: throw ApiException("Gemini ne koi jawab nahi diya: ${text.take(400)}")
                val partsOut = cands.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                val sb = StringBuilder()
                for (i in 0 until partsOut.length()) sb.append(partsOut.getJSONObject(i).optString("text", ""))
                return sb.toString()
            }
            if ((code == 429 || code == 503 || code == 500) && attempt < 4) {
                log("Gemini busy/limit ($code). 30 second ruk ke dobara try...")
                Thread.sleep(30000)
                continue
            }
            val hint = if (code == 429) " (Free limit lag gayi. Thodi der baad ya kal try karo, ya paid karo.)" else ""
            throw ApiException("Gemini error $code$hint: ${text.take(500)}")
        }
    }

    fun buildPrompt(count: Int, minSec: Int, maxSec: Int, withCaptions: Boolean): String {
        val capRule = if (withCaptions)
            "Har clip ke liye 'captions' do: speech ka sahi transcription, chhoti lines (max 6 words), start/end seconds clip ke start se relative (0 se shuru)."
        else
            "'captions' ko khali list [] rakho."
        return """
You are an expert short-form video editor. Listen to the whole audio.
Pick the $count best self-contained highlight moments for TikTok/Reels/Shorts.
Each clip must be between $minSec and $maxSec seconds long, start at a natural sentence start and end at a natural sentence end, and have a strong hook.
Clips must not overlap. Timestamps are in seconds from the start of the audio and must be accurate.
$capRule
Transcribe in the original spoken language and script (do not translate).
Return ONLY valid JSON in exactly this shape:
{"clips":[{"start":12.5,"end":58.0,"title":"short catchy title","captions":[{"start":0.0,"end":2.4,"text":"caption text"}]}]}
""".trimIndent()
    }

    fun parsePlans(raw: String, durationSec: Double, minSec: Int): List<ClipPlan> {
        var t = raw.trim()
        if (t.startsWith("```")) {
            t = t.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        }
        val clips = JSONObject(t).getJSONArray("clips")
        val out = ArrayList<ClipPlan>()
        for (i in 0 until clips.length()) {
            val o = clips.getJSONObject(i)
            var s = o.getDouble("start")
            var e = o.getDouble("end")
            if (s < 0) s = 0.0
            if (e > durationSec) e = durationSec
            if (e - s < minOf(minSec.toDouble(), 5.0)) continue
            val caps = ArrayList<Cap>()
            val ca = o.optJSONArray("captions")
            if (ca != null) {
                for (j in 0 until ca.length()) {
                    val c = ca.getJSONObject(j)
                    caps.add(Cap(c.optDouble("start", 0.0), c.optDouble("end", 0.0), c.optString("text", "")))
                }
            }
            out.add(ClipPlan(s, e, o.optString("title", "Clip ${i + 1}"), caps))
        }
        return out
    }
}
