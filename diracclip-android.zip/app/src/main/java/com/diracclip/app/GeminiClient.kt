package com.diracclip.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class ApiException(message: String) : Exception(message)

object GeminiClient {
    private const val BASE = "https://generativelanguage.googleapis.com"

    private fun readBody(c: HttpURLConnection): String {
        val stream = try {
            if (c.responseCode in 200..299) c.inputStream else c.errorStream
        } catch (e: Exception) {
            c.errorStream
        }
        return stream?.bufferedReader()?.use { it.readText() } ?: ""
    }

    /** Uploads a file via the Gemini File API. Returns Pair(fileName, fileUri). */
    fun uploadFile(apiKey: String, file: File, mime: String, log: (String) -> Unit): Pair<String, String> {
        val size = file.length()

        val start = URL("$BASE/upload/v1beta/files").openConnection() as HttpURLConnection
        start.requestMethod = "POST"
        start.doOutput = true
        start.connectTimeout = 30000
        start.readTimeout = 60000
        start.setRequestProperty("x-goog-api-key", apiKey)
        start.setRequestProperty("X-Goog-Upload-Protocol", "resumable")
        start.setRequestProperty("X-Goog-Upload-Command", "start")
        start.setRequestProperty("X-Goog-Upload-Header-Content-Length", size.toString())
        start.setRequestProperty("X-Goog-Upload-Header-Content-Type", mime)
        start.setRequestProperty("Content-Type", "application/json")
        start.outputStream.use { it.write("""{"file":{"display_name":"diracclip_audio"}}""".toByteArray()) }
        if (start.responseCode !in 200..299) {
            throw ApiException("Upload start failed (${start.responseCode}): ${readBody(start).take(500)}")
        }
        val uploadUrl = start.getHeaderField("X-Goog-Upload-URL")
            ?: throw ApiException("Upload URL missing in response")
        start.disconnect()

        log("Upload ho raha hai (${size / 1024 / 1024} MB)...")
        val up = URL(uploadUrl).openConnection() as HttpURLConnection
        up.requestMethod = "POST"
        up.doOutput = true
        up.connectTimeout = 30000
        up.readTimeout = 600000
        up.setFixedLengthStreamingMode(size)
        up.setRequestProperty("X-Goog-Upload-Offset", "0")
        up.setRequestProperty("X-Goog-Upload-Command", "upload, finalize")
        file.inputStream().use { input ->
            up.outputStream.use { output -> input.copyTo(output, 64 * 1024) }
        }
        val upBody = readBody(up)
        if (up.responseCode !in 200..299) {
            throw ApiException("Upload failed (${up.responseCode}): ${upBody.take(500)}")
        }
        up.disconnect()

        val fileJson = JSONObject(upBody).getJSONObject("file")
        val name = fileJson.getString("name")
        val uri = fileJson.getString("uri")
        var state = fileJson.optString("state", "ACTIVE")

        var tries = 0
        while (state == "PROCESSING" && tries < 180) {
            Thread.sleep(4000)
            val g = URL("$BASE/v1beta/$name").openConnection() as HttpURLConnection
            g.setRequestProperty("x-goog-api-key", apiKey)
            g.connectTimeout = 30000
            g.readTimeout = 60000
            val body = readBody(g)
            if (g.responseCode in 200..299) {
                state = JSONObject(body).optString("state", "ACTIVE")
            }
            g.disconnect()
            tries++
        }
        if (state != "ACTIVE") throw ApiException("Gemini file state: $state")
        return Pair(name, uri)
    }

    /** Streams generateContent (SSE) with retries + model fallback chain. Returns the full text. */
    fun generate(apiKey: String, model: String, fileUri: String, mime: String, prompt: String, lowRes: Boolean, log: (String) -> Unit): String {
        val chain = (listOf(model) + listOf("gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash")).distinct()
        var mi = 0
        var same = 0
        var attempt = 0
        var thinkingOff = true
        var lowResOn = lowRes
        var lastError = "unknown"

        fun nextModel() {
            mi++
            same = 0
        }

        while (attempt < 6 && mi < chain.size) {
            attempt++
            val m = chain[mi]
            log("Try $attempt: $m")

            val gen = JSONObject().put("responseMimeType", "application/json")
            if (lowResOn) gen.put("mediaResolution", "MEDIA_RESOLUTION_LOW")
            if (thinkingOff && m.contains("gemini-3")) {
                gen.put("thinkingConfig", JSONObject().put("thinkingLevel", "low"))
            }
            val parts = JSONArray()
            parts.put(JSONObject().put("file_data", JSONObject().put("mime_type", mime).put("file_uri", fileUri)))
            parts.put(JSONObject().put("text", prompt))
            val body = JSONObject()
            body.put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            body.put("generationConfig", gen)

            try {
                val c = URL("$BASE/v1beta/models/$m:streamGenerateContent?alt=sse").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 30000
                c.readTimeout = 240000
                c.setRequestProperty("x-goog-api-key", apiKey)
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = c.responseCode
                if (code in 200..299) {
                    val sb = StringBuilder()
                    var first = true
                    c.inputStream.bufferedReader().use { r ->
                        while (true) {
                            val line = r.readLine() ?: break
                            if (!line.startsWith("data:")) continue
                            val js = line.removePrefix("data:").trim()
                            if (js.isEmpty()) continue
                            val o = JSONObject(js)
                            val cands = o.optJSONArray("candidates") ?: continue
                            if (cands.length() == 0) continue
                            val content = cands.getJSONObject(0).optJSONObject("content") ?: continue
                            val ps = content.optJSONArray("parts") ?: continue
                            for (k in 0 until ps.length()) sb.append(ps.getJSONObject(k).optString("text", ""))
                            if (first) {
                                first = false
                                log("AI ka jawab aa raha hai...")
                            }
                        }
                    }
                    c.disconnect()
                    if (sb.isNotBlank()) return sb.toString()
                    lastError = "Gemini ne khali jawab diya"
                    same++
                    if (same >= 2) nextModel()
                    continue
                }
                val err = readBody(c)
                c.disconnect()
                lastError = "Gemini error $code: ${err.take(300)}"
                if (code == 400 && thinkingOff && err.contains("hink", ignoreCase = true)) {
                    thinkingOff = false
                    continue
                }
                if (code == 400 && lowResOn && err.contains("esolution", ignoreCase = true)) {
                    lowResOn = false
                    continue
                }
                if (code == 400 || code == 404) {
                    log("Model '$m' kaam nahi kar raha ($code). Agla model try...")
                    nextModel()
                    continue
                }
                if (code == 429 || code == 500 || code == 503 || code == 504) {
                    log("Gemini busy/limit ($code). 20 second ruk ke dobara...")
                    Thread.sleep(20000)
                    same++
                    if (same >= 2) nextModel()
                    continue
                }
                throw ApiException(lastError)
            } catch (e: java.io.IOException) {
                lastError = "Network/timeout: ${e.message}"
                log("Network problem: ${e.message}")
                same++
                if (same >= 2) nextModel()
            }
        }
        val hint = if (lastError.contains("429")) " (Free limit lag gayi. Thodi der baad ya kal try karo, ya paid karo.)" else ""
        throw ApiException("$lastError$hint")
    }

    fun buildPrompt(o: Options, loud: List<Int> = emptyList()): String {
        val typeText = when (o.type) {
            1 -> "VIDEO TYPE: gaming live-stream. A streamer talks over gameplay. Prefer hype moments: clutch plays, funny fails, rage or shock reactions, big wins, jokes by the streamer. Always use speaker \"NONE\"."
            2 -> "VIDEO TYPE: podcast / interview with two people. Identify the two voices: A = the person who speaks first in the audio, B = the other person. For every segment set speaker to \"A\", \"B\", or \"BOTH\" (when both talk or laugh together). Split segments at speaker changes when it helps (up to 8 segments per clip)."
            3 -> "VIDEO TYPE: silent gameplay recording (Call of Duty / GTA San Andreas style). The player usually does not talk; you hear game sounds (gunshots, explosions, music). You WATCH the video and listen to it. For shooter games like Call of Duty Mobile (multiplayer and zombies mode) watch the on-screen kill feed, medals and notifications (Double Kill, Triple Kill, Headshot, Killstreak / scorestreak, MVP) and the kill counter. Pick the most exciting moments: multi-kills, kill streaks, clutches (1 vs many), sniper or headshot kills, close calls, vehicle stunts, explosions, chaotic fights, funny fails or glitches, and if the player or teammates speak, funny or hype reactions. Skip menus, loading screens, lobbies, respawn waiting, empty walking and looting. Start the clip 2-3 seconds before the action starts and end 1-2 seconds after the payoff. Always use speaker \"NONE\"." + (if (loud.isNotEmpty()) " Hint: the loudest moments (likely fights/explosions) are around these seconds: " + loud.joinToString(", ") + "." else "")
            else -> "VIDEO TYPE: normal talking video (vlog, education, commentary, motivation, etc). Always use speaker \"NONE\"."
        }
        val maxSegs = if (o.type == 2) 8 else 4
        val langText = when (o.capLang) {
            1 -> "Write captions in Hinglish: Hindi words in English/Roman letters, English words as they are."
            2 -> "Write captions translated into simple English."
            else -> "Write captions in the original spoken language and original script (do not translate)."
        }
        val capText = if (o.withCaps)
            "CAPTIONS: for every clip give 'captions' covering all speech in the final clip. Use ABSOLUTE seconds from the audio start. Each caption is 2-6 words, 0.8-2.5 seconds, and must match exactly what is said at that moment (same wording, no paraphrase, no invented text). Do not include the filler sounds you cut. $langText"
        else
            "CAPTIONS: not needed, return \"captions\": []."

        return (
            "You are a top short-form video editor who makes viral TikTok / Reels / Shorts clips. " + (if (o.type == 3) "Watch and listen to the whole video carefully." else "Listen to the whole audio carefully.") + "\n" +
            typeText + "\n\n" +
            "TASK: choose the best viral clips (maximum ${o.count}). Quality matters more than quantity: if fewer than ${o.count} moments are truly strong, return fewer. " +
            "Each final clip must be ${o.minSec}-${o.maxSec} seconds long in total.\n\n" +
            "WHAT MAKES A CLIP VIRAL (use as scoring rules):\n" +
            "1. Strong hook in the first 3 seconds: bold claim, surprising fact, question, conflict, emotional line, or funny setup.\n" +
            "2. One complete idea or story: clear setup, then payoff. Make sense without any earlier context.\n" +
            "3. High emotion, curiosity, humor, controversy, strong opinion, or a useful tip / secret / lesson.\n" +
            "4. End on the payoff or punchline, never in the middle of a thought.\n" +
            "5. Fast pace: no dead air, no rambling, no repetition.\n\n" +
            "AVOID: greetings, intros/outros, sponsor or ad reads, 'like and subscribe', small talk, housekeeping, long slow setups, repeated points, technical difficulties.\n\n" +
            "EDITING: build each clip from 1-$maxSegs segments in original order. Skip boring or rambling parts between segments (jump cuts) to keep it tight. " +
            "Every segment must start at the beginning of a phrase and end at the end of a phrase. Never cut a word in half. " +
            "Also list in 'cuts' tiny ranges INSIDE the segments to remove: filler sounds (umm, uh, hmm, err, aa), false starts, stutters, accidental repeated words. Be precise (0.1 s) and only cut clear fillers.\n\n" +
            capText + "\n\n" +
            "SCORING: give each clip 'score' from 1 to 10 for viral potential (be strict). Do NOT return clips scoring below ${o.minScore}. Order best first.\n\n" +
            "All timestamps are in seconds from the start of the media, with one decimal. Return ONLY valid JSON in exactly this shape:\n" +
            "{\"clips\":[{\"title\":\"short catchy title\",\"score\":8.5,\"reason\":\"why it can go viral\"," +
            "\"segments\":[{\"start\":12.5,\"end\":30.0,\"speaker\":\"NONE\"}]," +
            "\"cuts\":[{\"start\":20.1,\"end\":20.6}]," +
            "\"captions\":[{\"start\":12.5,\"end\":14.0,\"text\":\"caption text\"}]}]}"
        )
    }

    fun parsePlans(raw: String, durationSec: Double, o: Options): List<ClipPlan> {
        var t = raw.trim()
        if (t.startsWith("```")) {
            t = t.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        }
        val clips = JSONObject(t).getJSONArray("clips")
        val out = ArrayList<ClipPlan>()
        for (i in 0 until clips.length()) {
            val c = clips.getJSONObject(i)
            val score = c.optDouble("score", 7.0)
            if (score < o.minScore) continue

            val segs = ArrayList<Seg>()
            val sa = c.optJSONArray("segments")
            if (sa != null) {
                for (j in 0 until sa.length()) {
                    val s = sa.getJSONObject(j)
                    var st = s.optDouble("start", -1.0)
                    var en = s.optDouble("end", -1.0)
                    if (st < 0) st = 0.0
                    if (en > durationSec) en = durationSec
                    if (en - st < 0.5) continue
                    segs.add(Seg(st, en, s.optString("speaker", "NONE").uppercase()))
                }
            } else if (c.has("start") && c.has("end")) {
                val st = maxOf(0.0, c.getDouble("start"))
                val en = minOf(durationSec, c.getDouble("end"))
                if (en - st >= 0.5) segs.add(Seg(st, en, "NONE"))
            }
            if (segs.isEmpty()) continue
            val total = segs.sumOf { it.end - it.start }
            if (total < minOf(o.minSec.toDouble(), 8.0)) continue

            val caps = ArrayList<Cap>()
            val ca = c.optJSONArray("captions")
            if (ca != null) {
                for (j in 0 until ca.length()) {
                    val k = ca.getJSONObject(j)
                    caps.add(Cap(k.optDouble("start", 0.0), k.optDouble("end", 0.0), k.optString("text", "")))
                }
            }
            val cuts = ArrayList<Cut>()
            val cu = c.optJSONArray("cuts")
            if (cu != null) {
                for (j in 0 until cu.length()) {
                    val k = cu.getJSONObject(j)
                    cuts.add(Cut(k.optDouble("start", 0.0), k.optDouble("end", 0.0)))
                }
            }
            out.add(ClipPlan(c.optString("title", "Clip ${i + 1}"), score, c.optString("reason", ""), segs, caps, cuts))
        }
        return out.sortedByDescending { it.score }.take(o.count)
    }
}
