package com.diracclip.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

open class ApiException(message: String) : Exception(message)

class QuotaException(message: String) : ApiException(message)

object GeminiClient {
    private const val BASE = "https://generativelanguage.googleapis.com"

    private fun readBody(c: HttpURLConnection): String {
        val stream = try {
            if (c.responseCode in 200..299) c.inputStream else c.errorStream
        } catch (e: Exception) {
            c.errorStream
        }
        return stream?.bufferedReader()?.use { it.readText() } ?: ""
    }

    /** Uploads a file via the Gemini File API. Returns Pair(fileName, fileUri). */
    fun uploadFile(apiKey: String, file: File, mime: String, log: (String) -> Unit): Pair<String, String> {
        val size = file.length()

        val start = URL("$BASE/upload/v1beta/files").openConnection() as HttpURLConnection
        start.requestMethod = "POST"
        start.doOutput = true
        start.connectTimeout = 30000
        start.readTimeout = 60000
        start.setRequestProperty("x-goog-api-key", apiKey)
        start.setRequestProperty("X-Goog-Upload-Protocol", "resumable")
        start.setRequestProperty("X-Goog-Upload-Command", "start")
        start.setRequestProperty("X-Goog-Upload-Header-Content-Length", size.toString())
        start.setRequestProperty("X-Goog-Upload-Header-Content-Type", mime)
        start.setRequestProperty("Content-Type", "application/json")
        start.outputStream.use { it.write("""{"file":{"display_name":"diracclip_audio"}}""".toByteArray()) }
        if (start.responseCode !in 200..299) {
            val sc = start.responseCode
            val sb = readBody(start).take(400)
            if (sc == 429) throw QuotaException("Upload limit reached (429): $sb")
            throw ApiException("Upload start failed ($sc): $sb")
        }
        val uploadUrl = start.getHeaderField("X-Goog-Upload-URL")
            ?: throw ApiException("Upload URL missing in response")
        start.disconnect()

        log("Uploading to Gemini (${size / 1024 / 1024} MB)...")
        val up = URL(uploadUrl).openConnection() as HttpURLConnection
        up.requestMethod = "POST"
        up.doOutput = true
        up.connectTimeout = 30000
        up.readTimeout = 600000
        up.setFixedLengthStreamingMode(size)
        up.setRequestProperty("X-Goog-Upload-Offset", "0")
        up.setRequestProperty("X-Goog-Upload-Command", "upload, finalize")
        file.inputStream().use { input ->
            up.outputStream.use { output -> input.copyTo(output, 64 * 1024) }
        }
        val upBody = readBody(up)
        if (up.responseCode !in 200..299) {
            throw ApiException("Upload failed (${up.responseCode}): ${upBody.take(500)}")
        }
        up.disconnect()

        val fileJson = JSONObject(upBody).getJSONObject("file")
        val name = fileJson.getString("name")
        val uri = fileJson.getString("uri")
        var state = fileJson.optString("state", "ACTIVE")

        var tries = 0
        while (state == "PROCESSING" && tries < 180) {
            Thread.sleep(4000)
            val g = URL("$BASE/v1beta/$name").openConnection() as HttpURLConnection
            g.setRequestProperty("x-goog-api-key", apiKey)
            g.connectTimeout = 30000
            g.readTimeout = 60000
            val body = readBody(g)
            if (g.responseCode in 200..299) {
                state = JSONObject(body).optString("state", "ACTIVE")
            }
            g.disconnect()
            tries++
        }
        if (state != "ACTIVE") throw ApiException("Gemini file state: $state")
        return Pair(name, uri)
    }

    private val SKIP = listOf("tts", "image", "live", "audio", "embedding", "robotics", "computer", "thinking-exp", "learnlm", "gemma", "vision", "veo", "imagen")

    /** Newest Flash models first, then Flash-Lite models. */
    fun listModels(apiKey: String): List<String> {
        val c = URL("$BASE/v1beta/models?pageSize=200").openConnection() as HttpURLConnection
        c.setRequestProperty("x-goog-api-key", apiKey)
        c.connectTimeout = 30000
        c.readTimeout = 60000
        val code = c.responseCode
        val body = readBody(c)
        c.disconnect()
        if (code == 429) throw QuotaException("Gemini model list limit (429)")
        if (code !in 200..299) throw ApiException("Gemini model list failed ($code): ${body.take(200)}")
        val arr = JSONObject(body).optJSONArray("models") ?: return emptyList()
        val ids = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val id = m.optString("name").removePrefix("models/")
            val methods = m.optJSONArray("supportedGenerationMethods")
            var ok = methods == null
            if (methods != null) {
                for (j in 0 until methods.length()) if (methods.optString(j) == "generateContent") ok = true
            }
            if (ok && id.startsWith("gemini-") && id.contains("flash") && SKIP.none { id.contains(it) }) ids.add(id)
        }
        fun version(id: String): Double =
            Regex("gemini-(\\d+(?:\\.\\d+)?)").find(id)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
        return ids.sortedWith(
            compareBy<String>({ it.contains("lite") }, { -version(it) }, { it.contains("preview") || it.contains("exp") })
        )
    }

    private fun mediaParts(fileUri: String?, mime: String, prompt: String): JSONArray {
        val parts = JSONArray()
        if (fileUri != null) {
            parts.put(JSONObject().put("file_data", JSONObject().put("mime_type", mime).put("file_uri", fileUri)))
        }
        parts.put(JSONObject().put("text", prompt))
        return parts
    }

    /** One model, one key. fileUri may be null for text-only prompts. */
    fun generate(
        apiKey: String, model: String, fileUri: String?, mime: String, prompt: String,
        lowRes: Boolean, log: (String) -> Unit
    ): String = request(apiKey, model, mediaParts(fileUri, mime, prompt), lowRes, log)

    fun generateWithImages(apiKey: String, model: String, prompt: String, images: List<ByteArray>, log: (String) -> Unit): String {
        val parts = JSONArray()
        for (img in images) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", "image/jpeg")
                        .put("data", android.util.Base64.encodeToString(img, android.util.Base64.NO_WRAP))
                )
            )
        }
        parts.put(JSONObject().put("text", prompt))
        return request(apiKey, model, parts, false, log)
    }

    private fun collect(o: JSONObject, sb: StringBuilder, diag: StringBuilder) {
        val pf = o.optJSONObject("promptFeedback")
        if (pf != null && pf.has("blockReason")) diag.append("blockReason=").append(pf.optString("blockReason")).append(' ')
        val cands = o.optJSONArray("candidates") ?: return
        if (cands.length() == 0) return
        val c0 = cands.getJSONObject(0)
        if (c0.has("finishReason")) diag.append("finishReason=").append(c0.optString("finishReason")).append(' ')
        val parts = c0.optJSONObject("content")?.optJSONArray("parts") ?: return
        for (k in 0 until parts.length()) {
            val p = parts.getJSONObject(k)
            if (!p.optBoolean("thought", false)) sb.append(p.optString("text", ""))
        }
    }

    private fun request(apiKey: String, model: String, parts: JSONArray, lowRes: Boolean, log: (String) -> Unit): String {
        var low = lowRes
        var thinking = true
        var stream = true
        var attempt = 0
        var lastError = "unknown"
        while (attempt < 5) {
            attempt++
            val gen = JSONObject().put("responseMimeType", "application/json")
            if (low) gen.put("mediaResolution", "MEDIA_RESOLUTION_LOW")
            if (thinking) {
                if (model.contains("gemini-3")) {
                    gen.put("thinkingConfig", JSONObject().put("thinkingLevel", "low"))
                } else if (model.contains("2.5-flash")) {
                    gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
                }
            }
            val body = JSONObject()
            body.put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            body.put("generationConfig", gen)
            try {
                val url = if (stream) "$BASE/v1beta/models/$model:streamGenerateContent?alt=sse"
                else "$BASE/v1beta/models/$model:generateContent"
                val c = URL(url).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 30000
                c.readTimeout = 240000
                c.setRequestProperty("x-goog-api-key", apiKey)
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = c.responseCode
                if (code in 200..299) {
                    val sb = StringBuilder()
                    val diag = StringBuilder()
                    if (stream) {
                        c.inputStream.bufferedReader().use { r ->
                            while (true) {
                                val line = r.readLine() ?: break
                                if (!line.startsWith("data:")) continue
                                val js = line.removePrefix("data:").trim()
                                if (js.isEmpty()) continue
                                collect(JSONObject(js), sb, diag)
                            }
                        }
                    } else {
                        collect(JSONObject(c.inputStream.bufferedReader().use { it.readText() }), sb, diag)
                    }
                    c.disconnect()
                    if (sb.isNotBlank()) return sb.toString()
                    lastError = "Empty response (${diag.toString().trim()})"
                    log("$model returned no text: ${diag.toString().trim()}")
                    if (stream) stream = false else thinking = false
                    continue
                }
                val err = readBody(c)
                c.disconnect()
                lastError = "Gemini $code: ${err.take(300)}"
                if (code == 400 && thinking && err.contains("hink", ignoreCase = true)) {
                    thinking = false
                    continue
                }
                if (code == 400 && low && err.contains("esolution", ignoreCase = true)) {
                    low = false
                    continue
                }
                if (code == 429) {
                    val daily = err.contains("PerDay", ignoreCase = true) ||
                        err.contains("per day", ignoreCase = true) || err.contains("daily", ignoreCase = true)
                    if (daily || attempt >= 2) throw QuotaException("$model limit reached (429)")
                    log("Rate limit on $model. Waiting 20 s...")
                    Thread.sleep(20000)
                    continue
                }
                if (code == 500 || code == 503 || code == 504) {
                    log("Gemini is busy ($code). Waiting 10 s...")
                    Thread.sleep(10000)
                    continue
                }
                throw ApiException(lastError)
            } catch (e: java.io.IOException) {
                lastError = "Network/timeout: ${e.message}"
                log("Network problem: ${e.message}")
            }
        }
        if (lastError.contains("429")) throw QuotaException(lastError)
        throw ApiException(lastError)
    }

    fun buildPrompt(o: Options, loud: List<Int> = emptyList(), transcript: String? = null): String {
        val typeText = when (o.type) {
            1 -> "VIDEO TYPE: gaming live-stream. A streamer talks over gameplay. Prefer hype moments: clutch plays, funny fails, rage or shock reactions, big wins, jokes by the streamer. Always use speaker \"NONE\"."
            2 -> "VIDEO TYPE: podcast / interview with two people. Identify the two voices: A = the person who speaks first in the audio, B = the other person. For every segment set speaker to \"A\", \"B\", or \"BOTH\" (when both talk or laugh together). Split segments at speaker changes when it helps (up to 8 segments per clip)."
            3 -> "VIDEO TYPE: silent gameplay recording (Call of Duty / GTA San Andreas style). The player usually does not talk; you hear game sounds (gunshots, explosions, music). You WATCH the video and listen to it. For shooter games like Call of Duty Mobile (multiplayer and zombies mode) watch the on-screen kill feed, medals and notifications (Double Kill, Triple Kill, Headshot, Killstreak / scorestreak, MVP) and the kill counter. Pick the most exciting moments: multi-kills, kill streaks, clutches (1 vs many), sniper or headshot kills, close calls, vehicle stunts, explosions, chaotic fights, funny fails or glitches, and if the player or teammates speak, funny or hype reactions. Skip menus, loading screens, lobbies, respawn waiting, empty walking and looting. Start the clip 2-3 seconds before the action starts and end 1-2 seconds after the payoff. Always use speaker \"NONE\"." + (if (loud.isNotEmpty()) " Hint: the loudest moments (likely fights/explosions) are around these seconds: " + loud.joinToString(", ") + "." else "")
            else -> "VIDEO TYPE: normal talking video (vlog, education, commentary, motivation, etc). Always use speaker \"NONE\"."
        }
        val maxSegs = if (o.type == 2) 8 else 4
        val langText = when (o.capLang) {
            1 -> "Write captions in Hinglish: Hindi words in English/Roman letters, English words as they are."
            2 -> "Write captions translated into simple English."
            else -> "Write captions in the original spoken language and original script (do not translate)."
        }
        val capText = if (o.withCaps)
            "CAPTIONS: for every clip give 'captions' covering all speech in the final clip. Use ABSOLUTE seconds from the audio start. Each caption is 2-6 words, 0.8-2.5 seconds, and must match exactly what is said at that moment (same wording, no paraphrase, no invented text). Do not include the filler sounds you cut. $langText"
        else
            "CAPTIONS: not needed, return \"captions\": []."

        val slowText = if (o.type == 3 && o.slowmo)
            "SLOW MOTION: in 'slowmo' give up to 2 timestamps (seconds, absolute) of the single most impressive instant of the clip (a headshot, the final kill of a streak, a clutch finish, a big explosion). Use [] if none.\n\n"
        else ""
        val slowField = if (o.type == 3 && o.slowmo) "\"slowmo\":[15.2]," else ""

        return (
            "You are a top short-form video editor who makes viral TikTok / Reels / Shorts clips. " + (if (transcript != null) "Read the whole timestamped transcript at the end carefully." else if (o.type == 3) "Watch and listen to the whole video carefully." else "Listen to the whole audio carefully.") + "\n" +
            typeText + "\n\n" +
            "TASK: choose the best viral clips (maximum ${o.count}). Quality matters more than quantity: if fewer than ${o.count} moments are truly strong, return fewer. " +
            "Each final clip must be ${o.minSec}-${o.maxSec} seconds long in total.\n\n" +
            "WHAT MAKES A CLIP VIRAL (use as scoring rules):\n" +
            "1. Strong hook in the first 3 seconds: bold claim, surprising fact, question, conflict, emotional line, or funny setup.\n" +
            "2. One complete idea or story: clear setup, then payoff. Make sense without any earlier context.\n" +
            "3. High emotion, curiosity, humor, controversy, strong opinion, or a useful tip / secret / lesson.\n" +
            "4. End on the payoff or punchline, never in the middle of a thought.\n" +
            "5. Fast pace: no dead air, no rambling, no repetition.\n\n" +
            "AVOID: greetings, intros/outros, sponsor or ad reads, 'like and subscribe', small talk, housekeeping, long slow setups, repeated points, technical difficulties.\n\n" +
            "EDITING: build each clip from 1-$maxSegs segments in original order. Skip boring or rambling parts between segments (jump cuts) to keep it tight. " +
            "Every segment must start at the beginning of a phrase and end at the end of a phrase. Never cut a word in half. " +
            "Also list in 'cuts' tiny ranges INSIDE the segments to remove: filler sounds (umm, uh, hmm, err, aa), false starts, stutters, accidental repeated words. Be precise (0.1 s) and only cut clear fillers.\n\n" +
            capText + "\n\n" + slowText +
            "SCORING: give each clip 'score' from 1 to 10 for viral potential (be strict). Do NOT return clips scoring below ${o.minScore}. Order best first.\n\n" +
            "All timestamps are in seconds from the start of the media, with one decimal. Return ONLY valid JSON in exactly this shape:\n" +
            "{\"clips\":[{\"title\":\"short catchy title\",\"score\":8.5,\"reason\":\"why it can go viral\"," +
            "\"segments\":[{\"start\":12.5,\"end\":30.0,\"speaker\":\"NONE\"}]," +
            "\"cuts\":[{\"start\":20.1,\"end\":20.6}]," + slowField +
            "\"captions\":[{\"start\":12.5,\"end\":14.0,\"text\":\"caption text\"}],\"post_caption\":\"ready-to-post caption with a hook\",\"hashtags\":\"#tag1 #tag2 #tag3\"}]}" +
            (if (transcript != null) "\n\nTRANSCRIPT (seconds in brackets):\n" + transcript else "")
        )
    }

    fun parsePlans(raw: String, durationSec: Double, o: Options): List<ClipPlan> {
        val t = Json.extract(raw)
        val clips = JSONObject(t).getJSONArray("clips")
        val out = ArrayList<ClipPlan>()
        for (i in 0 until clips.length()) {
            val c = clips.getJSONObject(i)
            val score = c.optDouble("score", 7.0)
            if (score < o.minScore) continue

            val segs = ArrayList<Seg>()
            val sa = c.optJSONArray("segments")
            if (sa != null) {
                for (j in 0 until sa.length()) {
                    val s = sa.getJSONObject(j)
                    var st = s.optDouble("start", -1.0)
                    var en = s.optDouble("end", -1.0)
                    if (st < 0) st = 0.0
                    if (en > durationSec) en = durationSec
                    if (en - st < 0.5) continue
                    segs.add(Seg(st, en, s.optString("speaker", "NONE").uppercase()))
                }
            } else if (c.has("start") && c.has("end")) {
                val st = maxOf(0.0, c.getDouble("start"))
                val en = minOf(durationSec, c.getDouble("end"))
                if (en - st >= 0.5) segs.add(Seg(st, en, "NONE"))
            }
            if (segs.isEmpty()) continue
            val total = segs.sumOf { it.end - it.start }
            if (total < minOf(o.minSec.toDouble(), 8.0)) continue

            val caps = ArrayList<Cap>()
            val ca = c.optJSONArray("captions")
            if (ca != null) {
                for (j in 0 until ca.length()) {
                    val k = ca.getJSONObject(j)
                    caps.add(Cap(k.optDouble("start", 0.0), k.optDouble("end", 0.0), k.optString("text", "")))
                }
            }
            val cuts = ArrayList<Cut>()
            val cu = c.optJSONArray("cuts")
            if (cu != null) {
                for (j in 0 until cu.length()) {
                    val k = cu.getJSONObject(j)
                    cuts.add(Cut(k.optDouble("start", 0.0), k.optDouble("end", 0.0)))
                }
            }
            val slow = ArrayList<Double>()
            val sm = c.optJSONArray("slowmo")
            if (sm != null) {
                for (j in 0 until sm.length()) {
                    val v = sm.optDouble(j, -1.0)
                    if (v >= 0) slow.add(v)
                }
            }
            out.add(ClipPlan(c.optString("title", "Clip ${i + 1}"), score, c.optString("reason", ""), segs, caps, cuts, slow, c.optString("post_caption", ""), c.optString("hashtags", "")))
        }
        return out.sortedByDescending { it.score }.take(o.count)
    }

    fun buildRefinePrompt(o: Options): String {
        return "You are a professional short-form video editor (Instagram Reels / TikTok). Watch this creator video (up to 2 minutes). " +
            "Select the best visual moments to cut into a fast, beat-synced edit: strong expressions, key actions, reveals, smooth motion, good lighting and sharp focus, aesthetic shots, funny or emotional beats. " +
            "Avoid blurry, dark, shaky, static or boring frames, awkward moments and dead air.\n" +
            "Return 8 to 30 shots. Each shot is 0.8 to 5.0 seconds long, self-contained, non-overlapping, with exact start and end in seconds from the start of the video (one decimal). " +
            "Score each shot 1-10 for how good it looks in a Reel (best moments highest).\n" +
            "Also return: 'title' (max 6 words, a hook), 'mood' (one of energetic, chill, cinematic, funny, emotional), 'post_caption' (ready to post, with a hook) and 'hashtags'.\n" +
            "Return ONLY valid JSON in exactly this shape:\n" +
            "{\"title\":\"short hook\",\"mood\":\"energetic\",\"post_caption\":\"caption\",\"hashtags\":\"#a #b #c\",\"shots\":[{\"start\":3.0,\"end\":5.5,\"score\":9}]}"
    }

    fun parseShots(raw: String, durationSec: Double): ShotPlan {
        val t = Json.extract(raw)
        val j = JSONObject(t)
        val arr = j.getJSONArray("shots")
        val shots = ArrayList<Shot>()
        for (i in 0 until arr.length()) {
            val s = arr.getJSONObject(i)
            val st = maxOf(0.0, s.optDouble("start", -1.0))
            val en = minOf(durationSec, s.optDouble("end", -1.0))
            if (en - st >= 0.5) shots.add(Shot(st, en, s.optDouble("score", 5.0)))
        }
        if (shots.isEmpty()) throw ApiException("The AI did not return any usable scenes.")
        return ShotPlan(
            j.optString("title", "Edit"), j.optString("mood", "energetic"),
            j.optString("post_caption", ""), j.optString("hashtags", ""), shots
        )
    }

    fun buildSongPrompt(o: Options, transcript: String? = null): String {
        val langText = when (o.capLang) {
            1 -> "Write the lyrics in Hinglish: Hindi words in English/Roman letters."
            2 -> "Write the lyrics translated into simple English."
            else -> "Write the lyrics in the original language and script."
        }
        return (if (transcript != null) "Read the timestamped transcript of this song at the end carefully. " else "Listen to this song carefully. ") +
            "You are a music-edit expert for Instagram Reels / TikTok.\n" +
            "TASK 1: give the lyrics as timed lines (absolute seconds from the start, one decimal, each line 1-6 seconds). $langText\n" +
            "TASK 2: choose up to 3 of the most viral sections of the song: the hook line, chorus or punchline that people quote, lip-sync or reuse in videos. " +
            "Each section must be ${o.minSec}-${o.maxSec} seconds long, start at the beginning of a lyric line and end at the end of a line. Score each 1-10.\n" +
            "Also return 'title' (song name or a short hook), 'mood' (energetic, chill, cinematic, funny, emotional), 'post_caption' and 'hashtags'.\n" +
            "Return ONLY valid JSON in exactly this shape:\n" +
            "{\"title\":\"name\",\"mood\":\"energetic\",\"post_caption\":\"caption\",\"hashtags\":\"#a #b\"," +
            "\"lines\":[{\"start\":12.0,\"end\":15.5,\"text\":\"lyric line\"}]," +
            "\"sections\":[{\"start\":30.0,\"end\":58.0,\"score\":9,\"reason\":\"why\"}]}" +
            (if (transcript != null) "\n\nTRANSCRIPT (seconds in brackets):\n" + transcript else "")
    }

    fun parseSong(raw: String, durationSec: Double): SongPlan {
        val j = JSONObject(Json.extract(raw))
        val lines = ArrayList<Cap>()
        val la = j.optJSONArray("lines")
        if (la != null) {
            for (i in 0 until la.length()) {
                val l = la.getJSONObject(i)
                val txt = l.optString("text", "").trim()
                if (txt.isNotEmpty()) lines.add(Cap(l.optDouble("start", 0.0), l.optDouble("end", 0.0), txt))
            }
        }
        val secs = ArrayList<Shot>()
        val sa = j.optJSONArray("sections")
        if (sa != null) {
            for (i in 0 until sa.length()) {
                val s = sa.getJSONObject(i)
                val st = maxOf(0.0, s.optDouble("start", -1.0))
                val en = minOf(durationSec, s.optDouble("end", -1.0))
                if (en - st >= 5.0) secs.add(Shot(st, en, s.optDouble("score", 5.0)))
            }
        }
        if (secs.isEmpty()) throw ApiException("The AI did not return any song sections.")
        return SongPlan(
            j.optString("title", "Song edit"), j.optString("mood", "energetic"),
            j.optString("post_caption", ""), j.optString("hashtags", ""),
            lines, secs.sortedByDescending { it.score }
        )
    }
}
