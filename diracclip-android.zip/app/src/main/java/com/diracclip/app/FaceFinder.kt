package com.diracclip.app

import android.graphics.Bitmap
import android.graphics.RectF
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.TimeUnit

object FaceFinder {
    private val detector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setMinFaceSize(0.03f)
                .build()
        )
    }

    /** Returns face boxes in the bitmap's pixel coordinates, biggest first. Call from a background thread. */
    fun detect(bmp: Bitmap): List<RectF> {
        return try {
            val faces = Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0)), 30, TimeUnit.SECONDS)
            faces.map { RectF(it.boundingBox) }.sortedByDescending { it.width() * it.height() }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
