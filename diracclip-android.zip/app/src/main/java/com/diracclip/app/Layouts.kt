package com.diracclip.app

import android.graphics.RectF
import androidx.media3.common.Effect
import androidx.media3.effect.Crop
import androidx.media3.effect.Presentation

class LayoutResult(val effects: List<Effect>, val captionY: Float)

object Layouts {

    private fun centerCrop(): LayoutResult {
        return LayoutResult(
            listOf(Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)),
            -0.55f
        )
    }

    /** 9:16 crop window horizontally centred on cx. */
    private fun cropAround(cx: Float, ctx: FaceCtx): LayoutResult {
        val w = ctx.w.toFloat()
        val h = ctx.h.toFloat()
        val aspect = 9f / 16f
        var cw = h * aspect
        var ch = h
        if (cw > w) {
            cw = w
            ch = w / aspect
        }
        val left = (cx - cw / 2f).coerceIn(0f, w - cw)
        val top = ((h - ch) / 2f).coerceAtLeast(0f)
        val crop = Crop(
            -1f + 2f * left / w,
            -1f + 2f * (left + cw) / w,
            1f - 2f * (top + ch) / h,
            1f - 2f * top / h
        )
        return LayoutResult(
            listOf(crop, Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT)),
            -0.55f
        )
    }

    /** Source rect (x,y,w,h normalised, top-left origin) around a face with the given panel aspect (w/h). */
    private fun faceRect(face: RectF, ctx: FaceCtx, aspect: Float, widthFactor: Float): FloatArray {
        val w = ctx.w.toFloat()
        val h = ctx.h.toFloat()
        var pw = minOf(face.width() * widthFactor, w)
        var ph = pw / aspect
        if (ph > h) {
            ph = h
            pw = ph * aspect
        }
        val cx = (face.centerX() - pw / 2f).coerceIn(0f, w - pw)
        val cy = (face.centerY() - ph * 0.45f).coerceIn(0f, h - ph)
        return floatArrayOf(cx / w, cy / h, pw / w, ph / h)
    }

    private fun gameRect(ctx: FaceCtx): FloatArray {
        val w = ctx.w.toFloat()
        val h = ctx.h.toFloat()
        val aspect = 1080f / 1200f
        var gh = h
        var gw = h * aspect
        if (gw > w) {
            gw = w
            gh = w / aspect
        }
        return floatArrayOf((w - gw) / 2f / w, (h - gh) / 2f / h, gw / w, gh / h)
    }

    fun effects(piece: Piece, o: Options, ctx: FaceCtx?, basic: Boolean): LayoutResult {
        if (o.type == 3) {
            if (basic) return centerCrop()
            return LayoutResult(listOf(FitBlurEffect()), -0.55f)
        }
        if (o.fit) {
            return LayoutResult(
                listOf(Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT)),
                -0.55f
            )
        }
        if (ctx == null || ctx.w <= 0 || ctx.h <= 0 || ctx.faces.isEmpty() || basic) return centerCrop()

        val biggest = ctx.faces[0]
        return when (o.type) {
            1 -> {
                // gaming: game on top, facecam below
                val splitTop = 1200f / 1920f
                LayoutResult(
                    listOf(StackEffect(gameRect(ctx), faceRect(biggest, ctx, 1080f / 720f, 2.8f), splitTop)),
                    1f - 2f * splitTop
                )
            }
            2 -> {
                if (ctx.faces.size < 2) return cropAround(biggest.centerX(), ctx)
                val two = ctx.faces.take(2).sortedBy { it.centerX() }
                val left = two[0]
                val right = two[1]
                val a = if (o.speakerALeft) left else right
                val b = if (o.speakerALeft) right else left
                when (piece.speaker.uppercase()) {
                    "A" -> cropAround(a.centerX(), ctx)
                    "B" -> cropAround(b.centerX(), ctx)
                    else -> LayoutResult(
                        listOf(
                            StackEffect(
                                faceRect(left, ctx, 1080f / 960f, 3.2f),
                                faceRect(right, ctx, 1080f / 960f, 3.2f),
                                0.5f
                            )
                        ),
                        0f
                    )
                }
            }
            else -> cropAround(biggest.centerX(), ctx)
        }
    }

    /** Tight 9:16 crop on the face (used for some shots of a Refine edit to add variety). */
    fun closeUp(ctx: FaceCtx): LayoutResult {
        val w = ctx.w.toFloat()
        val h = ctx.h.toFloat()
        var cw = h * 9f / 16f
        var ch = h
        if (cw > w) {
            cw = w
            ch = w * 16f / 9f
        }
        val z = 0.7f
        val cw2 = cw * z
        val ch2 = ch * z
        val face = ctx.faces.firstOrNull()
        val cx = face?.centerX() ?: (w / 2f)
        val cy = face?.centerY() ?: (h * 0.4f)
        val left = (cx - cw2 / 2f).coerceIn(0f, maxOf(0f, w - cw2))
        val top = (cy - ch2 / 2f).coerceIn(0f, maxOf(0f, h - ch2))
        val crop = Crop(
            -1f + 2f * left / w,
            -1f + 2f * (left + cw2) / w,
            1f - 2f * (top + ch2) / h,
            1f - 2f * top / h
        )
        return LayoutResult(
            listOf(crop, Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT)),
            -0.55f
        )
    }
}
