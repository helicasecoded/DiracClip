package com.diracclip.app

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import androidx.media3.common.Effect
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.RgbAdjustment

/** Zoom that starts large and settles to normal (a "punch" on every cut). base = constant extra zoom. */
class PunchZoom(private val maxScale: Float, private val dur: Float, private val base: Float = 1f) : MatrixTransformation {
    override fun getMatrix(presentationTimeUs: Long): Matrix {
        val el = presentationTimeUs / 1_000_000f
        val p = maxOf(0f, 1f - el / dur)
        val s = base * (1f + (maxScale - 1f) * p * p)
        val m = Matrix()
        m.postScale(s, s)
        return m
    }
}

/** Smooth push-in or pull-out across the whole shot. */
class PushPull(private val from: Float, private val to: Float, private val slotDur: Float) : MatrixTransformation {
    override fun getMatrix(presentationTimeUs: Long): Matrix {
        val el = presentationTimeUs / 1_000_000f
        val p = minOf(1f, el / maxOf(0.1f, slotDur))
        val s = from + (to - from) * p
        val m = Matrix()
        m.postScale(s, s)
        return m
    }
}

/** Slow zoom-in across the whole shot. */
class Drift(private val total: Float, private val slotDur: Float) : MatrixTransformation {
    override fun getMatrix(presentationTimeUs: Long): Matrix {
        val el = presentationTimeUs / 1_000_000f
        val p = minOf(1f, el / maxOf(0.1f, slotDur))
        val s = 1f + total * p
        val m = Matrix()
        m.postScale(s, s)
        return m
    }
}

/** Short camera shake at the start of each shot. */
class Shake(private val amp: Float, private val dur: Float) : MatrixTransformation {
    override fun getMatrix(presentationTimeUs: Long): Matrix {
        val el = presentationTimeUs / 1_000_000f
        val decay = maxOf(0f, 1f - el / dur)
        val m = Matrix()
        m.postScale(1.07f, 1.07f)
        m.postTranslate(
            (amp * decay * Math.sin(el * 70.0)).toFloat(),
            (amp * decay * Math.cos(el * 55.0)).toFloat()
        )
        return m
    }
}

/** White flash that fades out at the start of a shot. */
class FlashOverlay(private val dur: Float) : BitmapOverlay() {
    private val bmp: Bitmap = Bitmap.createBitmap(1080, 1920, Bitmap.Config.ARGB_8888).also { it.eraseColor(Color.WHITE) }

    override fun getBitmap(presentationTimeUs: Long): Bitmap = bmp

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val el = presentationTimeUs / 1_000_000f
        val a = maxOf(0f, 0.85f * (1f - el / dur))
        return OverlaySettings.Builder().setAlphaScale(a).build()
    }
}

object RefineFx {
    /** Visual effects for one shot, based on the edit style stored in piece.style (1..8). */
    fun effects(pc: Piece): List<Effect> {
        val d = Planner.outDuration(pc).toFloat()
        val out = ArrayList<Effect>()
        val inOut = pc.idx % 2 == 0
        when (pc.style) {
            1 -> {
                out.add(PunchZoom(1.26f, 0.26f, 1.08f))
                out.add(Contrast(0.12f))
            }
            2 -> {
                out.add(PunchZoom(1.12f, 0.2f))
                out.add(HslAdjustment.Builder().adjustSaturation(20f).build())
            }
            3 -> {
                out.add(if (inOut) PushPull(1.0f, 1.13f, d) else PushPull(1.15f, 1.02f, d))
                out.add(RgbAdjustment.Builder().setRedScale(1.03f).setBlueScale(0.97f).build())
            }
            4 -> {
                out.add(if (inOut) PushPull(1.02f, 1.1f, d) else PushPull(1.12f, 1.0f, d))
                out.add(RgbAdjustment.Builder().setRedScale(1.08f).setBlueScale(0.92f).build())
                out.add(Contrast(0.2f))
            }
            5 -> {
                out.add(Shake(0.025f, 0.28f))
                out.add(PunchZoom(1.1f, 0.2f))
            }
            6 -> {
                out.add(PunchZoom(1.16f, 0.22f, 1.04f))
                out.add(HslAdjustment.Builder().adjustSaturation(-100f).build())
                out.add(Contrast(0.28f))
            }
            7 -> {
                out.add(Shake(0.03f, 0.2f))
                out.add(RgbAdjustment.Builder().setRedScale(1.16f).setGreenScale(0.9f).setBlueScale(1.12f).build())
                out.add(Contrast(0.22f))
            }
            8 -> {
                out.add(if (inOut) PushPull(1.0f, 1.09f, d) else PushPull(1.1f, 1.0f, d))
                out.add(HslAdjustment.Builder().adjustSaturation(28f).build())
                out.add(Brightness(0.05f))
            }
        }
        return out
    }
}

object RefinePlanner {
    val STYLE_NAMES = listOf("Fast Punch", "Flash Cut", "Smooth Flow", "Cinematic", "Rhythm Shake", "B&W Flash", "Neon Glitch", "Dreamy Glow")

    // cut length in beats, per style
    private val PATTERNS = listOf(
        intArrayOf(2, 2, 1, 1, 2, 2, 4),
        intArrayOf(2, 2, 4),
        intArrayOf(4),
        intArrayOf(4, 4, 8),
        intArrayOf(2),
        intArrayOf(1, 1, 2, 1, 1, 2),
        intArrayOf(2, 1, 1, 2, 4),
        intArrayOf(4, 4, 2, 2)
    )

    /** Builds a beat-synced timeline of shots. beats = beat times from the clip start. */
    fun build(
        plan: ShotPlan, beats: List<Double>, period: Double, targetLen: Double,
        style: Int, seed: Long, srcDur: Double
    ): List<Piece> {
        val shots = plan.shots.sortedByDescending { it.score }
        if (shots.isEmpty()) return emptyList()
        val rnd = java.util.Random(seed)
        val order = ArrayList<Shot>()
        order.add(shots[0]) // best shot first = the hook
        order.addAll(shots.drop(1).shuffled(rnd))

        val pat = PATTERNS[style % PATTERNS.size]
        val bounds = ArrayList<Double>()
        bounds.add(0.0)
        var t = 0.0
        var j = 0
        while (j < 300) {
            val k = pat[j % pat.size]
            j++
            var nt = t + k * period
            val nb = beats.minByOrNull { Math.abs(it - nt) }
            if (nb != null && Math.abs(nb - nt) < period * 0.45 && nb > t + 0.2) nt = nb
            if (nt > targetLen + period * 0.3) break
            bounds.add(nt)
            t = nt
            if (t >= targetLen - period * 0.3) break
        }
        if (bounds.size < 2) return emptyList()

        val used = ArrayList<Pair<Double, Double>>()
        val out = ArrayList<Piece>()
        var idx = 0
        for (i in 0 until bounds.size - 1) {
            val d = bounds[i + 1] - bounds[i]
            val speed = if ((style == 3 && i % 2 == 1) || (style == 7 && i % 3 == 2)) 0.7 else 1.0
            val need = d * speed
            var chosen = -1.0
            for (tryN in 0 until order.size) {
                val sh = order[(idx + tryN) % order.size]
                var s0 = sh.start
                if (s0 + need > srcDur) s0 = maxOf(0.0, srcDur - need)
                val e0 = s0 + need
                if (used.none { s0 < it.second - 0.15 && e0 > it.first + 0.15 }) {
                    chosen = s0
                    idx += tryN + 1
                    break
                }
            }
            if (chosen < 0) {
                val sh = order[idx % order.size]
                idx++
                chosen = maxOf(0.0, minOf(sh.start, srcDur - need))
            }
            val end = minOf(srcDur, chosen + need)
            used.add(Pair(chosen, end))
            out.add(Piece(chosen, end, "NONE", speed, style + 1, i))
        }
        return out
    }

    /** No-AI scene picker: evenly spaced windows, scored by loudness. */
    fun fallbackShots(energy: FloatArray, durationSec: Double): ShotPlan {
        val n = minOf(24, maxOf(3, (durationSec / 3.0).toInt()))
        val step = durationSec / n
        val shots = ArrayList<Shot>()
        val avgs = ArrayList<Double>()
        for (i in 0 until n) {
            val s = i * step
            val i0 = (s / Planner.HOP).toInt()
            val i1 = minOf(energy.size, ((s + 2.5) / Planner.HOP).toInt())
            var sum = 0.0
            for (k in i0 until i1) sum += energy[k]
            avgs.add(if (i1 > i0) sum / (i1 - i0) else 0.0)
        }
        val mx = (avgs.maxOrNull() ?: 1.0).coerceAtLeast(1.0)
        for (i in 0 until n) {
            val s = i * step
            shots.add(Shot(s, minOf(durationSec, s + 2.5), 3.0 + 7.0 * avgs[i] / mx))
        }
        return ShotPlan("Edit", "energetic", "", "", shots)
    }
}
