package com.diracclip.app

import java.io.File

/**
 * Sends every AI request to the best available key + model and, when one hits a limit
 * or fails, silently continues with the next key / model.
 */
class Router(
    private val keys: List<KeyInfo>,
    private val preferredGemini: String,
    private val log: (String) -> Unit
) {
    private val order = listOf(Provider.GEMINI, Provider.GROQ, Provider.CEREBRAS, Provider.OPENROUTER, Provider.XAI, Provider.OPENAI)
    private val sorted: List<KeyInfo> = keys.sortedBy { order.indexOf(it.provider) }
    private val dead = HashSet<String>()
    private val deadKeys = HashSet<String>()
    private val infoCache = HashMap<String, List<OpenAiClient.MInfo>>()
    private val geminiCache = HashMap<String, List<String>>()

    private val bad = listOf(
        "whisper", "tts", "guard", "embed", "image", "imagine", "video", "audio", "moderation",
        "transcribe", "orpheus", "playai", "safeguard", "ling", "ring", ":thinking"
    )

    private val textPrefs: Map<Provider, List<String>> = mapOf(
        Provider.GROQ to listOf("llama-3.3-70b", "llama-4-scout", "llama-4-maverick", "qwen3-32b", "gpt-oss-120b", "kimi-k2", "gpt-oss-20b", "llama-3.1-8b"),
        Provider.CEREBRAS to listOf("llama-3.3-70b", "gpt-oss-120b", "qwen-3-32b", "qwen-3-235b", "llama3.1-8b"),
        Provider.OPENROUTER to listOf("llama-3.3-70b", "gpt-oss-120b", "qwen3-235b", "deepseek-chat", "deepseek-v3", "qwen3-32b", "gemma-3-27b", "mistral-small", "llama-4", "glm", "kimi", "gpt-oss-20b", "gemma-3-12b"),
        Provider.XAI to listOf("grok-4-fast", "grok-4", "grok-3-mini", "grok"),
        Provider.OPENAI to listOf("gpt-4o-mini", "gpt-4.1-mini", "gpt-5-mini", "gpt")
    )

    private val visionPrefs: Map<Provider, List<String>> = mapOf(
        Provider.GROQ to listOf("llama-4-scout", "llama-4-maverick"),
        Provider.OPENROUTER to listOf("gemma-3-27b", "llama-4", "qwen2.5-vl", "qwen3-vl", "mistral-small", "gemma-3-12b"),
        Provider.XAI to listOf("grok-4", "vision"),
        Provider.OPENAI to listOf("gpt-4o-mini", "gpt-4.1-mini")
    )

    private fun cid(k: KeyInfo, m: String) = k.key + "|" + m

    private fun geminiModels(k: KeyInfo): List<String> {
        return geminiCache.getOrPut(k.key) {
            val ids = try {
                GeminiClient.listModels(k.key)
            } catch (e: Exception) {
                emptyList()
            }
            val base = if (ids.isEmpty()) listOf("gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash", "gemini-3.5-flash-lite") else ids
            val list = ArrayList<String>()
            if (preferredGemini.isNotBlank()) list.add(preferredGemini)
            for (m in base) if (m !in list) list.add(m)
            list.take(6)
        }
    }

    private fun infos(k: KeyInfo): List<OpenAiClient.MInfo> =
        infoCache.getOrPut(k.key) { OpenAiClient.listModelInfos(k.provider.base, k.key, k.provider) }

    private fun textModels(k: KeyInfo): List<String> {
        if (k.provider == Provider.GEMINI) return geminiModels(k)
        val all = infos(k).filter { i ->
            bad.none { i.id.contains(it, ignoreCase = true) } && (k.provider != Provider.OPENROUTER || i.free)
        }
        val out = ArrayList<String>()
        for (p in textPrefs[k.provider] ?: emptyList()) {
            val hit = all.firstOrNull { it.id.contains(p, ignoreCase = true) && it.id !in out }
            if (hit != null) out.add(hit.id)
        }
        if (out.size < 2) {
            for (i in all) {
                if (out.size >= 4) break
                if (i.id !in out) out.add(i.id)
            }
        }
        return out.take(6)
    }

    private fun visionModels(k: KeyInfo): List<String> {
        if (k.provider == Provider.GEMINI) return geminiModels(k)
        val all = infos(k).filter { i ->
            i.vision && bad.none { i.id.contains(it, ignoreCase = true) } && (k.provider != Provider.OPENROUTER || i.free)
        }
        val out = ArrayList<String>()
        for (p in visionPrefs[k.provider] ?: emptyList()) {
            val hit = all.firstOrNull { it.id.contains(p, ignoreCase = true) && it.id !in out }
            if (hit != null) out.add(hit.id)
        }
        for (i in all) {
            if (out.size >= 4) break
            if (i.id !in out) out.add(i.id)
        }
        return out.take(5)
    }

    /** Writes the models that will be used, in order, for each key. */
    fun announce() {
        for ((n, k) in sorted.withIndex()) {
            val ms = try {
                textModels(k)
            } catch (e: Exception) {
                emptyList()
            }
            log("Key ${n + 1} (${k.provider.label}): " + (if (ms.isEmpty()) "no models found" else ms.joinToString(", ")))
        }
    }

    private fun <T : Any> tryRun(k: KeyInfo, m: String, what: String, block: () -> T): T? {
        val id = cid(k, m)
        try {
            log("AI ($what): ${k.provider.label} / $m")
            return block()
        } catch (e: QuotaException) {
            dead.add(id)
            if (e.message?.contains("Upload", ignoreCase = true) == true) deadKeys.add(k.key)
            log("${k.provider.label} / $m: limit reached. Switching to the next option...")
        } catch (e: Exception) {
            val msg = e.message ?: e.toString()
            dead.add(id)
            if (msg.contains("401") || msg.contains("403") || msg.contains("API key not valid", true) ||
                msg.contains("invalid api key", true) || msg.contains("Incorrect API key", true)
            ) {
                deadKeys.add(k.key)
                log("${k.provider.label} key was rejected (invalid or no access). Skipping it.")
            } else {
                log("${k.provider.label} / $m failed: ${msg.take(120)}. Switching...")
            }
        }
        return null
    }

    fun <T : Any> text(prompt: String, parse: (String) -> T): T {
        for (k in sorted) {
            if (k.key in deadKeys) continue
            val models = try {
                textModels(k)
            } catch (e: Exception) {
                log("${k.provider.label}: models unavailable (${(e.message ?: "").take(80)})")
                continue
            }
            for (m in models) {
                if (cid(k, m) in dead) continue
                val r = tryRun(k, m, "text") {
                    val raw = if (k.provider == Provider.GEMINI) {
                        GeminiClient.generate(k.key, m, null, "", prompt, false, log)
                    } else {
                        OpenAiClient.chat(k.provider.base, k.key, m, prompt, log)
                    }
                    parse(raw)
                }
                if (r != null) return r
                if (k.key in deadKeys) break
            }
        }
        throw ApiException("All keys and models are exhausted or failed. Add another key or try again later.")
    }

    fun <T : Any> vision(prompt: String, images: List<ByteArray>, parse: (String) -> T): T {
        for (k in sorted) {
            if (k.key in deadKeys) continue
            val models = try {
                visionModels(k)
            } catch (e: Exception) {
                continue
            }
            for (m in models) {
                if (cid(k, m) in dead) continue
                val r = tryRun(k, m, "vision") {
                    val raw = if (k.provider == Provider.GEMINI) {
                        GeminiClient.generateWithImages(k.key, m, prompt, images, log)
                    } else {
                        OpenAiClient.chatVision(k.provider.base, k.key, m, prompt, images, log)
                    }
                    parse(raw)
                }
                if (r != null) return r
                if (k.key in deadKeys) break
            }
        }
        throw ApiException("No vision-capable key or model is available.")
    }

    /** Gemini can read audio / video files directly. Returns null if no Gemini key/model worked. */
    fun <T : Any> geminiMedia(fileProvider: () -> File, mime: String, prompt: String, lowRes: Boolean, parse: (String) -> T): T? {
        val gem = sorted.filter { it.provider == Provider.GEMINI }
        if (gem.isEmpty()) return null
        var file: File? = null
        val uploaded = HashMap<String, String>()
        for (k in gem) {
            if (k.key in deadKeys) continue
            for (m in geminiModels(k)) {
                if (cid(k, m) in dead) continue
                val r = tryRun(k, m, "audio/video") {
                    val f = file ?: fileProvider().also { file = it }
                    val uri = uploaded.getOrPut(k.key) { GeminiClient.uploadFile(k.key, f, mime) { log(it) }.second }
                    parse(GeminiClient.generate(k.key, m, uri, mime, prompt, lowRes, log))
                }
                if (r != null) return r
                if (k.key in deadKeys) break
            }
        }
        return null
    }

    /** Speech-to-text on one WAV chunk, trying every STT-capable key. */
    fun stt(wav: File, offset: Double): List<Triple<Double, Double, String>> {
        for (k in sorted) {
            if (k.provider != Provider.GROQ && k.provider != Provider.OPENAI) continue
            if (k.key in deadKeys) continue
            val model = try {
                OpenAiClient.pickSttModel(infos(k).map { it.id })
            } catch (e: Exception) {
                null
            } ?: continue
            if (cid(k, model) in dead) continue
            val r = tryRun(k, model, "speech-to-text") {
                OpenAiClient.transcribe(k.provider.base, k.key, model, wav, offset)
            }
            if (r != null) return r
        }
        throw ApiException("No speech-to-text is available (it needs a Gemini, Groq or OpenAI key that still has quota).")
    }

    /** Speech-to-text with word timestamps. */
    fun sttFull(
        wav: File, offset: Double, prompt: String
    ): Pair<List<Triple<Double, Double, String>>, List<Triple<Double, Double, String>>> {
        for (k in sorted) {
            if (k.provider != Provider.GROQ && k.provider != Provider.OPENAI) continue
            if (k.key in deadKeys) continue
            val model = try {
                OpenAiClient.pickSttModel(infos(k).map { it.id })
            } catch (e: Exception) {
                null
            } ?: continue
            if (cid(k, model) in dead) continue
            val r = tryRun(k, model, "speech-to-text") {
                OpenAiClient.transcribeFull(k.provider.base, k.key, model, wav, offset, prompt, true)
            }
            if (r != null) return r
        }
        throw ApiException("No speech-to-text is available (it needs a Groq or OpenAI key that still has quota).")
    }
}
