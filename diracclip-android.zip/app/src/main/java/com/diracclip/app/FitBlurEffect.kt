package com.diracclip.app

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/** Whole landscape frame in the middle of a 1080x1920 output, blurred zoomed copy above and below. */
class FitBlurEffect : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram {
        return FitBlurProgram(useHdr)
    }
}

class FitBlurProgram(useHdr: Boolean) : BaseGlShaderProgram(useHdr, 1) {

    private val program: GlProgram = GlProgram(VERTEX, FRAGMENT)
    private var fgFrac = 0.316f
    private var bgW = 0.316f

    init {
        program.setBufferAttribute(
            "aFramePosition",
            GlUtil.getNormalizedCoordinateBounds(),
            GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
        )
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        val w = maxOf(1, inputWidth).toFloat()
        val h = maxOf(1, inputHeight).toFloat()
        fgFrac = minOf(1f, (1080f * h / w) / 1920f)
        bgW = minOf(1f, (9f / 16f) * h / w)
        return Size(1080, 1920)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        program.use()
        program.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
        program.setFloatUniform("uFgFrac", fgFrac)
        program.setFloatUniform("uBgW", bgW)
        program.bindAttributesAndUniforms()
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GlUtil.checkGlError()
    }

    override fun release() {
        super.release()
        program.delete()
    }

    companion object {
        private const val VERTEX = """
attribute vec4 aFramePosition;
varying vec2 vTexSamplingCoord;
void main() {
  gl_Position = aFramePosition;
  vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
}
"""
        private const val FRAGMENT = """
precision mediump float;
uniform sampler2D uTexSampler;
uniform float uFgFrac;
uniform float uBgW;
varying vec2 vTexSamplingCoord;
void main() {
  vec2 uv = vTexSamplingCoord;
  float fromTop = 1.0 - uv.y;
  float top = (1.0 - uFgFrac) * 0.5;
  if (fromTop >= top && fromTop <= top + uFgFrac) {
    float sy = (fromTop - top) / uFgFrac;
    gl_FragColor = texture2D(uTexSampler, vec2(uv.x, 1.0 - sy));
  } else {
    float bx = 0.5 + (uv.x - 0.5) * uBgW;
    vec4 c = vec4(0.0);
    for (int i = -2; i <= 2; i++) {
      for (int j = -2; j <= 2; j++) {
        vec2 p = vec2(bx, uv.y) + vec2(float(i), float(j)) * 0.02;
        c += texture2D(uTexSampler, clamp(p, 0.0, 1.0));
      }
    }
    gl_FragColor = (c / 25.0) * 0.55;
  }
}
"""
    }
}
