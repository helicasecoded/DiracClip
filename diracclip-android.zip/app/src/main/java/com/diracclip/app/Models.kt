package com.diracclip.app

data class Cap(val start: Double, val end: Double, val text: String)

data class ClipPlan(
    val start: Double,
    val end: Double,
    val title: String,
    val caps: List<Cap>
)
