package com.diracclip.app

import android.graphics.RectF
import android.net.Uri

data class Cap(val start: Double, val end: Double, val text: String)

data class Seg(val start: Double, val end: Double, val speaker: String)

data class Cut(val start: Double, val end: Double)

data class ClipPlan(
    val title: String,
    val score: Double,
    val reason: String,
    val segs: List<Seg>,
    val caps: List<Cap>,
    val cuts: List<Cut>,
    val slowmo: List<Double>,
    val postCaption: String = "",
    val hashtags: String = ""
)

data class Piece(val start: Double, val end: Double, val speaker: String, val speed: Double = 1.0)

/** type: 0 = normal talking video, 1 = gaming stream (game + facecam), 2 = podcast (2 people), 3 = silent gameplay recording */
data class Options(
    val count: Int,
    val minSec: Int,
    val maxSec: Int,
    val withCaps: Boolean,
    val trimPauses: Boolean,
    val fit: Boolean,
    val type: Int,
    val capLang: Int,
    val minScore: Int,
    val speakerALeft: Boolean,
    val title: Boolean,
    val music: Uri?,
    val beatSync: Boolean,
    val slowmo: Boolean
)

data class FaceCtx(val w: Int, val h: Int, val faces: List<RectF>)
