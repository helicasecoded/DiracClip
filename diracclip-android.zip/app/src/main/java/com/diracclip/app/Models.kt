package com.diracclip.app

import android.graphics.RectF

data class Cap(val start: Double, val end: Double, val text: String)

data class Seg(val start: Double, val end: Double, val speaker: String)

data class Cut(val start: Double, val end: Double)

data class ClipPlan(
    val title: String,
    val score: Double,
    val reason: String,
    val segs: List<Seg>,
    val caps: List<Cap>,
    val cuts: List<Cut>
)

data class Piece(val start: Double, val end: Double, val speaker: String)

/** type: 0 = normal talking video, 1 = gaming stream (game + facecam), 2 = podcast (2 people) */
data class Options(
    val count: Int,
    val minSec: Int,
    val maxSec: Int,
    val withCaps: Boolean,
    val trimPauses: Boolean,
    val fit: Boolean,
    val type: Int,
    val capLang: Int,
    val minScore: Int,
    val speakerALeft: Boolean
)

data class FaceCtx(val w: Int, val h: Int, val faces: List<RectF>)
