package com.diracclip.app

import android.graphics.RectF
import android.net.Uri

data class Cap(val start: Double, val end: Double, val text: String)

data class Seg(val start: Double, val end: Double, val speaker: String)

data class Cut(val start: Double, val end: Double)

data class ClipPlan(
    val title: String,
    val score: Double,
    val reason: String,
    val segs: List<Seg>,
    val caps: List<Cap>,
    val cuts: List<Cut>,
    val slowmo: List<Double>,
    val postCaption: String = "",
    val hashtags: String = ""
)

data class Piece(
    val start: Double,
    val end: Double,
    val speaker: String,
    val speed: Double = 1.0,
    val style: Int = 0,
    val idx: Int = 0
)

data class Shot(val start: Double, val end: Double, val score: Double)

data class ShotPlan(
    val title: String,
    val mood: String,
    val postCaption: String,
    val hashtags: String,
    val shots: List<Shot>
)

/** type: 0 = talking video, 1 = game stream, 2 = podcast, 3 = silent gameplay, 4 = Refine (creator video -> beat edit) */
data class Options(
    val count: Int,
    val minSec: Int,
    val maxSec: Int,
    val withCaps: Boolean,
    val trimPauses: Boolean,
    val fit: Boolean,
    val type: Int,
    val capLang: Int,
    val minScore: Int,
    val speakerALeft: Boolean,
    val title: Boolean,
    val music: Uri?,
    val beatSync: Boolean,
    val slowmo: Boolean,
    val keepAudio: Boolean
)

data class FaceCtx(val w: Int, val h: Int, val faces: List<RectF>)

data class SongPlan(
    val title: String,
    val mood: String,
    val postCaption: String,
    val hashtags: String,
    val lines: List<Cap>,
    val sections: List<Shot>
)
