package com.diracclip.app

import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.TextOverlay

/** Draws the caption active at the current time on a 1080x1920 frame. anchorY: -1 bottom ... 1 top. */
class CaptionOverlay(private val caps: List<Cap>, private val anchorY: Float) : TextOverlay() {

    override fun getText(presentationTimeUs: Long): SpannableString {
        val t = presentationTimeUs / 1_000_000.0
        val active = caps.firstOrNull { t >= it.start && t < it.end }
        val text = if (active == null || active.text.isBlank()) " " else wrap(active.text.trim())
        val s = SpannableString(text)
        s.setSpan(AbsoluteSizeSpan(62, false), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(StyleSpan(Typeface.BOLD), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(ForegroundColorSpan(Color.WHITE), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(BackgroundColorSpan(0xAA000000.toInt()), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return s
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        return OverlaySettings.Builder()
            .setBackgroundFrameAnchor(0f, anchorY)
            .build()
    }

    private fun wrap(text: String): String {
        val words = text.split(" ")
        val lines = ArrayList<String>()
        var cur = StringBuilder()
        for (w in words) {
            if (cur.isNotEmpty() && cur.length + 1 + w.length > 20) {
                lines.add(cur.toString())
                cur = StringBuilder()
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(w)
        }
        if (cur.isNotEmpty()) lines.add(cur.toString())
        return lines.joinToString("\n")
    }
}
