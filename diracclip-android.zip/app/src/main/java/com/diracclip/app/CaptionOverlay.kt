package com.diracclip.app

import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.TextOverlay

/**
 * Draws the caption active at the current time on a 1080x1920 frame. anchorY: -1 bottom ... 1 top.
 * kinetic = true: one big colourful word at a time that "pops" in on the beat (lyric-edit style).
 */
class CaptionOverlay(
    private val caps: List<Cap>,
    private val anchorY: Float,
    private val kinetic: Boolean = false
) : TextOverlay() {

    private val palette = intArrayOf(
        Color.parseColor("#FFE81A"), Color.parseColor("#22E0FF"), Color.parseColor("#FF2FD6"),
        Color.parseColor("#4DFF4D"), Color.parseColor("#FF8A1A"), Color.parseColor("#FF3B3B")
    )

    override fun getText(presentationTimeUs: Long): SpannableString {
        val t = presentationTimeUs / 1_000_000.0
        val idx = caps.indexOfFirst { t >= it.start && t < it.end }
        if (idx < 0 || caps[idx].text.isBlank()) return styled(" ", Color.WHITE, 62, false)
        val c = caps[idx]
        return if (kinetic) {
            styled(c.text.trim().uppercase(), palette[idx % palette.size], 118, true)
        } else {
            styled(wrap(c.text.trim()), Color.WHITE, 62, false)
        }
    }

    private fun styled(text: String, color: Int, size: Int, noBg: Boolean): SpannableString {
        val s = SpannableString(text)
        s.setSpan(AbsoluteSizeSpan(size, false), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(StyleSpan(Typeface.BOLD), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(ForegroundColorSpan(color), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (!noBg) s.setSpan(BackgroundColorSpan(0xAA000000.toInt()), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return s
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val b = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, anchorY)
        if (kinetic) {
            val t = presentationTimeUs / 1_000_000.0
            val c = caps.firstOrNull { t >= it.start && t < it.end }
            if (c != null) {
                val el = (t - c.start).toFloat()
                val s = 1f + 0.3f * maxOf(0f, 1f - el / 0.12f)
                b.setScale(s, s)
            }
        }
        return b.build()
    }

    private fun wrap(text: String): String {
        val words = text.split(" ")
        val lines = ArrayList<String>()
        var cur = StringBuilder()
        for (w in words) {
            if (cur.isNotEmpty() && cur.length + 1 + w.length > 20) {
                lines.add(cur.toString())
                cur = StringBuilder()
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(w)
        }
        if (cur.isNotEmpty()) lines.add(cur.toString())
        return lines.joinToString("\n")
    }
}
