package com.diracclip.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlaySettings

/**
 * One big word at a time with a black outline and a coloured glow that "pops" in on the beat
 * (lyric-edit style). Also used for the hook title (fixedColor = white, smaller size).
 */
class KineticOverlay(
    private val caps: List<Cap>,
    private val anchorY: Float,
    private val fixedColor: Int? = null,
    private val textSize: Float = 150f
) : BitmapOverlay() {

    private val palette = intArrayOf(
        Color.parseColor("#FFE81A"), Color.parseColor("#22E0FF"), Color.parseColor("#FF2FD6"),
        Color.parseColor("#4DFF4D"), Color.parseColor("#FF8A1A"), Color.parseColor("#FF3B3B")
    )
    private val cache = HashMap<Int, Bitmap>()
    private val blank: Bitmap = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888)

    private fun activeIdx(t: Double): Int = caps.indexOfFirst { t >= it.start && t < it.end }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val idx = activeIdx(presentationTimeUs / 1_000_000.0)
        if (idx < 0) return blank
        return cache.getOrPut(idx) {
            render(caps[idx].text.trim().uppercase(), fixedColor ?: palette[idx % palette.size])
        }
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val b = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, anchorY)
        val t = presentationTimeUs / 1_000_000.0
        val idx = activeIdx(t)
        if (idx >= 0) {
            val el = (t - caps[idx].start).toFloat()
            val s = 1f + 0.28f * maxOf(0f, 1f - el / 0.1f)
            b.setScale(s, s)
        }
        return b.build()
    }

    private fun render(text: String, color: Int): Bitmap {
        var size = textSize
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        fill.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        fill.textSize = size
        fill.color = color
        var w = fill.measureText(text)
        if (w > 940f) {
            size *= 940f / w
            fill.textSize = size
            w = fill.measureText(text)
        }
        val pad = 60
        val bw = (w + pad * 2).toInt().coerceAtLeast(10)
        val bh = (size * 1.55f).toInt().coerceAtLeast(10)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val base = size * 1.1f
        val glow = Paint(fill)
        glow.setShadowLayer(size * 0.28f, 0f, 0f, color)
        c.drawText(text, pad.toFloat(), base, glow)
        val stroke = Paint(fill)
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = size * 0.14f
        stroke.strokeJoin = Paint.Join.ROUND
        stroke.color = Color.BLACK
        c.drawText(text, pad.toFloat(), base, stroke)
        c.drawText(text, pad.toFloat(), base, fill)
        return bmp
    }
}
