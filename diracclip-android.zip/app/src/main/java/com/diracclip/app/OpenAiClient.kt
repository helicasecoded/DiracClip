package com.diracclip.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.DataOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Minimal client for OpenAI-compatible APIs (xAI, Groq, OpenRouter, OpenAI, Cerebras). */
object OpenAiClient {

    class MInfo(val id: String, val free: Boolean, val vision: Boolean)

    private fun read(c: HttpURLConnection, code: Int): String {
        val s = if (code in 200..299) c.inputStream else c.errorStream
        return s?.bufferedReader()?.use { it.readText() } ?: ""
    }

    private fun fail(code: Int, body: String, what: String): Nothing {
        if (code == 429 || (body.contains("quota", ignoreCase = true) && code != 401)) {
            throw QuotaException("$what limit reached ($code): ${body.take(200)}")
        }
        throw ApiException("$what failed ($code): ${body.take(300)}")
    }

    fun listModelInfos(base: String, key: String, p: Provider): List<MInfo> {
        val c = URL("$base/models").openConnection() as HttpURLConnection
        c.setRequestProperty("Authorization", "Bearer $key")
        c.connectTimeout = 30000
        c.readTimeout = 60000
        val code = c.responseCode
        val body = read(c, code)
        c.disconnect()
        if (code !in 200..299) fail(code, body, "Model list")
        val arr = JSONObject(body).optJSONArray("data") ?: return emptyList()
        val out = ArrayList<MInfo>()
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val id = m.optString("id")
            if (id.isEmpty()) continue
            var free = true
            var vision = id.contains("vision", true) || id.contains("-vl", true) || id.contains("llama-4", true) ||
                id.contains("grok-4", true) || id.contains("gpt-4o", true) || id.contains("gpt-4.1", true) || id.contains("gemma-3", true)
            if (p == Provider.OPENROUTER) {
                val pr = m.optJSONObject("pricing")
                free = id.endsWith(":free") ||
                    (pr != null && pr.optString("prompt") == "0" && pr.optString("completion") == "0")
                val mods = m.optJSONObject("architecture")?.optJSONArray("input_modalities")
                if (mods != null) {
                    vision = false
                    for (k in 0 until mods.length()) if (mods.optString(k) == "image") vision = true
                }
            }
            out.add(MInfo(id, free, vision))
        }
        return out
    }

    fun pickSttModel(ids: List<String>): String? {
        return ids.firstOrNull { it.contains("whisper-large-v3-turbo") }
            ?: ids.firstOrNull { it.contains("whisper-large-v3") }
            ?: ids.firstOrNull { it.contains("whisper") }
    }

    /** Speech-to-text. Returns segments (start, end, text) in absolute seconds (offset added). */
    fun transcribe(base: String, key: String, model: String, wav: File, offset: Double): List<Triple<Double, Double, String>> {
        val boundary = "----dirac" + System.currentTimeMillis()
        val c = URL("$base/audio/transcriptions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 30000
        c.readTimeout = 300000
        c.setChunkedStreamingMode(64 * 1024)
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        val out = DataOutputStream(c.outputStream)
        fun field(name: String, value: String) {
            out.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n")
        }
        field("model", model)
        field("response_format", "verbose_json")
        field("temperature", "0")
        out.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\nContent-Type: audio/wav\r\n\r\n")
        wav.inputStream().use { it.copyTo(out) }
        out.writeBytes("\r\n--$boundary--\r\n")
        out.flush()
        out.close()
        val code = c.responseCode
        val body = read(c, code)
        c.disconnect()
        if (code !in 200..299) fail(code, body, "Transcription")
        val j = JSONObject(body)
        val res = ArrayList<Triple<Double, Double, String>>()
        val segs: JSONArray? = j.optJSONArray("segments")
        if (segs != null) {
            for (i in 0 until segs.length()) {
                val s = segs.getJSONObject(i)
                val t = s.optString("text", "").trim()
                if (t.isNotEmpty()) res.add(Triple(offset + s.optDouble("start", 0.0), offset + s.optDouble("end", 0.0), t))
            }
        } else {
            val t = j.optString("text", "").trim()
            if (t.isNotEmpty()) res.add(Triple(offset, offset + 30.0, t))
        }
        return res
    }

    fun chat(base: String, key: String, model: String, prompt: String, log: (String) -> Unit): String {
        return completion(base, key, model, JSONArray().put(JSONObject().put("type", "text").put("text", prompt)), log, true)
    }

    fun chatVision(base: String, key: String, model: String, prompt: String, images: List<ByteArray>, log: (String) -> Unit): String {
        val content = JSONArray()
        content.put(JSONObject().put("type", "text").put("text", prompt))
        for (img in images) {
            val b64 = android.util.Base64.encodeToString(img, android.util.Base64.NO_WRAP)
            content.put(
                JSONObject().put("type", "image_url")
                    .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))
            )
        }
        return completion(base, key, model, content, log, true)
    }

    private fun completion(base: String, key: String, model: String, content: JSONArray, log: (String) -> Unit, firstJson: Boolean): String {
        var jsonMode = firstJson
        var tries = 0
        while (tries < 2) {
            tries++
            val body = JSONObject()
            body.put("model", model)
            body.put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
            body.put("temperature", 0.3)
            body.put("max_tokens", 8000)
            if (jsonMode) body.put("response_format", JSONObject().put("type", "json_object"))
            val c = URL("$base/chat/completions").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 30000
            c.readTimeout = 240000
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val resp = read(c, code)
            c.disconnect()
            if (code in 200..299) {
                val choices = JSONObject(resp).optJSONArray("choices")
                    ?: throw ApiException("Empty response from $model")
                val msg = choices.getJSONObject(0).optJSONObject("message")
                val text = msg?.optString("content", "") ?: ""
                if (text.isBlank()) throw ApiException("Empty response from $model")
                return text
            }
            val retryable = code == 400 && jsonMode && (
                resp.contains("response_format", true) || resp.contains("failed_generation", true) ||
                    resp.contains("validate JSON", true) || resp.contains("json_object", true)
                )
            if (retryable) {
                jsonMode = false
                log("JSON mode failed for $model; retrying without it...")
                continue
            }
            fail(code, resp, "Chat")
        }
        throw ApiException("Chat request failed")
    }
}
