package com.diracclip.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.DataOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Minimal client for OpenAI-compatible APIs (xAI, Groq, OpenRouter, OpenAI, Cerebras). */
object OpenAiClient {

    private fun read(c: HttpURLConnection, code: Int): String {
        val s = if (code in 200..299) c.inputStream else c.errorStream
        return s?.bufferedReader()?.use { it.readText() } ?: ""
    }

    private fun fail(code: Int, body: String, what: String): Nothing {
        if (code == 429 || body.contains("quota", ignoreCase = true) && code != 401) {
            throw QuotaException("$what limit reached ($code): ${body.take(200)}")
        }
        throw ApiException("$what failed ($code): ${body.take(300)}")
    }

    fun listModels(base: String, key: String): List<String> {
        val c = URL("$base/models").openConnection() as HttpURLConnection
        c.setRequestProperty("Authorization", "Bearer $key")
        c.connectTimeout = 30000
        c.readTimeout = 60000
        val code = c.responseCode
        val body = read(c, code)
        c.disconnect()
        if (code !in 200..299) fail(code, body, "Model list")
        val arr = JSONObject(body).optJSONArray("data") ?: return emptyList()
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) out.add(arr.getJSONObject(i).optString("id"))
        return out.filter { it.isNotEmpty() }
    }

    fun pickChatModel(p: Provider, ids: List<String>): String? {
        val bad = listOf("whisper", "tts", "guard", "embed", "image", "imagine", "video", "vision", "audio", "moderation", "transcribe")
        val chat = ids.filter { id -> bad.none { id.contains(it, ignoreCase = true) } }
        if (chat.isEmpty()) return null
        val prefs: List<String> = when (p) {
            Provider.XAI -> listOf("fast", "grok-4", "grok")
            Provider.GROQ -> listOf("llama-3.3-70b", "70b", "120b", "llama")
            Provider.OPENROUTER -> listOf(":free")
            Provider.OPENAI -> listOf("mini", "gpt")
            Provider.CEREBRAS -> listOf("70b", "120b", "llama", "gpt-oss")
            else -> emptyList()
        }
        for (pref in prefs) {
            val hit = chat.firstOrNull { it.contains(pref, ignoreCase = true) }
            if (hit != null) return hit
        }
        return chat[0]
    }

    fun pickSttModel(ids: List<String>): String? {
        return ids.firstOrNull { it.contains("whisper-large-v3-turbo") }
            ?: ids.firstOrNull { it.contains("whisper") }
    }

    /** Speech-to-text. Returns segments (start, end, text) in absolute seconds (offset added). */
    fun transcribe(base: String, key: String, model: String, wav: File, offset: Double): List<Triple<Double, Double, String>> {
        val boundary = "----dirac" + System.currentTimeMillis()
        val c = URL("$base/audio/transcriptions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 30000
        c.readTimeout = 300000
        c.setChunkedStreamingMode(64 * 1024)
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        val out = DataOutputStream(c.outputStream)
        fun field(name: String, value: String) {
            out.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n")
        }
        field("model", model)
        field("response_format", "verbose_json")
        field("temperature", "0")
        out.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\nContent-Type: audio/wav\r\n\r\n")
        wav.inputStream().use { it.copyTo(out) }
        out.writeBytes("\r\n--$boundary--\r\n")
        out.flush()
        out.close()
        val code = c.responseCode
        val body = read(c, code)
        c.disconnect()
        if (code !in 200..299) fail(code, body, "Transcription")
        val j = JSONObject(body)
        val res = ArrayList<Triple<Double, Double, String>>()
        val segs: JSONArray? = j.optJSONArray("segments")
        if (segs != null) {
            for (i in 0 until segs.length()) {
                val s = segs.getJSONObject(i)
                val t = s.optString("text", "").trim()
                if (t.isNotEmpty()) res.add(Triple(offset + s.optDouble("start", 0.0), offset + s.optDouble("end", 0.0), t))
            }
        } else {
            val t = j.optString("text", "").trim()
            if (t.isNotEmpty()) res.add(Triple(offset, offset + 30.0, t))
        }
        return res
    }

    /** Chat completion, JSON output requested. */
    fun chat(base: String, key: String, model: String, prompt: String, log: (String) -> Unit): String {
        var jsonMode = true
        var tries = 0
        while (tries < 2) {
            tries++
            val body = JSONObject()
            body.put("model", model)
            body.put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            body.put("temperature", 0.3)
            if (jsonMode) body.put("response_format", JSONObject().put("type", "json_object"))
            val c = URL("$base/chat/completions").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 30000
            c.readTimeout = 240000
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val resp = read(c, code)
            c.disconnect()
            if (code in 200..299) {
                val choices = JSONObject(resp).optJSONArray("choices")
                    ?: throw ApiException("Empty response from $model")
                return choices.getJSONObject(0).getJSONObject("message").optString("content", "")
            }
            if (code == 400 && jsonMode && resp.contains("response_format", ignoreCase = true)) {
                jsonMode = false
                log("JSON mode not supported by this model; retrying without it...")
                continue
            }
            fail(code, resp, "Chat")
        }
        throw ApiException("Chat request failed")
    }
}
