package com.diracclip.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.ByteArrayOutputStream

/** Contact sheets (grids of timestamped frames) so any vision model can "watch" a video. */
object FrameSheets {
    class Sheet(val jpeg: ByteArray, val tStart: Double, val tEnd: Double)

    fun make(ctx: Context, src: Uri, durationSec: Double, stepSec: Double, cols: Int, rows: Int): List<Sheet> {
        val r = MediaMetadataRetriever()
        r.setDataSource(ctx, src)
        try {
            val per = cols * rows
            val times = ArrayList<Double>()
            var t = 0.5
            while (t < durationSec) {
                times.add(t)
                t += stepSec
            }
            val tileW = 320
            val sheets = ArrayList<Sheet>()
            val txt = Paint()
            txt.color = Color.WHITE
            txt.textSize = 24f
            txt.isAntiAlias = true
            val outline = Paint(txt)
            outline.color = Color.BLACK
            outline.style = Paint.Style.STROKE
            outline.strokeWidth = 5f
            var i = 0
            while (i < times.size) {
                val group = times.subList(i, minOf(times.size, i + per))
                val tiles = ArrayList<Pair<Double, Bitmap>>()
                for (time in group) {
                    val f = r.getFrameAtTime((time * 1_000_000).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
                    val h = maxOf(1, tileW * f.height / maxOf(1, f.width))
                    val s = Bitmap.createScaledBitmap(f, tileW, h, true)
                    if (s !== f) f.recycle()
                    tiles.add(Pair(time, s))
                }
                if (tiles.isNotEmpty()) {
                    val tileH = tiles[0].second.height
                    val sheet = Bitmap.createBitmap(cols * tileW, rows * tileH, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(sheet)
                    canvas.drawColor(Color.BLACK)
                    for ((n, p) in tiles.withIndex()) {
                        val cx = (n % cols) * tileW
                        val cy = (n / cols) * tileH
                        canvas.drawBitmap(p.second, cx.toFloat(), cy.toFloat(), null)
                        val label = "${p.first.toInt()}s"
                        canvas.drawText(label, cx + 8f, cy + 28f, outline)
                        canvas.drawText(label, cx + 8f, cy + 28f, txt)
                        p.second.recycle()
                    }
                    val bos = ByteArrayOutputStream()
                    sheet.compress(Bitmap.CompressFormat.JPEG, 72, bos)
                    sheet.recycle()
                    sheets.add(Sheet(bos.toByteArray(), group.first(), group.last()))
                }
                i += per
            }
            return sheets
        } finally {
            r.release()
        }
    }
}
