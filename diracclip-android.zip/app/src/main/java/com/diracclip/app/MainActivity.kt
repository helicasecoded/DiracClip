package com.diracclip.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch

class MainActivity : Activity() {

    private val reqPick = 11
    private var pickedUri: Uri? = null

    private lateinit var scroll: ScrollView
    private lateinit var keyField: EditText
    private lateinit var modelField: EditText
    private lateinit var countField: EditText
    private lateinit var minField: EditText
    private lateinit var maxField: EditText
    private lateinit var capBox: CheckBox
    private lateinit var fitBox: CheckBox
    private lateinit var urlField: EditText
    private lateinit var pickedLabel: TextView
    private lateinit var startBtn: Button
    private lateinit var logView: TextView
    private lateinit var resultsBox: LinearLayout

    @Volatile
    private var running = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun field(hint: String, value: String, numeric: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.setSingleLine(true)
        if (numeric) e.inputType = InputType.TYPE_CLASS_NUMBER
        return e
    }

    private fun label(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 13f
        t.setTextColor(Color.DKGRAY)
        t.setPadding(0, dp(12), 0, 0)
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val prefs = getSharedPreferences("dirac", MODE_PRIVATE)

        scroll = ScrollView(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(36), dp(20), dp(40))
        scroll.addView(root)

        val title = TextView(this)
        title.text = "DiracClip"
        title.textSize = 28f
        title.setTextColor(Color.rgb(255, 106, 0))
        root.addView(title)

        val sub = TextView(this)
        sub.text = "Video chuno, AI best moments dhoondhega, aur 9:16 clips captions ke saath ban jayengi."
        sub.textSize = 14f
        root.addView(sub)

        root.addView(label("Gemini API key"))
        keyField = field("AIza...", prefs.getString("key", "") ?: "")
        root.addView(keyField)

        root.addView(label("Gemini model"))
        modelField = field("gemini-flash-latest", prefs.getString("model", "gemini-flash-latest") ?: "gemini-flash-latest")
        root.addView(modelField)

        root.addView(label("Kitni clips chahiye"))
        countField = field("5", prefs.getString("count", "5") ?: "5", true)
        root.addView(countField)

        root.addView(label("Clip length (seconds): minimum aur maximum"))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        minField = field("30", prefs.getString("min", "30") ?: "30", true)
        maxField = field("60", prefs.getString("max", "60") ?: "60", true)
        row.addView(minField, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(maxField, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row)

        capBox = CheckBox(this)
        capBox.text = "Captions lagao"
        capBox.isChecked = prefs.getBoolean("caps", true)
        root.addView(capBox)

        fitBox = CheckBox(this)
        fitBox.text = "Poora video dikhao (zoom nahi, upar-neeche kaali patti)"
        fitBox.isChecked = prefs.getBoolean("fit", false)
        root.addView(fitBox)

        val pickBtn = Button(this)
        pickBtn.text = "Video chuno (gallery / files)"
        pickBtn.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "video/*"
            startActivityForResult(i, reqPick)
        }
        root.addView(pickBtn)

        pickedLabel = TextView(this)
        pickedLabel.text = "Koi video nahi chuna"
        root.addView(pickedLabel)

        root.addView(label("Ya direct video link (.mp4). YouTube link is version me support nahi hai."))
        urlField = field("https://...", "")
        root.addView(urlField)

        startBtn = Button(this)
        startBtn.text = "Clips banao"
        startBtn.setOnClickListener { start() }
        root.addView(startBtn)

        resultsBox = LinearLayout(this)
        resultsBox.orientation = LinearLayout.VERTICAL
        root.addView(resultsBox)

        logView = TextView(this)
        logView.textSize = 12f
        logView.setPadding(0, dp(16), 0, 0)
        logView.setTextIsSelectable(true)
        root.addView(logView)

        setContentView(scroll)

        if (intent?.action == Intent.ACTION_SEND) {
            val u = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            if (u != null) setPicked(u)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqPick && resultCode == RESULT_OK) {
            val u = data?.data
            if (u != null) setPicked(u)
        }
    }

    private fun setPicked(u: Uri) {
        pickedUri = u
        var name = u.lastPathSegment ?: u.toString()
        try {
            contentResolver.query(u, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) name = c.getString(idx)
            }
        } catch (e: Exception) {
        }
        pickedLabel.text = "Chuna hua: $name"
    }

    private fun log(msg: String) {
        runOnUiThread {
            logView.append(msg + "\n")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun start() {
        if (running) return
        val key = keyField.text.toString().trim()
        if (key.isEmpty()) {
            Toast.makeText(this, "Pehle Gemini API key daalo", Toast.LENGTH_LONG).show()
            return
        }
        val urlText = urlField.text.toString().trim()
        if (pickedUri == null && urlText.isEmpty()) {
            Toast.makeText(this, "Video chuno ya direct link daalo", Toast.LENGTH_LONG).show()
            return
        }
        if (pickedUri == null && (urlText.contains("youtube.com") || urlText.contains("youtu.be"))) {
            log("YouTube link se download is version me nahi hota. Video khud download karke 'Video chuno' se do.")
            return
        }
        val model = modelField.text.toString().trim().ifEmpty { "gemini-flash-latest" }
        val count = countField.text.toString().toIntOrNull()?.coerceIn(1, 15) ?: 5
        val minSec = minField.text.toString().toIntOrNull()?.coerceIn(5, 300) ?: 30
        val maxSec = (maxField.text.toString().toIntOrNull() ?: 60).coerceIn(minSec, 600)
        val caps = capBox.isChecked
        val fit = fitBox.isChecked

        getSharedPreferences("dirac", MODE_PRIVATE).edit()
            .putString("key", key).putString("model", model)
            .putString("count", count.toString()).putString("min", minSec.toString())
            .putString("max", maxSec.toString()).putBoolean("caps", caps).putBoolean("fit", fit).apply()

        running = true
        startBtn.isEnabled = false
        resultsBox.removeAllViews()
        logView.text = ""
        val picked = pickedUri

        Thread {
            try {
                pipeline(key, model, count, minSec, maxSec, caps, fit, picked, urlText)
            } catch (e: Throwable) {
                log("ERROR: ${e.message ?: e.toString()}")
            } finally {
                running = false
                runOnUiThread { startBtn.isEnabled = true }
            }
        }.start()
    }

    private fun pipeline(
        key: String, model: String, count: Int, minSec: Int, maxSec: Int,
        withCaps: Boolean, fit: Boolean, picked: Uri?, urlText: String
    ) {
        val work = File(cacheDir, "work")
        work.deleteRecursively()
        work.mkdirs()

        val src: Uri = picked ?: run {
            log("Video download ho raha hai...")
            val f = File(work, "source.mp4")
            download(urlText, f)
            Uri.fromFile(f)
        }

        val durationSec = durationOf(src)
        if (durationSec <= 0) throw ApiException("Video ki length nahi mil payi. Dusra video try karo.")
        log("Video length: ${(durationSec / 60).toInt()} min ${(durationSec % 60).toInt()} sec")

        // 1) Audio nikalo -> 16kHz mono WAV (Gemini ka supported format)
        log("Audio nikal raha hu (video lamba ho to time lagega)...")
        val audioFile = File(work, "audio.wav")
        extractWav(src, audioFile, durationSec)
        log("Audio ready (${audioFile.length() / 1024 / 1024} MB)")

        // 2) Gemini: upload + highlights + captions
        val up = GeminiClient.uploadFile(key, audioFile, "audio/wav") { log(it) }
        log("AI best moments dhoondh raha hai ($model)...")
        val raw = GeminiClient.generate(
            key, model, up.second, "audio/wav",
            GeminiClient.buildPrompt(count, minSec, maxSec, withCaps)
        ) { log(it) }
        val plans = try {
            GeminiClient.parsePlans(raw, durationSec, minSec)
        } catch (e: Exception) {
            throw ApiException("AI ka jawab samajh nahi aaya: ${raw.take(300)}")
        }
        if (plans.isEmpty()) throw ApiException("AI ko koi clip nahi mili. Dusra video ya model try karo.")
        log("${plans.size} clips mili. Ab render ho rahi hain...")

        // 3) Har clip render karo
        val stamp = System.currentTimeMillis()
        for ((i, p) in plans.withIndex()) {
            log("Clip ${i + 1}/${plans.size}: ${p.title} (${(p.end - p.start).toInt()}s)")
            val out = File(work, "clip_$i.mp4")
            val clipping = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs((p.start * 1000).toLong())
                .setEndPositionMs((p.end * 1000).toLong())
                .build()
            val mi = MediaItem.Builder().setUri(src).setClippingConfiguration(clipping).build()
            val effects = ArrayList<Effect>()
            effects.add(Presentation.createForWidthAndHeight(
                1080, 1920,
                if (fit) Presentation.LAYOUT_SCALE_TO_FIT else Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
            ))
            if (withCaps && p.caps.isNotEmpty()) {
                effects.add(OverlayEffect(ImmutableList.of<TextureOverlay>(CaptionOverlay(p.caps))))
            }
            val edited = EditedMediaItem.Builder(mi)
                .setEffects(Effects(emptyList<AudioProcessor>(), effects))
                .build()
            val err = exportBlocking(edited, out.path) { b ->
                b.setVideoMimeType(MimeTypes.VIDEO_H264)
                b.setAudioMimeType(MimeTypes.AUDIO_AAC)
                b.setEncoderFactory(
                    DefaultEncoderFactory.Builder(this)
                        .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(6_000_000).build())
                        .setEnableFallback(true)
                        .build()
                )
            }
            if (err != null) {
                log("Clip ${i + 1} fail: $err")
                continue
            }
            val saved = saveToGallery(out, "DiracClip_${stamp}_${i + 1}.mp4")
            if (saved != null) {
                log("Clip ${i + 1} save ho gayi (Movies/DiracClip)")
                addResult(p.title, saved)
            } else {
                log("Clip ${i + 1} save nahi ho payi")
            }
        }
        log("Ho gaya! Clips gallery me Movies/DiracClip folder me hain.")
    }

    private fun extractWav(src: Uri, out: File, durationSec: Double) {
        val ex = MediaExtractor()
        ex.setDataSource(this, src, null)
        var track = -1
        for (i in 0 until ex.trackCount) {
            val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
            if (m.startsWith("audio/")) {
                track = i
                break
            }
        }
        if (track < 0) {
            ex.release()
            throw ApiException("Is video me audio track nahi mili.")
        }
        ex.selectTrack(track)
        val fmt = ex.getTrackFormat(track)
        val mime = fmt.getString(MediaFormat.KEY_MIME)!!
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()

        var srcRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = maxOf(1, fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
        var isFloat = false
        val outRate = 16000
        val raf = RandomAccessFile(out, "rw")
        raf.setLength(0)
        raf.write(ByteArray(44))
        val outBuf = ByteBuffer.allocate(64 * 1024).order(ByteOrder.LITTLE_ENDIAN)
        var dataLen = 0L
        var pos = 1.0
        var prev = 0f
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        var lastPct = -25
        try {
            while (!outputDone) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val ib = codec.getInputBuffer(ii)!!
                        val n = ex.readSampleData(ib, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10000)
                if (oi >= 0) {
                    if (info.size > 0) {
                        val ob = codec.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        ob.order(ByteOrder.LITTLE_ENDIAN)
                        val frames: Int
                        val mono: FloatArray
                        if (isFloat) {
                            val fb = ob.asFloatBuffer()
                            frames = fb.remaining() / channels
                            mono = FloatArray(frames)
                            for (f in 0 until frames) {
                                var sum = 0f
                                for (c in 0 until channels) sum += fb.get() * 32768f
                                mono[f] = sum / channels
                            }
                        } else {
                            val sb = ob.asShortBuffer()
                            frames = sb.remaining() / channels
                            mono = FloatArray(frames)
                            for (f in 0 until frames) {
                                var sum = 0f
                                for (c in 0 until channels) sum += sb.get().toFloat()
                                mono[f] = sum / channels
                            }
                        }
                        val e = FloatArray(frames + 1)
                        e[0] = prev
                        System.arraycopy(mono, 0, e, 1, frames)
                        val step = srcRate.toDouble() / outRate
                        while (pos <= frames.toDouble()) {
                            val i0 = pos.toInt()
                            val frac = (pos - i0).toFloat()
                            val a = e[i0]
                            val b = if (i0 + 1 <= frames) e[i0 + 1] else a
                            var v = a + (b - a) * frac
                            if (v > 32767f) v = 32767f
                            if (v < -32768f) v = -32768f
                            if (outBuf.remaining() < 2) {
                                raf.write(outBuf.array(), 0, outBuf.position())
                                dataLen += outBuf.position()
                                outBuf.clear()
                            }
                            outBuf.putShort(v.toInt().toShort())
                            pos += step
                        }
                        pos -= frames.toDouble()
                        if (frames > 0) prev = e[frames]
                        if (durationSec > 0) {
                            val pct = ((info.presentationTimeUs / 1_000_000.0) / durationSec * 100).toInt()
                            if (pct >= lastPct + 25) {
                                lastPct = pct
                                log("Audio $pct%")
                            }
                        }
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    srcRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = maxOf(1, of.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
                    isFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                }
            }
            if (outBuf.position() > 0) {
                raf.write(outBuf.array(), 0, outBuf.position())
                dataLen += outBuf.position()
            }
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray())
            h.putInt((36 + dataLen).toInt())
            h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray())
            h.putInt(16)
            h.putShort(1)
            h.putShort(1)
            h.putInt(outRate)
            h.putInt(outRate * 2)
            h.putShort(2)
            h.putShort(16)
            h.put("data".toByteArray())
            h.putInt(dataLen.toInt())
            raf.seek(0)
            raf.write(h.array())
        } finally {
            try {
                codec.stop()
            } catch (e: Exception) {
            }
            codec.release()
            ex.release()
            raf.close()
        }
    }

    private fun addResult(title: String, uri: Uri) {
        runOnUiThread {
            val b = Button(this)
            b.text = "Chalao: $title"
            b.isAllCaps = false
            b.setOnClickListener {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(uri, "video/mp4")
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                try {
                    startActivity(i)
                } catch (e: Exception) {
                    Toast.makeText(this, "Gallery me Movies/DiracClip dekho", Toast.LENGTH_LONG).show()
                }
            }
            resultsBox.addView(b)
        }
    }

    private fun exportBlocking(
        edited: EditedMediaItem,
        outPath: String,
        configure: (Transformer.Builder) -> Unit
    ): String? {
        val latch = CountDownLatch(1)
        var error: String? = null
        runOnUiThread {
            try {
                val b = Transformer.Builder(this)
                configure(b)
                b.addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        latch.countDown()
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        error = exportException.message ?: exportException.errorCodeName
                        latch.countDown()
                    }
                })
                b.build().start(edited, outPath)
            } catch (e: Exception) {
                error = e.message ?: e.toString()
                latch.countDown()
            }
        }
        latch.await()
        return error
    }

    private fun durationOf(uri: Uri): Double {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, uri)
            val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            return ms / 1000.0
        } finally {
            r.release()
        }
    }

    private fun download(url: String, dest: File) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = true
        c.connectTimeout = 30000
        c.readTimeout = 60000
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        if (c.responseCode !in 200..299) throw ApiException("Download fail (${c.responseCode})")
        val total = c.contentLengthLong
        var done = 0L
        var lastPct = -10
        c.inputStream.use { input ->
            dest.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val pct = (done * 100 / total).toInt()
                        if (pct >= lastPct + 10) {
                            lastPct = pct
                            log("Download $pct%")
                        }
                    }
                }
            }
        }
        c.disconnect()
    }

    private fun saveToGallery(file: File, name: String): Uri? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues()
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                values.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/DiracClip")
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { o ->
                        file.inputStream().use { it.copyTo(o) }
                    }
                }
                uri
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                dir?.mkdirs()
                val f = File(dir, name)
                file.copyTo(f, true)
                Uri.fromFile(f)
            }
        } catch (e: Exception) {
            log("Save error: ${e.message}")
            null
        }
    }
}
