package com.diracclip.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.text.method.PasswordTransformationMethod
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CountDownLatch

class MainActivity : Activity() {

    private val reqPick = 11
    private val reqMusic = 12
    private var pickedUri: Uri? = null
    private var pickedMusic: Uri? = null

    private val cBg = Color.parseColor("#0E1013")
    private val cCard = Color.parseColor("#181B20")
    private val cField = Color.parseColor("#20242B")
    private val cStroke = Color.parseColor("#2A2F37")
    private val cText = Color.parseColor("#F2F4F7")
    private val cMuted = Color.parseColor("#9AA3AF")
    private val cAccent = Color.parseColor("#FF6A00")

    private lateinit var scroll: ScrollView
    private lateinit var keyField: EditText
    private lateinit var keysInfo: TextView
    private lateinit var modelField: EditText
    private lateinit var countField: EditText
    private lateinit var minField: EditText
    private lateinit var maxField: EditText
    private lateinit var scoreField: EditText
    private lateinit var capBox: CheckBox
    private lateinit var trimBox: CheckBox
    private lateinit var fitBox: CheckBox
    private lateinit var titleBox: CheckBox
    private lateinit var slowBox: CheckBox
    private lateinit var beatBox: CheckBox
    private lateinit var typeGroup: RadioGroup
    private lateinit var sideGroup: RadioGroup
    private lateinit var langGroup: RadioGroup
    private lateinit var sideBlock: LinearLayout
    private lateinit var pickedLabel: TextView
    private lateinit var musicLabel: TextView
    private lateinit var startBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var resultsCard: LinearLayout

    @Volatile
    private var running = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radius: Int, stroke: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = dp(radius).toFloat()
        if (stroke != 0) d.setStroke(dp(1), stroke)
        return d
    }

    private fun card(parent: LinearLayout, title: String?): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(16))
        c.background = rounded(cCard, 16, cStroke)
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        parent.addView(c, lp)
        if (title != null) {
            val t = TextView(this)
            t.text = title
            t.textSize = 15f
            t.typeface = Typeface.DEFAULT_BOLD
            t.setTextColor(cText)
            t.setPadding(0, 0, 0, dp(8))
            c.addView(t)
        }
        return c
    }

    private fun muted(text: String, size: Float = 12f): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(cMuted)
        t.setPadding(0, dp(4), 0, dp(4))
        return t
    }

    private fun input(hint: String, value: String, numeric: Boolean = false, secret: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.setTextColor(cText)
        e.setHintTextColor(cMuted)
        e.textSize = 15f
        e.background = rounded(cField, 10, cStroke)
        e.setPadding(dp(14), dp(12), dp(14), dp(12))
        e.inputType = when {
            numeric -> InputType.TYPE_CLASS_NUMBER
            secret -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            else -> InputType.TYPE_CLASS_TEXT
        }
        return e
    }

    private fun labeled(label: String, v: View): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.addView(muted(label))
        l.addView(v)
        return l
    }

    private fun primaryButton(text: String): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 16f
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(Color.WHITE)
        b.background = rounded(cAccent, 14)
        b.stateListAnimator = null
        b.setPadding(dp(16), dp(14), dp(16), dp(14))
        return b
    }

    private fun ghostButton(text: String): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 14f
        b.setTextColor(cAccent)
        b.background = rounded(Color.TRANSPARENT, 12, cAccent)
        b.stateListAnimator = null
        b.setPadding(dp(14), dp(10), dp(14), dp(10))
        return b
    }

    private fun check(text: String, checked: Boolean): CheckBox {
        val c = CheckBox(this)
        c.text = text
        c.textSize = 14f
        c.setTextColor(cText)
        c.isChecked = checked
        c.buttonTintList = ColorStateList.valueOf(cAccent)
        return c
    }

    private fun radioGroup(options: List<String>, selected: Int): RadioGroup {
        val g = RadioGroup(this)
        g.orientation = RadioGroup.VERTICAL
        for ((i, name) in options.withIndex()) {
            val r = RadioButton(this)
            r.id = 1000 + i
            r.text = name
            r.textSize = 14f
            r.setTextColor(cText)
            r.buttonTintList = ColorStateList.valueOf(cAccent)
            r.setPadding(dp(6), dp(8), dp(6), dp(8))
            g.addView(r)
        }
        g.check(1000 + selected)
        return g
    }

    private fun selected(g: RadioGroup): Int = g.checkedRadioButtonId - 1000

    private fun fileName(u: Uri): String {
        var name = u.lastPathSegment ?: u.toString()
        try {
            contentResolver.query(u, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) name = c.getString(idx)
            }
        } catch (e: Exception) {
        }
        return name
    }

    private fun updateVisibility() {
        val type = selected(typeGroup)
        sideBlock.visibility = if (type == 2) View.VISIBLE else View.GONE
        fitBox.visibility = if (type == 0) View.VISIBLE else View.GONE
        slowBox.visibility = if (type == 3) View.VISIBLE else View.GONE
        trimBox.visibility = if (type == 3) View.GONE else View.VISIBLE
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        val prefs = getSharedPreferences("dirac", MODE_PRIVATE)

        scroll = ScrollView(this)
        scroll.setBackgroundColor(cBg)
        scroll.isFillViewport = true
        val outer = LinearLayout(this)
        outer.orientation = LinearLayout.VERTICAL
        outer.gravity = Gravity.CENTER_HORIZONTAL
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(28), dp(16), dp(32))
        val colW = minOf(resources.displayMetrics.widthPixels, dp(640))
        outer.addView(col, LinearLayout.LayoutParams(colW, LinearLayout.LayoutParams.WRAP_CONTENT))
        scroll.addView(outer)

        // Header
        val title = TextView(this)
        title.text = "DiracClip"
        title.textSize = 30f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(cAccent)
        col.addView(title)
        val sub = muted("AI editor for viral clips: best moments, beat-synced cuts, slow motion and music mixing.", 13f)
        sub.setPadding(0, 0, 0, dp(16))
        col.addView(sub)

        // 1. Video
        val cVideo = card(col, "1. Video")
        val pickBtn = primaryButton("Select video")
        pickBtn.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "video/*"
            startActivityForResult(i, reqPick)
        }
        cVideo.addView(pickBtn)
        pickedLabel = muted("No video selected (max 1 hour)")
        cVideo.addView(pickedLabel)

        // 2. Type
        val cType = card(col, "2. Video type")
        typeGroup = radioGroup(
            listOf(
                "Talking video (vlog, education, commentary)",
                "Game stream (gameplay on top, streamer facecam below)",
                "Podcast / interview (2 people)",
                "Gameplay recording (no commentary): COD, GTA, any game"
            ),
            prefs.getInt("type", 3)
        )
        typeGroup.setOnCheckedChangeListener { _, _ -> updateVisibility() }
        cType.addView(typeGroup)

        // 3. Music
        val cMusic = card(col, "3. Background music (optional)")
        cMusic.addView(muted("With music: game audio 60% + music 40%, and cuts land on the beat. Without music: the clip keeps its raw game audio."))
        val mRow = LinearLayout(this)
        mRow.orientation = LinearLayout.HORIZONTAL
        val musicBtn = ghostButton("Select music")
        musicBtn.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "audio/*"
            startActivityForResult(i, reqMusic)
        }
        val clearBtn = ghostButton("Remove")
        clearBtn.setOnClickListener {
            pickedMusic = null
            musicLabel.text = "No music selected (raw audio)"
        }
        mRow.addView(musicBtn)
        val clp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        clp.leftMargin = dp(10)
        mRow.addView(clearBtn, clp)
        cMusic.addView(mRow)
        musicLabel = muted("No music selected (raw audio)")
        cMusic.addView(musicLabel)
        beatBox = check("Sync cuts to the music beat", prefs.getBoolean("beat", true))
        cMusic.addView(beatBox)

        // 4. Edit options
        val cEdit = card(col, "4. Edit options")
        capBox = check("Burn-in captions (exactly what is said)", prefs.getBoolean("caps", false))
        trimBox = check("Remove pauses and filler words (umm, hmm)", prefs.getBoolean("trim", true))
        titleBox = check("Show a hook title at the start (3 s)", prefs.getBoolean("title", true))
        slowBox = check("Slow motion on the best kill", prefs.getBoolean("slow", true))
        fitBox = check("Show the full frame, no zoom (black bars)", prefs.getBoolean("fit", false))
        cEdit.addView(capBox)
        cEdit.addView(trimBox)
        cEdit.addView(titleBox)
        cEdit.addView(slowBox)
        cEdit.addView(fitBox)

        // 5. Settings
        val cSet = card(col, "5. Clip settings")
        countField = input("5", prefs.getString("count", "5") ?: "5", true)
        scoreField = input("7", prefs.getString("score", "7") ?: "7", true)
        minField = input("30", prefs.getString("min", "30") ?: "30", true)
        maxField = input("60", prefs.getString("max", "60") ?: "60", true)
        val r1 = LinearLayout(this)
        r1.orientation = LinearLayout.HORIZONTAL
        val r2 = LinearLayout(this)
        r2.orientation = LinearLayout.HORIZONTAL
        fun half(first: Boolean): LinearLayout.LayoutParams {
            val p = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (first) p.rightMargin = dp(10)
            return p
        }
        r1.addView(labeled("Max clips", countField), half(true))
        r1.addView(labeled("Min viral score (1-10)", scoreField), half(false))
        r2.addView(labeled("Min length (sec)", minField), half(true))
        r2.addView(labeled("Max length (sec)", maxField), half(false))
        cSet.addView(r1)
        cSet.addView(r2)
        cSet.addView(muted("Caption language"))
        langGroup = radioGroup(listOf("Original (as spoken)", "Hinglish (Roman)", "English"), prefs.getInt("lang", 1))
        cSet.addView(langGroup)
        sideBlock = LinearLayout(this)
        sideBlock.orientation = LinearLayout.VERTICAL
        sideBlock.addView(muted("Podcast: which side does the FIRST speaker sit on?"))
        sideGroup = radioGroup(listOf("Left", "Right"), prefs.getInt("side", 0))
        sideBlock.addView(sideGroup)
        cSet.addView(sideBlock)

        // 6. AI keys
        val cAi = card(col, "6. AI keys")
        cAi.addView(muted("Paste one or more API keys (one per line). The provider is detected automatically: Gemini, xAI Grok, Groq, OpenRouter, OpenAI, Cerebras. When one key hits its limit, the next one takes over."))
        keyField = input("AIza...   xai-...   gsk_...", prefs.getString("keys", prefs.getString("key", "")) ?: "")
        keyField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        keyField.setSingleLine(false)
        keyField.minLines = 3
        keyField.gravity = Gravity.TOP
        keyField.transformationMethod = PasswordTransformationMethod.getInstance()
        cAi.addView(keyField)
        keysInfo = muted("")
        keysInfo.setTextColor(cAccent)
        cAi.addView(keysInfo)
        val showKeys = check("Show keys", false)
        showKeys.setOnCheckedChangeListener { _, on ->
            keyField.transformationMethod = if (on) null else PasswordTransformationMethod.getInstance()
        }
        cAi.addView(showKeys)
        keyField.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val r = Keys.parse(s?.toString() ?: "")
                keysInfo.text = Keys.summary(r.first) + (if (r.second.isNotEmpty()) "  |  ignored: ${r.second.size}" else "")
            }
        })
        val r0 = Keys.parse(keyField.text.toString())
        keysInfo.text = Keys.summary(r0.first)
        modelField = input("gemini-3.8-flash", prefs.getString("model4", "gemini-3.8-flash") ?: "gemini-3.8-flash")
        cAi.addView(labeled("Gemini model", modelField))

        updateVisibility()

        // Start
        startBtn = primaryButton("Generate clips")
        startBtn.setOnClickListener { start() }
        val sp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        sp.bottomMargin = dp(10)
        col.addView(startBtn, sp)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.isIndeterminate = true
        progress.visibility = View.GONE
        col.addView(progress, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(6)))

        statusView = muted("", 13f)
        statusView.setTextColor(cText)
        col.addView(statusView)

        // Results + log
        resultsCard = card(col, "Your clips")
        resultsCard.visibility = View.GONE
        val cLog = card(col, "Details")
        logView = TextView(this)
        logView.textSize = 11f
        logView.setTextColor(cMuted)
        logView.typeface = Typeface.MONOSPACE
        logView.setTextIsSelectable(true)
        cLog.addView(logView)

        setContentView(scroll)

        if (intent?.action == Intent.ACTION_SEND) {
            val u = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            if (u != null) {
                pickedUri = u
                pickedLabel.text = "Selected: ${fileName(u)}"
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val u = data?.data ?: return
        if (requestCode == reqPick) {
            pickedUri = u
            pickedLabel.text = "Selected: ${fileName(u)}"
        } else if (requestCode == reqMusic) {
            pickedMusic = u
            musicLabel.text = "Music: ${fileName(u)}"
        }
    }

    private fun log(msg: String) {
        runOnUiThread {
            logView.append(msg + "\n")
            statusView.text = msg
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun start() {
        if (running) return
        val keyText = keyField.text.toString()
        val keys = Keys.parse(keyText).first
        if (keys.isEmpty()) {
            Toast.makeText(this, "Please add at least one valid API key", Toast.LENGTH_LONG).show()
            return
        }
        val picked = pickedUri
        if (picked == null) {
            Toast.makeText(this, "Please select a video first", Toast.LENGTH_LONG).show()
            return
        }
        val model = modelField.text.toString().trim().ifEmpty { "gemini-3.8-flash" }
        val count = countField.text.toString().toIntOrNull()?.coerceIn(1, 15) ?: 5
        val minSec = minField.text.toString().toIntOrNull()?.coerceIn(5, 300) ?: 30
        val maxSec = (maxField.text.toString().toIntOrNull() ?: 60).coerceIn(minSec, 600)
        val minScore = scoreField.text.toString().toIntOrNull()?.coerceIn(1, 10) ?: 7
        val type = selected(typeGroup).coerceIn(0, 3)
        val side = selected(sideGroup).coerceIn(0, 1)
        val lang = selected(langGroup).coerceIn(0, 2)
        val o = Options(
            count, minSec, maxSec, capBox.isChecked, trimBox.isChecked, fitBox.isChecked,
            type, lang, minScore, side == 0, titleBox.isChecked,
            pickedMusic, beatBox.isChecked, slowBox.isChecked
        )

        getSharedPreferences("dirac", MODE_PRIVATE).edit()
            .putString("keys", keyText).putString("model4", model)
            .putString("count", count.toString()).putString("min", minSec.toString())
            .putString("max", maxSec.toString()).putString("score", minScore.toString())
            .putBoolean("caps", o.withCaps).putBoolean("trim", o.trimPauses).putBoolean("fit", o.fit)
            .putBoolean("title", o.title).putBoolean("beat", o.beatSync).putBoolean("slow", o.slowmo)
            .putInt("type", type).putInt("side", side).putInt("lang", lang).apply()

        running = true
        startBtn.isEnabled = false
        startBtn.alpha = 0.5f
        progress.visibility = View.VISIBLE
        resultsCard.visibility = View.GONE
        while (resultsCard.childCount > 1) resultsCard.removeViewAt(1)
        logView.text = ""

        Thread {
            try {
                pipeline(keys, model, o, picked)
            } catch (e: Throwable) {
                log("ERROR: ${e.message ?: e.toString()}")
            } finally {
                running = false
                runOnUiThread {
                    startBtn.isEnabled = true
                    startBtn.alpha = 1f
                    progress.visibility = View.GONE
                }
            }
        }.start()
    }

    private fun pipeline(keys: List<KeyInfo>, model: String, o: Options, src: Uri) {
        val work = File(cacheDir, "work")
        work.deleteRecursively()
        work.mkdirs()

        val durationSec = durationOf(src)
        if (durationSec <= 0) throw ApiException("Could not read the video length. Try another video.")
        if (durationSec > 3900) throw ApiException("This video is longer than 1 hour. Please trim it (max ~65 min).")
        log("Video length: ${(durationSec / 60).toInt()} min ${(durationSec % 60).toInt()} sec")

        // 1) Audio -> 16kHz mono WAV (+ loudness map)
        log("Extracting audio (long videos take a while)...")
        val audioFile = File(work, "audio.wav")
        val energy = extractWav(src, audioFile, durationSec)
        log("Audio ready (${audioFile.length() / 1024 / 1024} MB)")

        // 1b) Music analysis
        val music = o.music
        var mEnergy: FloatArray? = null
        var beat: Beats.Result? = null
        if (music != null) {
            log("Analysing the music beat...")
            val mDur = durationOf(music)
            val mEn = extractWav(music, File(work, "music.wav"), mDur)
            mEnergy = mEn
            val b = Beats.analyze(mEn)
            beat = b
            log(if (b != null) "Music tempo: about ${b.bpm.toInt()} BPM" else "No clear beat found; the music will be mixed without sync")
        }

        // 2) AI: viral moments (Gemini keys rotate; fallbacks if all are exhausted)
        val plans = aiPlans(keys, model, o, work, audioFile, src, energy, durationSec)
        if (plans.isEmpty()) {
            throw ApiException("No clip was viral enough (score ${o.minScore}+). Lower the minimum score and try again.")
        }
        log("${plans.size} clips found. Rendering now...")

        val mE = mEnergy
        val bt = beat
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(this, src)
        val stamp = System.currentTimeMillis()
        try {
            for ((i, p) in plans.withIndex()) {
                var pieces = Planner.buildPieces(p, energy, o.trimPauses && o.type != 3)
                if (o.type == 3 && o.slowmo) pieces = Planner.applySlowmo(pieces, p.slowmo, energy)
                if (pieces.isEmpty()) {
                    log("Clip ${i + 1} skipped (nothing left after trimming)")
                    continue
                }
                var mStart = 0.0
                if (music != null && mE != null && bt != null) {
                    val dur0 = pieces.sumOf { Planner.outDuration(it) }
                    mStart = Beats.bestStart(bt, mE, dur0)
                    if (o.beatSync) {
                        val rel = bt.beats.map { it - mStart }.filter { it >= 0.0 }
                        pieces = Beats.syncCuts(pieces, rel, durationSec)
                    }
                }
                val total = pieces.sumOf { Planner.outDuration(it) }
                log("Clip ${i + 1}/${plans.size}: ${p.title} (score ${p.score}, ${pieces.size} hisse, ${total.toInt()}s)")

                val ctx = if (o.fit || o.type == 3) null else detectFaces(retriever, pieces)
                if (!o.fit && o.type != 3) {
                    log(if (ctx == null || ctx.faces.isEmpty()) "No face found, using a center crop" else "${ctx.faces.size} face(s) found")
                }

                val out = File(work, "clip_$i.mp4")
                var err = renderClip(src, pieces, p, o, ctx, out, false, false, music, mStart)
                if (err != null) {
                    log("Layout failed ($err). Retrying with a simple crop...")
                    out.delete()
                    err = renderClip(src, pieces, p, o, ctx, out, true, false, music, mStart)
                }
                if (err != null) {
                    log("Failed again ($err). Retrying without music and slow motion...")
                    out.delete()
                    err = renderClip(src, pieces, p, o, ctx, out, true, true, null, 0.0)
                }
                if (err != null) {
                    log("Clip ${i + 1} fail: $err")
                    continue
                }
                val saved = saveToGallery(out, "DiracClip_${stamp}_${i + 1}.mp4")
                if (saved != null) {
                    log("Clip ${i + 1} saved (Movies/DiracClip)")
                    addResult("${p.title} (${p.score})", saved, "${p.postCaption}\n${p.hashtags}".trim())
                } else {
                    log("Clip ${i + 1} could not be saved")
                }
            }
        } finally {
            retriever.release()
        }
        log("Done! Your clips are in the gallery, Movies/DiracClip folder.")
    }

    private fun detectFaces(r: MediaMetadataRetriever, pieces: List<Piece>): FaceCtx? {
        return try {
            val longest = pieces.maxByOrNull { it.end - it.start } ?: return null
            val mid = (longest.start + longest.end) / 2.0
            val bmp = r.getFrameAtTime((mid * 1_000_000).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: return null
            val w = bmp.width
            val h = bmp.height
            val scale = if (w > 1280) 1280f / w else 1f
            val small = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (w * scale).toInt(), (h * scale).toInt(), true) else bmp
            val faces = FaceFinder.detect(small).map {
                RectF(it.left / scale, it.top / scale, it.right / scale, it.bottom / scale)
            }
            FaceCtx(w, h, faces)
        } catch (e: Exception) {
            null
        }
    }

    private fun parseOrThrow(raw: String, durationSec: Double, o: Options): List<ClipPlan> {
        return try {
            GeminiClient.parsePlans(raw, durationSec, o)
        } catch (e: Exception) {
            throw ApiException("Could not understand the AI response: ${raw.take(200)}")
        }
    }

    private fun makeProxyFile(src: Uri, work: File): File {
        log("Creating a small 360p copy of the gameplay (takes a few minutes)...")
        val f = File(work, "proxy.mp4")
        val err = makeProxy(src, f)
        if (err != null) throw ApiException("Could not create the preview copy: $err")
        log("Preview copy ready (${f.length() / 1024 / 1024} MB)")
        return f
    }

    private fun aiPlans(
        keys: List<KeyInfo>, model: String, o: Options, work: File, audioFile: File,
        src: Uri, energy: FloatArray, durationSec: Double
    ): List<ClipPlan> {
        val gem = keys.filter { it.provider == Provider.GEMINI }
        var proxy: File? = null
        var lastErr = ""
        for ((n, gk) in gem.withIndex()) {
            try {
                log("Using Gemini key ${n + 1} of ${gem.size}")
                val raw: String
                if (o.type == 3) {
                    val pf = proxy ?: makeProxyFile(src, work).also { proxy = it }
                    val up = GeminiClient.uploadFile(gk.key, pf, "video/mp4") { log(it) }
                    log("Gemini is watching the gameplay ($model)...")
                    val loud = Planner.loudMoments(energy, 12)
                    raw = GeminiClient.generate(gk.key, model, up.second, "video/mp4", GeminiClient.buildPrompt(o, loud), true) { log(it) }
                } else {
                    val up = GeminiClient.uploadFile(gk.key, audioFile, "audio/wav") { log(it) }
                    log("Gemini is finding viral moments ($model)...")
                    raw = GeminiClient.generate(gk.key, model, up.second, "audio/wav", GeminiClient.buildPrompt(o), false) { log(it) }
                }
                return parseOrThrow(raw, durationSec, o)
            } catch (e: Exception) {
                lastErr = e.message ?: e.toString()
                log("Gemini key ${n + 1} failed: ${lastErr.take(140)}")
            }
        }
        if (o.type == 3) {
            log("No Gemini key could be used. Using the audio-only fallback (no AI): clips around the loudest moments.")
            return Planner.fallbackPlans(energy, durationSec, o)
        }
        return speechFallback(keys, o, work, audioFile, durationSec, lastErr)
    }

    private fun speechFallback(
        keys: List<KeyInfo>, o: Options, work: File, audioFile: File, durationSec: Double, lastErr: String
    ): List<ClipPlan> {
        val sttKey = keys.firstOrNull { it.provider == Provider.GROQ } ?: keys.firstOrNull { it.provider == Provider.OPENAI }
        val llmKeys = keys.filter { it.provider != Provider.GEMINI }
        if (sttKey == null || llmKeys.isEmpty()) {
            throw ApiException(
                "No Gemini key is available" + (if (lastErr.isNotEmpty()) " ($lastErr)" else "") +
                    ". To keep working, add a free Groq key (speech-to-text + AI) or try again after the daily reset."
            )
        }
        log("Gemini unavailable. Switching to ${sttKey.provider.label} speech-to-text + text AI...")
        val sttBase = sttKey.provider.base
        val sttModel = OpenAiClient.pickSttModel(OpenAiClient.listModels(sttBase, sttKey.key))
            ?: throw ApiException("No speech-to-text model found for ${sttKey.provider.label}")
        val chunks = splitWav(audioFile, 540, work)
        val lines = StringBuilder()
        for ((i, ch) in chunks.withIndex()) {
            log("Transcribing part ${i + 1}/${chunks.size}...")
            for (s in OpenAiClient.transcribe(sttBase, sttKey.key, sttModel, ch.first, ch.second)) {
                lines.append("[").append("%.1f".format(java.util.Locale.US, s.first)).append("] ").append(s.third).append("\n")
            }
        }
        val prompt = GeminiClient.buildPrompt(o, emptyList(), lines.toString())
        var last = lastErr
        for (k in llmKeys) {
            try {
                val ids = OpenAiClient.listModels(k.provider.base, k.key)
                val m = OpenAiClient.pickChatModel(k.provider, ids) ?: continue
                log("Asking ${k.provider.label} ($m)...")
                val raw = OpenAiClient.chat(k.provider.base, k.key, m, prompt) { log(it) }
                return parseOrThrow(raw, durationSec, o)
            } catch (e: Exception) {
                last = e.message ?: e.toString()
                log("${k.provider.label} key failed: ${last.take(140)}")
            }
        }
        throw ApiException("All keys failed. Last error: ${last.take(200)}")
    }

    private fun splitWav(wav: File, chunkSec: Int, dir: File): List<Pair<File, Double>> {
        val bytesPerSec = 32000
        val total = wav.length() - 44
        val chunkBytes = chunkSec.toLong() * bytesPerSec
        val out = ArrayList<Pair<File, Double>>()
        RandomAccessFile(wav, "r").use { raf ->
            var pos = 0L
            var idx = 0
            while (pos < total) {
                val len = minOf(chunkBytes, total - pos)
                val f = File(dir, "chunk_$idx.wav")
                f.outputStream().use { os ->
                    val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
                    h.put("RIFF".toByteArray())
                    h.putInt((36 + len).toInt())
                    h.put("WAVE".toByteArray())
                    h.put("fmt ".toByteArray())
                    h.putInt(16)
                    h.putShort(1)
                    h.putShort(1)
                    h.putInt(16000)
                    h.putInt(32000)
                    h.putShort(2)
                    h.putShort(16)
                    h.put("data".toByteArray())
                    h.putInt(len.toInt())
                    os.write(h.array())
                    raf.seek(44 + pos)
                    val buf = ByteArray(64 * 1024)
                    var left = len
                    while (left > 0) {
                        val n = raf.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n < 0) break
                        os.write(buf, 0, n)
                        left -= n
                    }
                }
                out.add(Pair(f, pos / bytesPerSec.toDouble()))
                pos += len
                idx++
            }
        }
        return out
    }

    private fun capsFor(pc: Piece, caps: List<Cap>): List<Cap> {
        val r = ArrayList<Cap>()
        for (c in caps) {
            val s = maxOf(c.start, pc.start)
            val e = minOf(c.end, pc.end)
            if (e - s >= 0.2 && c.text.isNotBlank()) {
                r.add(Cap((s - pc.start) / pc.speed, (e - pc.start) / pc.speed, c.text))
            }
        }
        return r
    }

    private fun gainProcessor(g: Float): AudioProcessor {
        val p = ChannelMixingAudioProcessor()
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(1, 2).scaleBy(g))
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(2, 2).scaleBy(g))
        return p
    }

    private fun renderClip(
        src: Uri, piecesIn: List<Piece>, plan: ClipPlan, o: Options,
        ctx: FaceCtx?, out: File, basic: Boolean, simple: Boolean,
        music: Uri?, musicStart: Double
    ): String? {
        val pieces = if (simple) piecesIn.map { Piece(it.start, it.end, it.speaker, 1.0) } else piecesIn
        val items = ArrayList<EditedMediaItem>()
        for ((idx, pc) in pieces.withIndex()) {
            val lay = Layouts.effects(pc, o, ctx, basic)
            val fx = ArrayList<Effect>()
            val audioFx = ArrayList<AudioProcessor>()
            if (pc.speed != 1.0) {
                fx.add(SpeedChangeEffect(pc.speed.toFloat()))
                val sonic = SonicAudioProcessor()
                sonic.setSpeed(pc.speed.toFloat())
                sonic.setPitch(1f)
                audioFx.add(sonic)
            }
            fx.addAll(lay.effects)
            if (music != null) audioFx.add(gainProcessor(0.6f))
            val overlays = ArrayList<TextureOverlay>()
            if (o.withCaps) {
                val caps = capsFor(pc, plan.caps)
                if (caps.isNotEmpty()) overlays.add(CaptionOverlay(caps, lay.captionY))
            }
            if (o.title && idx == 0 && plan.title.isNotBlank()) {
                overlays.add(CaptionOverlay(listOf(Cap(0.0, 3.0, plan.title)), 0.72f))
            }
            if (overlays.isNotEmpty()) fx.add(OverlayEffect(ImmutableList.copyOf(overlays)))
            val clipping = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs((pc.start * 1000).toLong())
                .setEndPositionMs((pc.end * 1000).toLong())
                .build()
            val mi = MediaItem.Builder().setUri(src).setClippingConfiguration(clipping).build()
            items.add(
                EditedMediaItem.Builder(mi)
                    .setEffects(Effects(audioFx, fx))
                    .build()
            )
        }
        val sequences = ArrayList<EditedMediaItemSequence>()
        sequences.add(EditedMediaItemSequence(items))
        if (music != null) {
            val total = pieces.sumOf { Planner.outDuration(it) }
            val musicMs = (durationOf(music) * 1000).toLong()
            val startMs = (musicStart * 1000).toLong()
            val endMs = minOf(musicMs, startMs + (total * 1000).toLong() + 500)
            if (endMs - startMs > 1000) {
                val mc = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build()
                val mm = MediaItem.Builder().setUri(music).setClippingConfiguration(mc).build()
                val musicItem = EditedMediaItem.Builder(mm)
                    .setRemoveVideo(true)
                    .setEffects(Effects(listOf<AudioProcessor>(gainProcessor(0.4f)), emptyList<Effect>()))
                    .build()
                sequences.add(EditedMediaItemSequence(listOf(musicItem), true))
            }
        }
        val composition = Composition.Builder(sequences).build()
        return exportBlocking(composition, out.path) { b ->
            b.setVideoMimeType(MimeTypes.VIDEO_H264)
            b.setAudioMimeType(MimeTypes.AUDIO_AAC)
            b.setEncoderFactory(
                DefaultEncoderFactory.Builder(this)
                    .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(6_000_000).build())
                    .setEnableFallback(true)
                    .build()
            )
        }
    }

    /** Small 360p copy of the video so Gemini can watch it cheaply. */
    private fun makeProxy(src: Uri, out: File): String? {
        val fx = ArrayList<Effect>()
        fx.add(Presentation.createForHeight(360))
        val edited = EditedMediaItem.Builder(MediaItem.fromUri(src))
            .setEffects(Effects(emptyList<AudioProcessor>(), fx))
            .build()
        val composition = Composition.Builder(listOf(EditedMediaItemSequence(listOf(edited)))).build()
        return exportBlocking(composition, out.path) { b ->
            b.setVideoMimeType(MimeTypes.VIDEO_H264)
            b.setAudioMimeType(MimeTypes.AUDIO_AAC)
            b.setEncoderFactory(
                DefaultEncoderFactory.Builder(this)
                    .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(500_000).build())
                    .setEnableFallback(true)
                    .build()
            )
        }
    }

    private fun exportBlocking(
        composition: Composition,
        outPath: String,
        configure: (Transformer.Builder) -> Unit
    ): String? {
        val latch = CountDownLatch(1)
        var error: String? = null
        runOnUiThread {
            try {
                val b = Transformer.Builder(this)
                configure(b)
                b.addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        latch.countDown()
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        error = exportException.message ?: exportException.errorCodeName
                        latch.countDown()
                    }
                })
                b.build().start(composition, outPath)
            } catch (e: Exception) {
                error = e.message ?: e.toString()
                latch.countDown()
            }
        }
        latch.await()
        return error
    }

    /** Decodes audio to 16 kHz mono WAV. Returns loudness (RMS) per 20 ms for pause detection. */
    private fun extractWav(src: Uri, out: File, durationSec: Double): FloatArray {
        val ex = MediaExtractor()
        ex.setDataSource(this, src, null)
        var track = -1
        for (i in 0 until ex.trackCount) {
            val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
            if (m.startsWith("audio/")) {
                track = i
                break
            }
        }
        if (track < 0) {
            ex.release()
            throw ApiException("This video has no audio track.")
        }
        ex.selectTrack(track)
        val fmt = ex.getTrackFormat(track)
        val mime = fmt.getString(MediaFormat.KEY_MIME)!!
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()

        var srcRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = maxOf(1, fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
        var isFloat = false
        val outRate = 16000
        val raf = RandomAccessFile(out, "rw")
        raf.setLength(0)
        raf.write(ByteArray(44))
        val outBuf = ByteBuffer.allocate(64 * 1024).order(ByteOrder.LITTLE_ENDIAN)
        var dataLen = 0L
        var pos = 1.0
        var prev = 0f
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        var lastPct = -25

        var eBuf = FloatArray(1 shl 16)
        var eN = 0
        var sumSq = 0.0
        var eCount = 0

        try {
            while (!outputDone) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val ib = codec.getInputBuffer(ii)!!
                        val n = ex.readSampleData(ib, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10000)
                if (oi >= 0) {
                    if (info.size > 0) {
                        val ob = codec.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        ob.order(ByteOrder.LITTLE_ENDIAN)
                        val frames: Int
                        val mono: FloatArray
                        if (isFloat) {
                            val fb = ob.asFloatBuffer()
                            frames = fb.remaining() / channels
                            mono = FloatArray(frames)
                            for (f in 0 until frames) {
                                var sum = 0f
                                for (c in 0 until channels) sum += fb.get() * 32768f
                                mono[f] = sum / channels
                            }
                        } else {
                            val sb = ob.asShortBuffer()
                            frames = sb.remaining() / channels
                            mono = FloatArray(frames)
                            for (f in 0 until frames) {
                                var sum = 0f
                                for (c in 0 until channels) sum += sb.get().toFloat()
                                mono[f] = sum / channels
                            }
                        }
                        val e = FloatArray(frames + 1)
                        e[0] = prev
                        System.arraycopy(mono, 0, e, 1, frames)
                        val step = srcRate.toDouble() / outRate
                        while (pos <= frames.toDouble()) {
                            val i0 = pos.toInt()
                            val frac = (pos - i0).toFloat()
                            val a = e[i0]
                            val b = if (i0 + 1 <= frames) e[i0 + 1] else a
                            var v = a + (b - a) * frac
                            if (v > 32767f) v = 32767f
                            if (v < -32768f) v = -32768f
                            if (outBuf.remaining() < 2) {
                                raf.write(outBuf.array(), 0, outBuf.position())
                                dataLen += outBuf.position()
                                outBuf.clear()
                            }
                            outBuf.putShort(v.toInt().toShort())
                            sumSq += (v * v).toDouble()
                            eCount++
                            if (eCount == 320) {
                                if (eN == eBuf.size) eBuf = eBuf.copyOf(eN * 2)
                                eBuf[eN++] = Math.sqrt(sumSq / 320.0).toFloat()
                                sumSq = 0.0
                                eCount = 0
                            }
                            pos += step
                        }
                        pos -= frames.toDouble()
                        if (frames > 0) prev = e[frames]
                        if (durationSec > 0) {
                            val pct = ((info.presentationTimeUs / 1_000_000.0) / durationSec * 100).toInt()
                            if (pct >= lastPct + 25) {
                                lastPct = pct
                                log("Audio $pct%")
                            }
                        }
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    srcRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = maxOf(1, of.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
                    isFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                }
            }
            if (outBuf.position() > 0) {
                raf.write(outBuf.array(), 0, outBuf.position())
                dataLen += outBuf.position()
            }
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray())
            h.putInt((36 + dataLen).toInt())
            h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray())
            h.putInt(16)
            h.putShort(1)
            h.putShort(1)
            h.putInt(outRate)
            h.putInt(outRate * 2)
            h.putShort(2)
            h.putShort(16)
            h.put("data".toByteArray())
            h.putInt(dataLen.toInt())
            raf.seek(0)
            raf.write(h.array())
        } finally {
            try {
                codec.stop()
            } catch (e: Exception) {
            }
            codec.release()
            ex.release()
            raf.close()
        }
        return eBuf.copyOf(eN)
    }

    private fun addResult(title: String, uri: Uri, postText: String) {
        runOnUiThread {
            resultsCard.visibility = View.VISIBLE
            val b = ghostButton("Play: $title")
            b.setOnClickListener {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(uri, "video/mp4")
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                try {
                    startActivity(i)
                } catch (e: Exception) {
                    Toast.makeText(this, "Open the gallery: Movies/DiracClip", Toast.LENGTH_LONG).show()
                }
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(8)
            resultsCard.addView(b, lp)
            if (postText.isNotBlank()) {
                val tv = muted(postText, 12f)
                tv.setTextIsSelectable(true)
                resultsCard.addView(tv)
                val cp = ghostButton("Copy caption")
                cp.setOnClickListener {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("caption", postText))
                    Toast.makeText(this, "Caption copied", Toast.LENGTH_SHORT).show()
                }
                val lp2 = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp2.bottomMargin = dp(12)
                resultsCard.addView(cp, lp2)
            }
        }
    }

    private fun durationOf(uri: Uri): Double {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, uri)
            val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            return ms / 1000.0
        } finally {
            r.release()
        }
    }

    private fun saveToGallery(file: File, name: String): Uri? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues()
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                values.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/DiracClip")
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { o ->
                        file.inputStream().use { it.copyTo(o) }
                    }
                }
                uri
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                dir?.mkdirs()
                val f = File(dir, name)
                file.copyTo(f, true)
                Uri.fromFile(f)
            }
        } catch (e: Exception) {
            log("Save error: ${e.message}")
            null
        }
    }
}
