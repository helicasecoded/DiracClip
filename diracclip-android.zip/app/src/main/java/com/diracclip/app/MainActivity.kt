package com.diracclip.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.text.method.PasswordTransformationMethod
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.Effect
import org.json.JSONArray
import org.json.JSONObject
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CountDownLatch

class MainActivity : Activity() {

    private val reqPick = 11
    private val reqMusic = 12
    private var pickedUri: Uri? = null
    private var pickedMusic: Uri? = null

    private val cBg = Color.parseColor("#0E1013")
    private val cCard = Color.parseColor("#181B20")
    private val cField = Color.parseColor("#20242B")
    private val cStroke = Color.parseColor("#2A2F37")
    private val cText = Color.parseColor("#F2F4F7")
    private val cMuted = Color.parseColor("#9AA3AF")
    private val cAccent = Color.parseColor("#FF6A00")

    private lateinit var scroll: ScrollView
    private lateinit var keyField: EditText
    private lateinit var keysInfo: TextView
    private lateinit var modelField: EditText
    private lateinit var countField: EditText
    private lateinit var minField: EditText
    private lateinit var maxField: EditText
    private lateinit var scoreField: EditText
    private lateinit var capBox: CheckBox
    private lateinit var trimBox: CheckBox
    private lateinit var fitBox: CheckBox
    private lateinit var titleBox: CheckBox
    private lateinit var slowBox: CheckBox
    private lateinit var keepBox: CheckBox
    private lateinit var cMusic: LinearLayout
    private lateinit var refineHint: TextView
    private lateinit var beatBox: CheckBox
    private lateinit var typeGroup: RadioGroup
    private lateinit var sideGroup: RadioGroup
    private lateinit var langGroup: RadioGroup
    private lateinit var sideBlock: LinearLayout
    private lateinit var pickedLabel: TextView
    private lateinit var musicLabel: TextView
    private lateinit var startBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var resultsCard: LinearLayout

    @Volatile
    private var running = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radius: Int, stroke: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = dp(radius).toFloat()
        if (stroke != 0) d.setStroke(dp(1), stroke)
        return d
    }

    private fun card(parent: LinearLayout, title: String?): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(16))
        c.background = rounded(cCard, 16, cStroke)
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        parent.addView(c, lp)
        if (title != null) {
            val t = TextView(this)
            t.text = title
            t.textSize = 15f
            t.typeface = Typeface.DEFAULT_BOLD
            t.setTextColor(cText)
            t.setPadding(0, 0, 0, dp(8))
            c.addView(t)
        }
        return c
    }

    private fun muted(text: String, size: Float = 12f): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(cMuted)
        t.setPadding(0, dp(4), 0, dp(4))
        return t
    }

    private fun input(hint: String, value: String, numeric: Boolean = false, secret: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.setTextColor(cText)
        e.setHintTextColor(cMuted)
        e.textSize = 15f
        e.background = rounded(cField, 10, cStroke)
        e.setPadding(dp(14), dp(12), dp(14), dp(12))
        e.inputType = when {
            numeric -> InputType.TYPE_CLASS_NUMBER
            secret -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            else -> InputType.TYPE_CLASS_TEXT
        }
        return e
    }

    private fun labeled(label: String, v: View): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.addView(muted(label))
        l.addView(v)
        return l
    }

    private fun primaryButton(text: String): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 16f
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(Color.WHITE)
        b.background = rounded(cAccent, 14)
        b.stateListAnimator = null
        b.setPadding(dp(16), dp(14), dp(16), dp(14))
        return b
    }

    private fun ghostButton(text: String): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 14f
        b.setTextColor(cAccent)
        b.background = rounded(Color.TRANSPARENT, 12, cAccent)
        b.stateListAnimator = null
        b.setPadding(dp(14), dp(10), dp(14), dp(10))
        return b
    }

    private fun check(text: String, checked: Boolean): CheckBox {
        val c = CheckBox(this)
        c.text = text
        c.textSize = 14f
        c.setTextColor(cText)
        c.isChecked = checked
        c.buttonTintList = ColorStateList.valueOf(cAccent)
        return c
    }

    private fun radioGroup(options: List<String>, selected: Int): RadioGroup {
        val g = RadioGroup(this)
        g.orientation = RadioGroup.VERTICAL
        for ((i, name) in options.withIndex()) {
            val r = RadioButton(this)
            r.id = 1000 + i
            r.text = name
            r.textSize = 14f
            r.setTextColor(cText)
            r.buttonTintList = ColorStateList.valueOf(cAccent)
            r.setPadding(dp(6), dp(8), dp(6), dp(8))
            g.addView(r)
        }
        g.check(1000 + selected)
        return g
    }

    private fun selected(g: RadioGroup): Int = g.checkedRadioButtonId - 1000

    private fun fileName(u: Uri): String {
        var name = u.lastPathSegment ?: u.toString()
        try {
            contentResolver.query(u, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) name = c.getString(idx)
            }
        } catch (e: Exception) {
        }
        return name
    }

    private fun updateVisibility() {
        val type = selected(typeGroup)
        sideBlock.visibility = if (type == 2) View.VISIBLE else View.GONE
        fitBox.visibility = if (type == 0) View.VISIBLE else View.GONE
        slowBox.visibility = if (type == 3) View.VISIBLE else View.GONE
        trimBox.visibility = if (type >= 3) View.GONE else View.VISIBLE
        capBox.visibility = if (type == 4) View.GONE else View.VISIBLE
        keepBox.visibility = if (type == 4) View.VISIBLE else View.GONE
        cMusic.visibility = if (type == 5) View.GONE else View.VISIBLE
        refineHint.visibility = if (type >= 4) View.VISIBLE else View.GONE
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        val prefs = getSharedPreferences("dirac", MODE_PRIVATE)

        scroll = ScrollView(this)
        scroll.setBackgroundColor(cBg)
        scroll.isFillViewport = true
        val outer = LinearLayout(this)
        outer.orientation = LinearLayout.VERTICAL
        outer.gravity = Gravity.CENTER_HORIZONTAL
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(28), dp(16), dp(32))
        val colW = minOf(resources.displayMetrics.widthPixels, dp(640))
        outer.addView(col, LinearLayout.LayoutParams(colW, LinearLayout.LayoutParams.WRAP_CONTENT))
        scroll.addView(outer)

        // Header
        val title = TextView(this)
        title.text = "DiracClip"
        title.textSize = 30f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(cAccent)
        col.addView(title)
        val sub = muted("AI editor for viral clips: best moments, beat-synced cuts, slow motion and music mixing.", 13f)
        sub.setPadding(0, 0, 0, dp(16))
        col.addView(sub)

        // 1. Video
        val cVideo = card(col, "1. Video")
        val pickBtn = primaryButton("Select video")
        pickBtn.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "video/*"
            startActivityForResult(i, reqPick)
        }
        cVideo.addView(pickBtn)
        pickedLabel = muted("No video selected (max 1 hour)")
        cVideo.addView(pickedLabel)

        // 2. Type
        val cType = card(col, "2. Video type")
        typeGroup = radioGroup(
            listOf(
                "Talking video (vlog, education, commentary)",
                "Game stream (gameplay on top, streamer facecam below)",
                "Podcast / interview (2 people)",
                "Gameplay recording (no commentary): COD, GTA, any game",
                "Refine: creator video + music to a beat-synced edit (max 2 min)",
                "Song edit: song video to a viral-lyrics edit (max 7 min)"
            ),
            prefs.getInt("type", 3)
        )
        typeGroup.setOnCheckedChangeListener { _, _ -> updateVisibility() }
        cType.addView(typeGroup)

        // 3. Music
        cMusic = card(col, "3. Background music (optional)")
        cMusic.addView(muted("With music: game audio 60% + music 40%, and cuts land on the beat. Without music: the clip keeps its raw game audio."))
        val mRow = LinearLayout(this)
        mRow.orientation = LinearLayout.HORIZONTAL
        val musicBtn = ghostButton("Select music")
        musicBtn.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "audio/*"
            startActivityForResult(i, reqMusic)
        }
        val clearBtn = ghostButton("Remove")
        clearBtn.setOnClickListener {
            pickedMusic = null
            musicLabel.text = "No music selected (raw audio)"
        }
        mRow.addView(musicBtn)
        val clp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        clp.leftMargin = dp(10)
        mRow.addView(clearBtn, clp)
        cMusic.addView(mRow)
        musicLabel = muted("No music selected (raw audio)")
        cMusic.addView(musicLabel)
        beatBox = check("Sync cuts to the music beat", prefs.getBoolean("beat", true))
        cMusic.addView(beatBox)

        // 4. Edit options
        val cEdit = card(col, "4. Edit options")
        capBox = check("Burn-in captions (exactly what is said)", prefs.getBoolean("caps", false))
        trimBox = check("Remove pauses and filler words (umm, hmm)", prefs.getBoolean("trim", true))
        titleBox = check("Show a hook title at the start (2.5 s)", prefs.getBoolean("title2", false))
        slowBox = check("Slow motion on the best kill", prefs.getBoolean("slow", true))
        fitBox = check("Show the full frame, no zoom (black bars)", prefs.getBoolean("fit", false))
        keepBox = check("Keep the original audio under the music (25%)", prefs.getBoolean("keep", false))
        cEdit.addView(capBox)
        cEdit.addView(trimBox)
        cEdit.addView(titleBox)
        cEdit.addView(slowBox)
        cEdit.addView(fitBox)
        cEdit.addView(keepBox)

        // 5. Settings
        val cSet = card(col, "5. Clip settings")
        refineHint = muted("Refine and Song edit: 'Max clips' = number of edit variations (each in a different style). Min / Max length = length of each edit.")
        cSet.addView(refineHint)
        countField = input("5", prefs.getString("count", "5") ?: "5", true)
        scoreField = input("7", prefs.getString("score", "7") ?: "7", true)
        minField = input("30", prefs.getString("min", "30") ?: "30", true)
        maxField = input("60", prefs.getString("max", "60") ?: "60", true)
        val r1 = LinearLayout(this)
        r1.orientation = LinearLayout.HORIZONTAL
        val r2 = LinearLayout(this)
        r2.orientation = LinearLayout.HORIZONTAL
        fun half(first: Boolean): LinearLayout.LayoutParams {
            val p = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (first) p.rightMargin = dp(10)
            return p
        }
        r1.addView(labeled("Max clips", countField), half(true))
        r1.addView(labeled("Min viral score (1-10)", scoreField), half(false))
        r2.addView(labeled("Min length (sec)", minField), half(true))
        r2.addView(labeled("Max length (sec)", maxField), half(false))
        cSet.addView(r1)
        cSet.addView(r2)
        cSet.addView(muted("Caption language"))
        langGroup = radioGroup(listOf("Original (as spoken)", "Hinglish (Roman)", "English"), prefs.getInt("lang", 1))
        cSet.addView(langGroup)
        sideBlock = LinearLayout(this)
        sideBlock.orientation = LinearLayout.VERTICAL
        sideBlock.addView(muted("Podcast: which side does the FIRST speaker sit on?"))
        sideGroup = radioGroup(listOf("Left", "Right"), prefs.getInt("side", 0))
        sideBlock.addView(sideGroup)
        cSet.addView(sideBlock)

        // 6. AI keys
        val cAi = card(col, "6. AI keys")
        cAi.addView(muted("Models are chosen automatically and switch when a limit is hit. Gemini: newest Flash, then Flash-Lite. Groq: Llama 3.3 70B, Llama 4, Qwen3, GPT-OSS. OpenRouter: best free model. Cerebras: Llama 3.3 70B. The exact order is shown in the log."))
        cAi.addView(muted("Paste one or more API keys (one per line). The provider is detected automatically: Gemini, xAI Grok, Groq, OpenRouter, OpenAI, Cerebras. When one key hits its limit, the next one takes over."))
        keyField = input("AIza...   xai-...   gsk_...", prefs.getString("keys", prefs.getString("key", "")) ?: "")
        keyField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        keyField.setSingleLine(false)
        keyField.minLines = 3
        keyField.gravity = Gravity.TOP
        keyField.transformationMethod = PasswordTransformationMethod.getInstance()
        cAi.addView(keyField)
        keysInfo = muted("")
        keysInfo.setTextColor(cAccent)
        cAi.addView(keysInfo)
        val showKeys = check("Show keys", false)
        showKeys.setOnCheckedChangeListener { _, on ->
            keyField.transformationMethod = if (on) null else PasswordTransformationMethod.getInstance()
        }
        cAi.addView(showKeys)
        keyField.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val r = Keys.parse(s?.toString() ?: "")
                keysInfo.text = Keys.summary(r.first) + (if (r.second.isNotEmpty()) "  |  ignored: ${r.second.size}" else "")
            }
        })
        val r0 = Keys.parse(keyField.text.toString())
        keysInfo.text = Keys.summary(r0.first)
        modelField = input("gemini-3.8-flash", prefs.getString("model4", "gemini-3.8-flash") ?: "gemini-3.8-flash")
        cAi.addView(labeled("Preferred Gemini model (optional)", modelField))

        updateVisibility()

        // Start
        startBtn = primaryButton("Generate clips")
        startBtn.setOnClickListener { start() }
        val sp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        sp.bottomMargin = dp(10)
        col.addView(startBtn, sp)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.isIndeterminate = true
        progress.visibility = View.GONE
        col.addView(progress, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(6)))

        statusView = muted("", 13f)
        statusView.setTextColor(cText)
        col.addView(statusView)

        // Results + log
        resultsCard = card(col, "Your clips")
        resultsCard.visibility = View.GONE
        val cLog = card(col, "Details")
        logView = TextView(this)
        logView.textSize = 11f
        logView.setTextColor(cMuted)
        logView.typeface = Typeface.MONOSPACE
        logView.setTextIsSelectable(true)
        cLog.addView(logView)

        setContentView(scroll)

        if (intent?.action == Intent.ACTION_SEND) {
            val u = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            if (u != null) {
                pickedUri = u
                pickedLabel.text = "Selected: ${fileName(u)}"
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val u = data?.data ?: return
        if (requestCode == reqPick) {
            pickedUri = u
            pickedLabel.text = "Selected: ${fileName(u)}"
        } else if (requestCode == reqMusic) {
            pickedMusic = u
            musicLabel.text = "Music: ${fileName(u)}"
        }
    }

    private fun log(msg: String) {
        runOnUiThread {
            logView.append(msg + "\n")
            statusView.text = msg
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun start() {
        if (running) return
        val keyText = keyField.text.toString()
        val keys = Keys.parse(keyText).first
        if (keys.isEmpty()) {
            Toast.makeText(this, "Please add at least one valid API key", Toast.LENGTH_LONG).show()
            return
        }
        val picked = pickedUri
        if (picked == null) {
            Toast.makeText(this, "Please select a video first", Toast.LENGTH_LONG).show()
            return
        }
        val model = modelField.text.toString().trim().ifEmpty { "gemini-3.8-flash" }
        val count = countField.text.toString().toIntOrNull()?.coerceIn(1, 15) ?: 5
        val minSec = minField.text.toString().toIntOrNull()?.coerceIn(5, 300) ?: 30
        val maxSec = (maxField.text.toString().toIntOrNull() ?: 60).coerceIn(minSec, 600)
        val minScore = scoreField.text.toString().toIntOrNull()?.coerceIn(1, 10) ?: 7
        val type = selected(typeGroup).coerceIn(0, 5)
        val side = selected(sideGroup).coerceIn(0, 1)
        val lang = selected(langGroup).coerceIn(0, 2)
        val o = Options(
            count, minSec, maxSec, capBox.isChecked, trimBox.isChecked, fitBox.isChecked,
            type, lang, minScore, side == 0, titleBox.isChecked,
            pickedMusic, beatBox.isChecked, slowBox.isChecked, keepBox.isChecked && type == 4
        )

        getSharedPreferences("dirac", MODE_PRIVATE).edit()
            .putString("keys", keyText).putString("model4", model)
            .putString("count", count.toString()).putString("min", minSec.toString())
            .putString("max", maxSec.toString()).putString("score", minScore.toString())
            .putBoolean("caps", o.withCaps).putBoolean("trim", o.trimPauses).putBoolean("fit", o.fit)
            .putBoolean("title2", o.title).putBoolean("keep", keepBox.isChecked).putBoolean("beat", o.beatSync).putBoolean("slow", o.slowmo)
            .putInt("type", type).putInt("side", side).putInt("lang", lang).apply()

        running = true
        startBtn.isEnabled = false
        startBtn.alpha = 0.5f
        progress.visibility = View.VISIBLE
        resultsCard.visibility = View.GONE
        while (resultsCard.childCount > 1) resultsCard.removeViewAt(1)
        logView.text = ""

        Thread {
            try {
                pipeline(keys, model, o, picked)
            } catch (e: Throwable) {
                log("ERROR: ${e.message ?: e.toString()}")
            } finally {
                running = false
                runOnUiThread {
                    startBtn.isEnabled = true
                    startBtn.alpha = 1f
                    progress.visibility = View.GONE
                }
            }
        }.start()
    }

    private fun pipeline(keys: List<KeyInfo>, model: String, o: Options, src: Uri) {
        val work = File(cacheDir, "work")
        work.deleteRecursively()
        work.mkdirs()

        val durationSec = durationOf(src)
        if (durationSec <= 0) throw ApiException("Could not read the video length. Try another video.")
        if (durationSec > 3900) throw ApiException("This video is longer than 1 hour. Please trim it (max ~65 min).")
        log("Video length: ${(durationSec / 60).toInt()} min ${(durationSec % 60).toInt()} sec")

        if (o.type >= 4) {
            refinePipeline(keys, model, o, src, work, durationSec)
            return
        }

        // 1) Audio -> 16kHz mono WAV (+ loudness map)
        log("Extracting audio (long videos take a while)...")
        val audioFile = File(work, "audio.wav")
        val energy = extractWav(src, audioFile, durationSec)
        log("Audio ready (${audioFile.length() / 1024 / 1024} MB)")

        // 1b) Music analysis
        val music = o.music
        var mEnergy: FloatArray? = null
        var beat: Beats.Result? = null
        if (music != null) {
            log("Analysing the music beat...")
            val mDur = durationOf(music)
            val mEn = extractWav(music, File(work, "music.wav"), mDur)
            mEnergy = mEn
            val b = Beats.analyze(mEn)
            beat = b
            log(if (b != null) "Music tempo: about ${b.bpm.toInt()} BPM" else "No clear beat found; the music will be mixed without sync")
        }

        // 2) AI: viral moments (Gemini keys rotate; fallbacks if all are exhausted)
        val router = Router(keys, model) { log(it) }
        router.announce()
        val plans = aiPlans(router, o, work, audioFile, src, energy, durationSec)
        if (plans.isEmpty()) {
            throw ApiException("No clip was viral enough (score ${o.minScore}+). Lower the minimum score and try again.")
        }
        log("${plans.size} clips found. Rendering now...")

        val mE = mEnergy
        val bt = beat
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(this, src)
        val stamp = System.currentTimeMillis()
        try {
            for ((i, p) in plans.withIndex()) {
                var pieces = Planner.buildPieces(p, energy, o.trimPauses && o.type != 3)
                if (o.type == 3 && o.slowmo) pieces = Planner.applySlowmo(pieces, p.slowmo, energy)
                if (pieces.isEmpty()) {
                    log("Clip ${i + 1} skipped (nothing left after trimming)")
                    continue
                }
                var mStart = 0.0
                if (music != null && mE != null && bt != null) {
                    val dur0 = pieces.sumOf { Planner.outDuration(it) }
                    mStart = Beats.bestStart(bt, mE, dur0)
                    if (o.beatSync) {
                        val rel = bt.beats.map { it - mStart }.filter { it >= 0.0 }
                        pieces = Beats.syncCuts(pieces, rel, durationSec)
                    }
                }
                val total = pieces.sumOf { Planner.outDuration(it) }
                log("Clip ${i + 1}/${plans.size}: ${p.title} (score ${p.score}, ${pieces.size} hisse, ${total.toInt()}s)")

                val ctx = if (o.fit || o.type == 3) null else detectFaces(retriever, pieces)
                if (!o.fit && o.type != 3) {
                    log(if (ctx == null || ctx.faces.isEmpty()) "No face found, using a center crop" else "${ctx.faces.size} face(s) found")
                }

                val out = File(work, "clip_$i.mp4")
                var err = renderClip(src, pieces, p, o, ctx, out, false, false, music, mStart)
                if (err != null) {
                    log("Layout failed ($err). Retrying with a simple crop...")
                    out.delete()
                    err = renderClip(src, pieces, p, o, ctx, out, true, false, music, mStart)
                }
                if (err != null) {
                    log("Failed again ($err). Retrying without music and slow motion...")
                    out.delete()
                    err = renderClip(src, pieces, p, o, ctx, out, true, true, null, 0.0)
                }
                if (err != null) {
                    log("Clip ${i + 1} fail: $err")
                    continue
                }
                val saved = saveToGallery(out, "DiracClip_${stamp}_${i + 1}.mp4")
                if (saved != null) {
                    log("Clip ${i + 1} saved (Movies/DiracClip)")
                    addResult("${p.title} (${p.score})", saved, "${p.postCaption}\n${p.hashtags}".trim())
                } else {
                    log("Clip ${i + 1} could not be saved")
                }
            }
        } finally {
            retriever.release()
        }
        log("Done! Your clips are in the gallery, Movies/DiracClip folder.")
    }

    private fun detectFaces(r: MediaMetadataRetriever, pieces: List<Piece>): FaceCtx? {
        return try {
            val longest = pieces.maxByOrNull { it.end - it.start } ?: return null
            val mid = (longest.start + longest.end) / 2.0
            val bmp = r.getFrameAtTime((mid * 1_000_000).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: return null
            val w = bmp.width
            val h = bmp.height
            val scale = if (w > 1280) 1280f / w else 1f
            val small = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (w * scale).toInt(), (h * scale).toInt(), true) else bmp
            val faces = FaceFinder.detect(small).map {
                RectF(it.left / scale, it.top / scale, it.right / scale, it.bottom / scale)
            }
            FaceCtx(w, h, faces)
        } catch (e: Exception) {
            null
        }
    }

    private fun parseOrThrow(raw: String, durationSec: Double, o: Options): List<ClipPlan> {
        return try {
            GeminiClient.parsePlans(raw, durationSec, o)
        } catch (e: Exception) {
            throw ApiException("Could not understand the AI response: ${raw.take(200)}")
        }
    }

    private fun makeProxyFile(src: Uri, work: File): File {
        log("Creating a small 360p preview copy of the video (takes a few minutes)...")
        val f = File(work, "proxy.mp4")
        val err = makeProxy(src, f)
        if (err != null) throw ApiException("Could not create the preview copy: $err")
        log("Preview copy ready (${f.length() / 1024 / 1024} MB)")
        return f
    }

    private class Moment(val t: Double, val score: Double, val title: String)

    private fun parseMoments(raw: String): List<Moment> {
        val arr = JSONObject(Json.extract(raw)).optJSONArray("moments") ?: JSONArray()
        val out = ArrayList<Moment>()
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val tt = m.optDouble("t", -1.0)
            if (tt >= 0) out.add(Moment(tt, m.optDouble("score", 6.0), m.optString("title", "")))
        }
        return out
    }

    private fun parseVisionShots(raw: String, durationSec: Double): List<Shot> {
        val arr = JSONObject(Json.extract(raw)).getJSONArray("shots")
        val out = ArrayList<Shot>()
        for (i in 0 until arr.length()) {
            val s = arr.getJSONObject(i)
            val st = maxOf(0.0, s.optDouble("start", -1.0))
            val en = minOf(durationSec, s.optDouble("end", -1.0))
            if (en - st >= 0.5) out.add(Shot(st, en, s.optDouble("score", 5.0)))
        }
        return out
    }

    private fun visionMoments(router: Router, src: Uri, durationSec: Double, loud: List<Int>): List<Moment> {
        val sheets = try {
            FrameSheets.make(this, src, durationSec, if (durationSec > 600) 6.0 else 4.0, 4, 3)
        } catch (e: Exception) {
            log("Could not sample frames: ${e.message}")
            return emptyList()
        }
        val out = ArrayList<Moment>()
        var i = 0
        while (i < sheets.size) {
            val batch = sheets.subList(i, minOf(sheets.size, i + 2))
            log("Vision analysis ${i / 2 + 1}/${(sheets.size + 1) / 2}...")
            val prompt = "These images are contact sheets of a gameplay video. Every tile is labeled with its timestamp in seconds. " +
                "Find the most exciting, viral-worthy moments: kills, headshots, multi-kills, clutches, explosions, stunts, funny fails. " +
                (if (loud.isNotEmpty()) "Hint: loud moments (fights) are near these seconds: ${loud.joinToString(", ")}. " else "") +
                "Return ONLY JSON: {\"moments\":[{\"t\":123.0,\"score\":8,\"title\":\"short title\"}]} with at most 6 moments."
            val got = try {
                router.vision(prompt, batch.map { it.jpeg }) { raw -> parseMoments(raw) }
            } catch (e: Exception) {
                log("Vision analysis unavailable: ${(e.message ?: "").take(100)}")
                return out
            }
            out.addAll(got)
            i += 2
        }
        return out
    }

    private fun plansFromMoments(ms: List<Moment>, durationSec: Double, o: Options): List<ClipPlan> {
        val len = ((o.minSec + o.maxSec) / 2.0).coerceAtMost(durationSec)
        val used = ArrayList<Pair<Double, Double>>()
        val plans = ArrayList<ClipPlan>()
        for (m in ms.sortedByDescending { it.score }) {
            if (plans.size >= o.count) break
            val e0 = minOf(durationSec, maxOf(0.0, m.t - len * 0.4) + len)
            val s0 = maxOf(0.0, e0 - len)
            if (used.any { s0 < it.second && e0 > it.first }) continue
            used.add(Pair(s0, e0))
            plans.add(
                ClipPlan(
                    m.title.ifBlank { "Highlight ${plans.size + 1}" }, m.score, "Vision model pick",
                    listOf(Seg(s0, e0, "NONE")), emptyList(), emptyList(), listOf(m.t)
                )
            )
        }
        return plans
    }

    /** Every key can do every job: Gemini reads media directly, other keys use speech-to-text / frame sheets + text or vision models. */
    private fun aiPlans(
        router: Router, o: Options, work: File, audioFile: File,
        src: Uri, energy: FloatArray, durationSec: Double
    ): List<ClipPlan> {
        if (o.type == 3) {
            val loud = Planner.loudMoments(energy, 12)
            val prompt = GeminiClient.buildPrompt(o, loud)
            var proxy: File? = null
            val direct = router.geminiMedia({ proxy ?: makeProxyFile(src, work).also { proxy = it } }, "video/mp4", prompt, true) { raw ->
                parseOrThrow(raw, durationSec, o)
            }
            if (direct != null) return direct
            log("Gemini could not analyse the video. Trying vision models on frame sheets...")
            val v = visionMoments(router, src, durationSec, loud)
            if (v.isNotEmpty()) return plansFromMoments(v, durationSec, o)
            log("No AI vision model was available. Using the audio-only fallback: clips around the loudest moments.")
            return Planner.fallbackPlans(energy, durationSec, o)
        }
        val direct = router.geminiMedia({ audioFile }, "audio/wav", GeminiClient.buildPrompt(o), false) { raw ->
            parseOrThrow(raw, durationSec, o)
        }
        if (direct != null) return direct
        log("Gemini could not analyse the audio. Using speech-to-text + text AI...")
        val transcript = transcribeAll(router, work, audioFile)
        return router.text(GeminiClient.buildPrompt(o, emptyList(), transcript)) { raw -> parseOrThrow(raw, durationSec, o) }
    }

    private fun transcribeAll(router: Router, work: File, audioFile: File): String {
        val chunks = splitWav(audioFile, 540, work)
        val sb = StringBuilder()
        for ((i, ch) in chunks.withIndex()) {
            log("Transcribing part ${i + 1}/${chunks.size}...")
            for (s in router.stt(ch.first, ch.second)) {
                sb.append("[").append("%.1f".format(java.util.Locale.US, s.first)).append("] ").append(s.third).append("\n")
            }
        }
        return sb.toString()
    }

    private fun songAi(router: Router, o: Options, work: File, audioFile: File, energy: FloatArray, durationSec: Double): SongPlan {
        // 1) Whisper speech-to-text with word timestamps (Groq / OpenAI): accurate lyrics + timing
        val segs = ArrayList<Triple<Double, Double, String>>()
        val words = ArrayList<Triple<Double, Double, String>>()
        try {
            val prompt = if (o.capLang == 1) "Song lyrics in Hinglish, written in Roman (English) letters." else ""
            val chunks = if (audioFile.length() <= 23_000_000L) listOf(Pair(audioFile, 0.0)) else splitWav(audioFile, 540, work)
            for ((i, ch) in chunks.withIndex()) {
                log("Transcribing the lyrics (${i + 1}/${chunks.size})...")
                val r = router.sttFull(ch.first, ch.second, prompt)
                segs.addAll(r.first)
                words.addAll(r.second)
            }
        } catch (e: Exception) {
            log("Lyric speech-to-text unavailable (${(e.message ?: "").take(100)}).")
        }
        val lineCaps = segs.map { Cap(it.first, it.second, it.third) }
        val wordCaps = words.map { Cap(it.first, it.second, it.third) }.filter { it.text.isNotBlank() }
        if (lineCaps.isNotEmpty()) {
            log("Lyrics found: ${lineCaps.size} lines, ${wordCaps.size} words")
            val transcript = lineCaps.joinToString("\n") {
                "[%.1f-%.1f] %s".format(java.util.Locale.US, it.start, it.end, it.text)
            }
            val meta: SongPlan? = try {
                router.text(GeminiClient.buildSongSectionsPrompt(o, transcript, durationSec)) { raw ->
                    GeminiClient.parseSong(raw, durationSec)
                }
            } catch (e: Exception) {
                log("AI could not pick the sections (${(e.message ?: "").take(100)}). Using lyric density and loudness.")
                null
            }
            val secs = Planner.fixSections(meta?.sections ?: emptyList(), lineCaps, wordCaps, energy, durationSec, o)
            if (secs.isNotEmpty()) {
                return SongPlan(
                    meta?.title ?: "Song edit", meta?.mood ?: "energetic",
                    meta?.postCaption ?: "", meta?.hashtags ?: "", lineCaps, secs, wordCaps
                )
            }
        }
        // 2) Gemini listens to the song directly (lyrics without word timing)
        val direct = router.geminiMedia({ audioFile }, "audio/wav", GeminiClient.buildSongPrompt(o), false) { raw ->
            GeminiClient.parseSong(raw, durationSec)
        }
        if (direct != null) {
            val secs = Planner.fixSections(direct.sections, direct.lines, emptyList(), energy, durationSec, o)
            return direct.copy(sections = if (secs.isNotEmpty()) secs else direct.sections)
        }
        // 3) No AI: loudest parts of the song
        log("No AI could analyse the lyrics. Using the loudest parts of the song.")
        val secs = Planner.fixSections(emptyList(), emptyList(), emptyList(), energy, durationSec, o)
        return SongPlan("Song edit", "energetic", "", "", emptyList(), secs)
    }

    private fun refineShots(router: Router, o: Options, work: File, src: Uri, energy: FloatArray, durationSec: Double): ShotPlan {
        var proxy: File? = null
        val direct = router.geminiMedia({ proxy ?: makeProxyFile(src, work).also { proxy = it } }, "video/mp4", GeminiClient.buildRefinePrompt(o), true) { raw ->
            GeminiClient.parseShots(raw, durationSec)
        }
        if (direct != null) return direct
        log("Gemini could not analyse the video. Trying vision models on frame sheets...")
        val sheets = try {
            FrameSheets.make(this, src, durationSec, 2.0, 4, 3)
        } catch (e: Exception) {
            emptyList()
        }
        val shots = ArrayList<Shot>()
        var i = 0
        while (i < sheets.size) {
            val batch = sheets.subList(i, minOf(sheets.size, i + 2))
            val prompt = "These images are contact sheets of a creator video. Every tile is labeled with its timestamp in seconds. " +
                "Choose the best moments for a fast Instagram Reel edit: strong expressions, key actions, aesthetic and sharp shots; avoid blurry, dark or boring tiles. " +
                "Return ONLY JSON: {\"shots\":[{\"start\":4.0,\"end\":6.0,\"score\":8}]} (each shot 1-4 seconds, score 1-10)."
            val got = try {
                router.vision(prompt, batch.map { it.jpeg }) { raw -> parseVisionShots(raw, durationSec) }
            } catch (e: Exception) {
                log("Vision analysis unavailable: ${(e.message ?: "").take(100)}")
                break
            }
            shots.addAll(got)
            i += 2
        }
        if (shots.isNotEmpty()) return ShotPlan("Edit", "energetic", "", "", shots)
        log("No AI vision model was available. Picking scenes from the audio instead.")
        return RefinePlanner.fallbackShots(energy, durationSec)
    }

    private fun renderWithFallback(
        src: Uri, pieces: List<Piece>, plan: ClipPlan, o: Options, ctx: FaceCtx?, out: File,
        music: Uri?, mStart: Double, lyrics: List<Cap>?, lyricsBase: Double
    ): String? {
        var err = renderClip(src, pieces, plan, o, ctx, out, false, false, music, mStart, lyrics, lyricsBase)
        if (err != null) {
            log("Render failed ($err). Retrying with a simpler layout...")
            out.delete()
            err = renderClip(src, pieces, plan, o, ctx, out, true, false, music, mStart, lyrics, lyricsBase)
        }
        if (err != null) {
            log("Failed again ($err). Retrying without music and effects...")
            out.delete()
            err = renderClip(src, pieces, plan, o, ctx, out, true, true, null, 0.0, null, 0.0)
        }
        return err
    }

    private fun refinePipeline(keys: List<KeyInfo>, model: String, o: Options, src: Uri, work: File, durationSec: Double) {
        val song = o.type == 5
        if (!song && durationSec > 130) throw ApiException("Refine supports videos up to 2 minutes. Please trim it.")
        if (song && durationSec > 420) throw ApiException("Song edit supports videos up to 7 minutes.")
        val router = Router(keys, model) { log(it) }
        router.announce()
        log("Extracting audio...")
        val audioFile = File(work, "audio.wav")
        val energy = extractWav(src, audioFile, durationSec)

        val music: Uri? = if (song) src else o.music
        var mE: FloatArray? = null
        var bt: Beats.Result? = null
        if (song) {
            mE = energy
            bt = Beats.analyze(energy)
        } else if (music != null) {
            log("Analysing the music beat...")
            val mEn = extractWav(music, File(work, "music.wav"), durationOf(music))
            mE = mEn
            bt = Beats.analyze(mEn)
        }
        val b0 = bt
        val e0 = mE
        if (music != null) {
            log(if (b0 != null) "Tempo: about ${b0.bpm.toInt()} BPM" else "No clear beat found; cuts will use a default rhythm")
        } else {
            log("No music selected: using a 120 BPM rhythm and the original audio.")
        }

        val sp: SongPlan? = if (song) songAi(router, o, work, audioFile, energy, durationSec) else null
        val shotsPlan: ShotPlan = if (sp != null) {
            val f = RefinePlanner.fallbackShots(energy, durationSec)
            ShotPlan(sp.title, sp.mood, sp.postCaption, sp.hashtags, f.shots)
        } else {
            refineShots(router, o, work, src, energy, durationSec)
        }
        log("Scenes ready: ${shotsPlan.shots.size}. Mood: ${shotsPlan.mood}")

        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(this, src)
        val ctx = try {
            detectFaces(retriever, listOf(Piece(0.0, durationSec, "NONE")))
        } finally {
            retriever.release()
        }

        val stamp = System.currentTimeMillis()
        val variations = if (sp != null) minOf(o.count.coerceIn(1, 6), maxOf(1, sp.sections.size)) else o.count.coerceIn(1, 6)
        val lyricWords: List<Cap> = if (sp != null) Planner.tidyWords(if (sp.words.isNotEmpty()) sp.words else Planner.evenWords(sp.lines)) else emptyList()
        val period = if (b0 != null) 60.0 / b0.bpm else 0.5
        for (v in 0 until variations) {
            val style = ((stamp / 1000 + v) % RefinePlanner.STYLE_NAMES.size).toInt()
            var target = ((o.minSec + o.maxSec) / 2.0) * (0.9 + 0.1 * (v % 3))
            target = target.coerceIn(o.minSec.toDouble(), o.maxSec.toDouble())
            var mStart = 0.0
            var lyrics: List<Cap>? = null
            var shots = shotsPlan
            if (sp != null) {
                val sec = sp.sections[v % sp.sections.size]
                var s0 = sec.start
                if (b0 != null) s0 = b0.beats.minByOrNull { Math.abs(it - sec.start) } ?: sec.start
                mStart = s0
                target = (sec.end - sec.start).coerceIn(o.minSec.toDouble(), o.maxSec.toDouble())
                lyrics = lyricWords
                val hook = Shot(s0, minOf(durationSec, s0 + 3.5), 10.0)
                shots = ShotPlan(shots.title, shots.mood, shots.postCaption, shots.hashtags, listOf(hook) + shots.shots)
            } else if (b0 != null && e0 != null) {
                mStart = Beats.bestStart(b0, e0, target)
            }
            val beats: List<Double> = if (b0 != null) {
                b0.beats.map { it - mStart }.filter { it >= 0.0 }
            } else {
                (0..((target / 0.5).toInt() + 2)).map { it * 0.5 }
            }
            val pieces = RefinePlanner.build(shots, beats, period, target, style, stamp + v, durationSec)
            if (pieces.isEmpty()) {
                log("Variation ${v + 1}: no usable scenes")
                continue
            }
            val total = pieces.sumOf { Planner.outDuration(it) }
            log("Variation ${v + 1}/$variations: ${RefinePlanner.STYLE_NAMES[style]} style, ${pieces.size} cuts, ${total.toInt()}s")
            val plan = ClipPlan(shots.title, 8.0, "", emptyList(), emptyList(), emptyList(), emptyList())
            val out = File(work, "refine_$v.mp4")
            val err = renderWithFallback(src, pieces, plan, o, ctx, out, music, mStart, lyrics, mStart)
            if (err != null) {
                log("Variation ${v + 1} failed: $err")
                continue
            }
            val saved = saveToGallery(out, "DiracClip_edit_${stamp}_${v + 1}.mp4")
            if (saved != null) {
                log("Variation ${v + 1} saved (Movies/DiracClip)")
                addResult("${RefinePlanner.STYLE_NAMES[style]} edit ${v + 1}", saved, "${shots.postCaption}\n${shots.hashtags}".trim())
            }
        }
        log("Done! Your edits are in the gallery, Movies/DiracClip folder.")
    }

    private fun splitWav(wav: File, chunkSec: Int, dir: File): List<Pair<File, Double>> {
        val bytesPerSec = 32000
        val total = wav.length() - 44
        val chunkBytes = chunkSec.toLong() * bytesPerSec
        val out = ArrayList<Pair<File, Double>>()
        RandomAccessFile(wav, "r").use { raf ->
            var pos = 0L
            var idx = 0
            while (pos < total) {
                val len = minOf(chunkBytes, total - pos)
                val f = File(dir, "chunk_$idx.wav")
                f.outputStream().use { os ->
                    val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
                    h.put("RIFF".toByteArray())
                    h.putInt((36 + len).toInt())
                    h.put("WAVE".toByteArray())
                    h.put("fmt ".toByteArray())
                    h.putInt(16)
                    h.putShort(1)
                    h.putShort(1)
                    h.putInt(16000)
                    h.putInt(32000)
                    h.putShort(2)
                    h.putShort(16)
                    h.put("data".toByteArray())
                    h.putInt(len.toInt())
                    os.write(h.array())
                    raf.seek(44 + pos)
                    val buf = ByteArray(64 * 1024)
                    var left = len
                    while (left > 0) {
                        val n = raf.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n < 0) break
                        os.write(buf, 0, n)
                        left -= n
                    }
                }
                out.add(Pair(f, pos / bytesPerSec.toDouble()))
                pos += len
                idx++
            }
        }
        return out
    }

    private fun capsFor(pc: Piece, caps: List<Cap>): List<Cap> {
        val r = ArrayList<Cap>()
        for (c in caps) {
            val s = maxOf(c.start, pc.start)
            val e = minOf(c.end, pc.end)
            if (e - s >= 0.2 && c.text.isNotBlank()) {
                r.add(Cap((s - pc.start) / pc.speed, (e - pc.start) / pc.speed, c.text))
            }
        }
        return r
    }

    private fun gainProcessor(g: Float): AudioProcessor {
        val p = ChannelMixingAudioProcessor()
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(1, 2).scaleBy(g))
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(2, 2).scaleBy(g))
        return p
    }

    /** Word captions mapped to this shot's timeline. */
    private fun lyricCapsFor(words: List<Cap>, base: Double, outStart: Double, dur: Double): List<Cap> {
        val r = ArrayList<Cap>()
        for (c in words) {
            val s = maxOf(c.start - base - outStart, 0.0)
            val e = minOf(c.end - base - outStart, dur)
            if (e - s >= 0.08 && c.text.isNotBlank()) r.add(Cap(s, e, c.text))
        }
        return r
    }

    private fun renderClip(
        src: Uri, piecesIn: List<Piece>, plan: ClipPlan, o: Options,
        ctx: FaceCtx?, out: File, basic: Boolean, simple: Boolean,
        music: Uri?, musicStart: Double,
        lyrics: List<Cap>? = null, lyricsBase: Double = 0.0
    ): String? {
        val refine = o.type == 4 || o.type == 5
        val origGain = if (refine) (if (o.keepAudio) 0.25f else 0f) else 0.6f
        val musicGain = if (refine) (if (o.keepAudio) 0.75f else 1f) else 0.4f
        val lo = if (refine) o.copy(type = 0, fit = false) else o
        val pieces = if (simple) piecesIn.map { Piece(it.start, it.end, it.speaker, 1.0) } else piecesIn
        val items = ArrayList<EditedMediaItem>()
        var outT = 0.0
        for ((idx, pc) in pieces.withIndex()) {
            val lay = if (refine && !simple && !basic && ctx != null && pc.idx % 3 == 2) Layouts.closeUp(ctx) else Layouts.effects(pc, lo, ctx, basic)
            val fx = ArrayList<Effect>()
            val audioFx = ArrayList<AudioProcessor>()
            if (pc.speed != 1.0) {
                fx.add(SpeedChangeEffect(pc.speed.toFloat()))
                val sonic = SonicAudioProcessor()
                sonic.setSpeed(pc.speed.toFloat())
                sonic.setPitch(1f)
                audioFx.add(sonic)
            }
            fx.addAll(lay.effects)
            if (refine && !simple) fx.addAll(RefineFx.effects(pc))
            if (music != null && origGain > 0f) audioFx.add(gainProcessor(origGain))
            val overlays = ArrayList<TextureOverlay>()
            if (refine && !simple && (pc.style == 2 || pc.style == 6 || pc.style == 7)) overlays.add(FlashOverlay(0.16f))
            if (o.withCaps) {
                val dur = Planner.outDuration(pc)
                val caps = if (lyrics != null) lyricCapsFor(lyrics, lyricsBase, outT, dur) else capsFor(pc, plan.caps)
                if (caps.isNotEmpty()) overlays.add(if (lyrics != null) KineticOverlay(caps, -0.12f) else CaptionOverlay(caps, lay.captionY, false))
            }
            if (o.title && idx == 0 && plan.title.isNotBlank()) {
                overlays.add(KineticOverlay(listOf(Cap(0.0, 2.5, plan.title)), 0.62f, Color.WHITE, 100f))
            }
            if (overlays.isNotEmpty()) fx.add(OverlayEffect(ImmutableList.copyOf(overlays)))
            val clipping = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs((pc.start * 1000).toLong())
                .setEndPositionMs((pc.end * 1000).toLong())
                .build()
            val mi = MediaItem.Builder().setUri(src).setClippingConfiguration(clipping).build()
            items.add(
                EditedMediaItem.Builder(mi)
                    .setEffects(Effects(audioFx, fx))
                    .setRemoveAudio(music != null && origGain == 0f)
                    .build()
            )
            outT += Planner.outDuration(pc)
        }
        val sequences = ArrayList<EditedMediaItemSequence>()
        sequences.add(EditedMediaItemSequence(items))
        if (music != null) {
            val total = pieces.sumOf { Planner.outDuration(it) }
            val musicMs = (durationOf(music) * 1000).toLong()
            val startMs = (musicStart * 1000).toLong()
            val endMs = minOf(musicMs, startMs + (total * 1000).toLong() + 500)
            if (endMs - startMs > 1000) {
                val mc = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build()
                val mm = MediaItem.Builder().setUri(music).setClippingConfiguration(mc).build()
                val mAudio = if (musicGain != 1f) listOf<AudioProcessor>(gainProcessor(musicGain)) else emptyList<AudioProcessor>()
                val musicItem = EditedMediaItem.Builder(mm)
                    .setRemoveVideo(true)
                    .setEffects(Effects(mAudio, emptyList<Effect>()))
                    .build()
                sequences.add(EditedMediaItemSequence(listOf(musicItem), true))
            }
        }
        val composition = Composition.Builder(sequences).build()
        return exportBlocking(composition, out.path) { b ->
            b.setVideoMimeType(MimeTypes.VIDEO_H264)
            b.setAudioMimeType(MimeTypes.AUDIO_AAC)
            b.setEncoderFactory(
                DefaultEncoderFactory.Builder(this)
                    .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(6_000_000).build())
                    .setEnableFallback(true)
                    .build()
            )
        }
    }

    /** Small 360p copy of the video so Gemini can watch it cheaply. */
    private fun makeProxy(src: Uri, out: File): String? {
        val fx = ArrayList<Effect>()
        fx.add(Presentation.createForHeight(360))
        val edited = EditedMediaItem.Builder(MediaItem.fromUri(src))
            .setEffects(Effects(emptyList<AudioProcessor>(), fx))
            .build()
        val composition = Composition.Builder(listOf(EditedMediaItemSequence(listOf(edited)))).build()
        return exportBlocking(composition, out.path) { b ->
            b.setVideoMimeType(MimeTypes.VIDEO_H264)
            b.setAudioMimeType(MimeTypes.AUDIO_AAC)
            b.setEncoderFactory(
                DefaultEncoderFactory.Builder(this)
                    .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(500_000).build())
                    .setEnableFallback(true)
                    .build()
            )
        }
    }

    private fun exportBlocking(
        composition: Composition,
        outPath: String,
        configure: (Transformer.Builder) -> Unit
    ): String? {
        val latch = CountDownLatch(1)
        var error: String? = null
        runOnUiThread {
            try {
                val b = Transformer.Builder(this)
                configure(b)
                b.addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        latch.countDown()
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        error = exportException.message ?: exportException.errorCodeName
                        latch.countDown()
                    }
                })
                b.build().start(composition, outPath)
            } catch (e: Exception) {
                error = e.message ?: e.toString()
                latch.countDown()
            }
        }
        latch.await()
        return error
    }

    private fun extractWav(src: Uri, out: File, durationSec: Double): FloatArray =
        AudioTools.extractWav(this, src, out, durationSec) { log(it) }

    private fun addResult(title: String, uri: Uri, postText: String) {
        runOnUiThread {
            resultsCard.visibility = View.VISIBLE
            val b = ghostButton("Play: $title")
            b.setOnClickListener {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(uri, "video/mp4")
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                try {
                    startActivity(i)
                } catch (e: Exception) {
                    Toast.makeText(this, "Open the gallery: Movies/DiracClip", Toast.LENGTH_LONG).show()
                }
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(8)
            resultsCard.addView(b, lp)
            if (postText.isNotBlank()) {
                val tv = muted(postText, 12f)
                tv.setTextIsSelectable(true)
                resultsCard.addView(tv)
                val cp = ghostButton("Copy caption")
                cp.setOnClickListener {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("caption", postText))
                    Toast.makeText(this, "Caption copied", Toast.LENGTH_SHORT).show()
                }
                val lp2 = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp2.bottomMargin = dp(12)
                resultsCard.addView(cp, lp2)
            }
        }
    }

    private fun durationOf(uri: Uri): Double {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, uri)
            val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            return ms / 1000.0
        } finally {
            r.release()
        }
    }

    private fun saveToGallery(file: File, name: String): Uri? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues()
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                values.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/DiracClip")
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { o ->
                        file.inputStream().use { it.copyTo(o) }
                    }
                }
                uri
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                dir?.mkdirs()
                val f = File(dir, name)
                file.copyTo(f, true)
                Uri.fromFile(f)
            }
        } catch (e: Exception) {
            log("Save error: ${e.message}")
            null
        }
    }
}
