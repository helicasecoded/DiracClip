package com.diracclip.app

object Planner {
    const val HOP = 0.02 // seconds per energy frame (320 samples @16kHz)

    private fun silenceThreshold(energy: FloatArray): Float {
        if (energy.isEmpty()) return 0f
        val sorted = energy.copyOf()
        sorted.sort()
        val p10 = sorted[(sorted.size * 0.10).toInt().coerceIn(0, sorted.size - 1)]
        return minOf(maxOf(p10 * 3f, 120f), 700f)
    }

    private fun snapMin(t: Double, window: Double, energy: FloatArray): Double {
        if (energy.isEmpty()) return t
        val i0 = maxOf(0, ((t - window) / HOP).toInt())
        val i1 = minOf(energy.size - 1, ((t + window) / HOP).toInt())
        if (i1 < i0) return t
        var best = i0
        for (i in i0..i1) if (energy[i] < energy[best]) best = i
        return best * HOP + HOP / 2
    }

    private fun energyAt(t: Double, energy: FloatArray): Float {
        val i = (t / HOP).toInt()
        return if (i in energy.indices) energy[i] else Float.MAX_VALUE
    }

    private fun subtract(base: List<Pair<Double, Double>>, cuts: List<Pair<Double, Double>>): List<Pair<Double, Double>> {
        var cur = base
        for (c in cuts.sortedBy { it.first }) {
            val next = ArrayList<Pair<Double, Double>>()
            for (b in cur) {
                if (c.second <= b.first || c.first >= b.second) {
                    next.add(b)
                } else {
                    if (c.first - b.first > 0.05) next.add(Pair(b.first, c.first))
                    if (b.second - c.second > 0.05) next.add(Pair(c.second, b.second))
                }
            }
            cur = next
        }
        return cur
    }

    /** Timestamps (seconds) of the loudest moments (gunfights, explosions, shouting). */
    fun loudMoments(energy: FloatArray, count: Int): List<Int> {
        val win = 50 // 1 second
        val n = energy.size / win
        if (n < 3) return emptyList()
        val avg = FloatArray(n)
        for (i in 0 until n) {
            var s = 0f
            for (k in 0 until win) s += energy[i * win + k]
            avg[i] = s / win
        }
        val order = (0 until n).sortedByDescending { avg[it] }
        val picked = ArrayList<Int>()
        for (i in order) {
            if (picked.size >= count) break
            if (picked.none { Math.abs(it - i) < 10 }) picked.add(i)
        }
        return picked.sorted()
    }

    /** Turns a plan into the final list of source pieces (jump cuts, with pauses/fillers removed). */
    fun buildPieces(plan: ClipPlan, energy: FloatArray, trim: Boolean): List<Piece> {
        val thr = silenceThreshold(energy)
        val cutList = ArrayList<Pair<Double, Double>>()

        if (trim && energy.isNotEmpty()) {
            // 1) filler cuts from the AI, snapped to quiet points so words are not chopped
            for (c in plan.cuts) {
                val cs = snapMin(c.start, 0.15, energy)
                val ce = snapMin(c.end, 0.15, energy)
                val len = ce - cs
                if (len < 0.15 || len > 1.6) continue
                if (energyAt(cs, energy) > thr * 2f || energyAt(ce, energy) > thr * 2f) continue
                cutList.add(Pair(cs, ce))
            }
            // 2) long silent pauses inside every segment
            for (s in plan.segs) {
                val i0 = maxOf(0, (s.start / HOP).toInt())
                val i1 = minOf(energy.size, (s.end / HOP).toInt())
                var i = i0
                while (i < i1) {
                    if (energy[i] < thr) {
                        var j = i
                        while (j < i1 && energy[j] < thr) j++
                        val len = (j - i) * HOP
                        if (len >= 0.6) cutList.add(Pair(i * HOP + 0.18, j * HOP - 0.18))
                        i = j
                    } else {
                        i++
                    }
                }
            }
        }

        val out = ArrayList<Piece>()
        for (s in plan.segs) {
            val parts = subtract(listOf(Pair(s.start, s.end)), cutList)
            for (p in parts.sortedBy { it.first }) {
                if (p.second - p.first >= 0.4) out.add(Piece(p.first, p.second, s.speaker))
            }
        }
        return out
    }
}
