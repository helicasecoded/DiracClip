package com.diracclip.app

object Planner {
    const val HOP = 0.02 // seconds per energy frame (320 samples @16kHz)

    private fun silenceThreshold(energy: FloatArray): Float {
        if (energy.isEmpty()) return 0f
        val sorted = energy.copyOf()
        sorted.sort()
        val p10 = sorted[(sorted.size * 0.10).toInt().coerceIn(0, sorted.size - 1)]
        return minOf(maxOf(p10 * 3f, 120f), 700f)
    }

    private fun snapMin(t: Double, window: Double, energy: FloatArray): Double {
        if (energy.isEmpty()) return t
        val i0 = maxOf(0, ((t - window) / HOP).toInt())
        val i1 = minOf(energy.size - 1, ((t + window) / HOP).toInt())
        if (i1 < i0) return t
        var best = i0
        for (i in i0..i1) if (energy[i] < energy[best]) best = i
        return best * HOP + HOP / 2
    }

    private fun energyAt(t: Double, energy: FloatArray): Float {
        val i = (t / HOP).toInt()
        return if (i in energy.indices) energy[i] else Float.MAX_VALUE
    }

    private fun subtract(base: List<Pair<Double, Double>>, cuts: List<Pair<Double, Double>>): List<Pair<Double, Double>> {
        var cur = base
        for (c in cuts.sortedBy { it.first }) {
            val next = ArrayList<Pair<Double, Double>>()
            for (b in cur) {
                if (c.second <= b.first || c.first >= b.second) {
                    next.add(b)
                } else {
                    if (c.first - b.first > 0.05) next.add(Pair(b.first, c.first))
                    if (b.second - c.second > 0.05) next.add(Pair(c.second, b.second))
                }
            }
            cur = next
        }
        return cur
    }

    /** Timestamps (seconds) of the loudest moments, loudest first. */
    fun loudMoments(energy: FloatArray, count: Int): List<Int> = loudRanked(energy, count).sorted()

    fun loudRanked(energy: FloatArray, count: Int): List<Int> {
        val win = 50 // 1 second
        val n = energy.size / win
        if (n < 3) return emptyList()
        val avg = FloatArray(n)
        for (i in 0 until n) {
            var s = 0f
            for (k in 0 until win) s += energy[i * win + k]
            avg[i] = s / win
        }
        val order = (0 until n).sortedByDescending { avg[it] }
        val picked = ArrayList<Int>()
        for (i in order) {
            if (picked.size >= count) break
            if (picked.none { Math.abs(it - i) < 10 }) picked.add(i)
        }
        return picked
    }

    /** No-AI fallback: clips around the loudest moments. */
    fun fallbackPlans(energy: FloatArray, durationSec: Double, o: Options): List<ClipPlan> {
        val len = ((o.minSec + o.maxSec) / 2.0).coerceAtMost(durationSec)
        val used = ArrayList<Pair<Double, Double>>()
        val plans = ArrayList<ClipPlan>()
        for (t in loudRanked(energy, o.count * 4)) {
            if (plans.size >= o.count) break
            val e0 = minOf(durationSec, maxOf(0.0, t - len * 0.4) + len)
            val s0 = maxOf(0.0, e0 - len)
            if (used.any { s0 < it.second && e0 > it.first }) continue
            used.add(Pair(s0, e0))
            plans.add(ClipPlan("Highlight ${plans.size + 1}", 6.0, "Loud moment (no-AI fallback)", listOf(Seg(s0, e0, "NONE")), emptyList(), emptyList(), listOf(t.toDouble())))
        }
        return plans
    }

    fun outDuration(p: Piece): Double = (p.end - p.start) / p.speed

    /** Splits pieces so that the most impressive instants play at half speed. */
    fun applySlowmo(pieces: List<Piece>, times: List<Double>, energy: FloatArray): List<Piece> {
        var cur = pieces
        for (raw in times.take(2)) {
            // snap to the loudest instant (the gunshot / hit) within +-1 s
            var t = raw
            if (energy.isNotEmpty()) {
                val i0 = maxOf(0, ((raw - 1.0) / HOP).toInt())
                val i1 = minOf(energy.size - 1, ((raw + 1.0) / HOP).toInt())
                if (i1 > i0) {
                    var best = i0
                    for (i in i0..i1) if (energy[i] > energy[best]) best = i
                    t = best * HOP
                }
            }
            val next = ArrayList<Piece>()
            for (p in cur) {
                if (p.speed == 1.0 && t - 0.5 >= p.start + 0.4 && t + 0.9 <= p.end - 0.4) {
                    next.add(Piece(p.start, t - 0.5, p.speaker, 1.0))
                    next.add(Piece(t - 0.5, t + 0.9, p.speaker, 0.5))
                    next.add(Piece(t + 0.9, p.end, p.speaker, 1.0))
                } else {
                    next.add(p)
                }
            }
            cur = next
        }
        return cur
    }

    /** Turns a plan into the final list of source pieces (jump cuts, with pauses/fillers removed). */
    fun buildPieces(plan: ClipPlan, energy: FloatArray, trim: Boolean): List<Piece> {
        val thr = silenceThreshold(energy)
        val cutList = ArrayList<Pair<Double, Double>>()

        if (trim && energy.isNotEmpty()) {
            // 1) filler cuts from the AI, snapped to quiet points so words are not chopped
            for (c in plan.cuts) {
                val cs = snapMin(c.start, 0.15, energy)
                val ce = snapMin(c.end, 0.15, energy)
                val len = ce - cs
                if (len < 0.15 || len > 1.6) continue
                if (energyAt(cs, energy) > thr * 2f || energyAt(ce, energy) > thr * 2f) continue
                cutList.add(Pair(cs, ce))
            }
            // 2) long silent pauses inside every segment
            for (s in plan.segs) {
                val i0 = maxOf(0, (s.start / HOP).toInt())
                val i1 = minOf(energy.size, (s.end / HOP).toInt())
                var i = i0
                while (i < i1) {
                    if (energy[i] < thr) {
                        var j = i
                        while (j < i1 && energy[j] < thr) j++
                        val len = (j - i) * HOP
                        if (len >= 0.6) cutList.add(Pair(i * HOP + 0.18, j * HOP - 0.18))
                        i = j
                    } else {
                        i++
                    }
                }
            }
        }

        val out = ArrayList<Piece>()
        for (s in plan.segs) {
            val parts = subtract(listOf(Pair(s.start, s.end)), cutList)
            for (p in parts.sortedBy { it.first }) {
                if (p.second - p.first >= 0.4) out.add(Piece(p.first, p.second, s.speaker))
            }
        }
        return out
    }

    /** One caption per word. Very short words are merged and every word stays on screen long enough to read. */
    fun tidyWords(ws: List<Cap>): List<Cap> {
        val s = ws.sortedBy { it.start }
        val out = ArrayList<Cap>()
        var i = 0
        while (i < s.size) {
            var c = s[i]
            if (c.end - c.start < 0.15 && i + 1 < s.size && s[i + 1].start - c.end < 0.3) {
                c = Cap(c.start, s[i + 1].end, c.text + " " + s[i + 1].text)
                i++
            }
            val next = if (i + 1 < s.size) s[i + 1].start else Double.MAX_VALUE
            val end = minOf(maxOf(c.end, c.start + 0.3), next)
            out.add(Cap(c.start, maxOf(end, c.start + 0.12), c.text))
            i++
        }
        return out
    }

    /** Fallback when no word timestamps exist: spread the words of each line evenly. */
    fun evenWords(lines: List<Cap>): List<Cap> {
        val r = ArrayList<Cap>()
        for (c in lines) {
            val ws = c.text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            if (ws.isEmpty()) continue
            val per = (c.end - c.start) / ws.size
            for ((i, w) in ws.withIndex()) r.add(Cap(c.start + i * per, c.start + (i + 1) * per, w))
        }
        return r
    }

    private fun tokens(t: String): Set<String> =
        t.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length > 2 }.toSet()

    /**
     * Makes the song sections usable: snaps them to lyric lines, keeps the length in range, removes
     * overlaps and repeated lyrics (e.g. the same chorus twice) and adds more sections from lyric
     * density + loudness if the AI gave too few.
     */
    fun fixSections(
        ai: List<Shot>, lines: List<Cap>, words: List<Cap>, energy: FloatArray, durationSec: Double, o: Options
    ): List<Shot> {
        val minL = o.minSec.toDouble()
        val maxL = o.maxSec.toDouble()
        val need = o.count.coerceIn(1, 6)

        fun snap(s: Shot): Shot {
            var st = s.start
            var en = s.end
            val ls = lines.minByOrNull { Math.abs(it.start - st) }
            if (ls != null && Math.abs(ls.start - st) < 4.0) st = ls.start
            val le = lines.minByOrNull { Math.abs(it.end - en) }
            if (le != null && Math.abs(le.end - en) < 4.0) en = le.end
            if (en - st > maxL) en = st + maxL
            if (en - st < minL) en = st + minL
            en = minOf(en, durationSec)
            if (en - st < minL * 0.7) st = maxOf(0.0, en - minL)
            return Shot(st, en, s.score)
        }

        fun textOf(s: Shot): Set<String> =
            tokens(lines.filter { it.end > s.start && it.start < s.end }.joinToString(" ") { it.text })

        val out = ArrayList<Shot>()
        val outTok = ArrayList<Set<String>>()
        fun tryAdd(s0: Shot): Boolean {
            val s = snap(s0)
            if (s.end - s.start < 5.0) return false
            for (o2 in out) {
                val ov = minOf(s.end, o2.end) - maxOf(s.start, o2.start)
                if (ov > 0.25 * (s.end - s.start)) return false
            }
            val tk = textOf(s)
            for (t2 in outTok) {
                if (tk.isNotEmpty() && t2.isNotEmpty()) {
                    val inter = tk.intersect(t2).size.toDouble()
                    if (inter / minOf(tk.size, t2.size) > 0.6) return false
                }
            }
            out.add(s)
            outTok.add(tk)
            return true
        }

        for (s in ai.sortedByDescending { it.score }) {
            if (out.size >= need) break
            tryAdd(s)
        }

        if (out.size < need) {
            val len = ((minL + maxL) / 2.0).coerceAtMost(durationSec)
            val pre = DoubleArray(energy.size + 1)
            for (i in energy.indices) pre[i + 1] = pre[i] + energy[i]
            val cands = ArrayList<Shot>()
            var t = durationSec * 0.04
            while (t + len <= durationSec * 0.97) {
                val wc = words.count { it.start >= t && it.start < t + len } + lines.count { it.start >= t && it.start < t + len } * 2
                var e = 0.0
                if (energy.isNotEmpty()) {
                    val i0 = (t / HOP).toInt().coerceIn(0, energy.size)
                    val i1 = ((t + len) / HOP).toInt().coerceIn(i0, energy.size)
                    if (i1 > i0) e = (pre[i1] - pre[i0]) / (i1 - i0)
                }
                cands.add(Shot(t, t + len, wc.toDouble() / len + e / 1500.0))
                t += 4.0
            }
            for (c in cands.sortedByDescending { it.score }) {
                if (out.size >= need) break
                tryAdd(c)
            }
        }
        return out
    }
}
