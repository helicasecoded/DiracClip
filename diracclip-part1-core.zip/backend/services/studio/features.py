"""Feature-flag snapshot for one generation.

The desktop client sends the resolved snapshot with an import. CLI, MCP and
Docker have no PostHog SDK: they read AUTOCLIP_FLAGS, then these defaults.
Unknown keys and values are dropped. autoclip_safe_mode forces every other
flag back to its safe off value unless AUTOCLIP_FLAGS sets that flag explicitly.
qa_gate_blocking is the exception: safe mode always forces it to off.
"""
from __future__ import annotations

import os

# Keep in lockstep with frontend/src/analytics/flags.defaults.json.
DEFAULTS: dict[str, bool | str] = {
    'autoclip_safe_mode': False,
    'remember_platforms': False,
    'one_click_paste_start': 'button',
    'link_import_without_whisper': False,
    'notify_on_done': False,
    'publish_pack_v2': 'separate',
    'render_top_first': 'limit10',
    'clip_reasons': False,
    'hide_legacy_entrypoints': False,
    'import_drop_zone': False,
    'track_overrides': False,
    # Plan §10.2 starts this gate at full shadow. block is accepted and not enforced.
    'qa_gate_blocking': 'shadow',
    # 1.5.7: editing styles and the visual picker ship on. Remote PostHog, a
    # local override or AUTOCLIP_FLAGS=...=off still turn them off; safe mode
    # forces them off.
    'pkg_templates_v1': True,
    'pkg_template_picker_visual': True,
    'mcp_v2_tools': True,
}

# Safe mode value when it differs from the build default (default-on features).
SAFE_OFF: dict[str, bool | str] = {
    'qa_gate_blocking': 'off',
    'pkg_templates_v1': False,
    'pkg_template_picker_visual': False,
    'mcp_v2_tools': False,
}


def safe_off(key: str) -> bool | str:
    return SAFE_OFF.get(key, DEFAULTS[key])

VARIANTS = {
    'one_click_paste_start': ('button', 'autostart'),
    'publish_pack_v2': ('separate', 'combined'),
    'render_top_first': ('limit10', 'top3'),
    'qa_gate_blocking': ('off', 'shadow', 'block'),
}


def normalize_flag(name: str, raw: object) -> bool | str | None:
    if name not in DEFAULTS:
        return None
    if name == 'qa_gate_blocking' and raw == 'blocking':
        raw = 'block'
    if name in VARIANTS:
        return raw if isinstance(raw, str) and raw in VARIANTS[name] else None
    if raw is True or raw in ('true', 'on', '1', 1):
        return True
    if raw is False or raw in ('false', 'off', '0', 0):
        return False
    return None


def parse_flag_list(raw: str | None) -> dict[str, bool | str]:
    found: dict[str, bool | str] = {}
    for part in (raw or '').split(','):
        if '=' not in part:
            continue
        key, value = part.split('=', 1)
        normalized = normalize_flag(key.strip(), value.strip())
        if normalized is not None:
            found[key.strip()] = normalized
    return found


def resolve_features(snapshot: dict | None = None, env: str | None = None) -> dict[str, bool | str]:
    """Defaults, then the client snapshot, then safe mode, then AUTOCLIP_FLAGS."""
    if env is None:
        env = os.environ.get('AUTOCLIP_FLAGS', '')
    operator = parse_flag_list(env)
    resolved = dict(DEFAULTS)
    if isinstance(snapshot, dict):
        for key, value in snapshot.items():
            normalized = normalize_flag(str(key), value)
            if normalized is not None:
                resolved[str(key)] = normalized
    if resolved.get('autoclip_safe_mode') is True:
        for key in DEFAULTS:
            if key != 'autoclip_safe_mode':
                resolved[key] = safe_off(key)
    resolved.update(operator)
    if resolved.get('autoclip_safe_mode') is True:
        for key in DEFAULTS:
            if key != 'autoclip_safe_mode' and key not in operator:
                resolved[key] = safe_off(key)
        # The kill switch wins even when AUTOCLIP_FLAGS names this gate.
        resolved['qa_gate_blocking'] = 'off'
    return resolved


def flag_enabled(features: dict | None, name: str) -> bool:
    """True only for the treatment. Missing flags stay off."""
    value = (features or {}).get(name, DEFAULTS.get(name))
    if name in VARIANTS:
        treatments = {'one_click_paste_start': 'autostart', 'publish_pack_v2': 'combined', 'render_top_first': 'top3', 'qa_gate_blocking': 'block'}
        return value == treatments[name]
    return value is True
