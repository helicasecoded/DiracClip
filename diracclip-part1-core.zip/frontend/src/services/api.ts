import { projectProperties } from '../analytics/workflow'
import { t } from '../i18n'
import axios, { type AxiosRequestConfig } from 'axios'
import { Project, Clip, Collection } from '../store/useProjectStore'
import { errorHandler } from '../utils/errorHandler'
import { apiConfigManager } from '../utils/apiConfig'
import { observeOperation, observeDownload, observeMediaResponse } from '../analytics/operations'
import { workflow } from '../analytics/observer'
import { captureBusinessEvent } from '../analytics/posthog'
import {
  trackVideoImported,
  trackClipsExported,
  trackProcessingFailed,
} from '../analytics/events'

// 扩展Axios配置类型
declare module 'axios' {
  interface AxiosRequestConfig {
    /* false = a single attempt (the caller polls on its own, e.g. the readiness probe). */
    retry?: boolean
  }
  interface InternalAxiosRequestConfig {
    metadata?: {
      startTime: number
      retryCount?: number
    }
  }
}

// 格式化时间函数（暂时未使用，保留备用）

const api = axios.create({
  baseURL: apiConfigManager.getBaseUrl(),
  timeout: 300000, // 增加到5分钟超时
  headers: {
    'Content-Type': 'application/json',
  },
})

const RETRYABLE_METHODS = new Set(['get', 'head', 'options'])
const RETRYABLE_STATUS_CODES = new Set([408, 429, 500, 502, 503, 504])
const MAX_RETRIES = 2

const shouldRetry = (error: any): boolean => {
  if (error?.config?.retry === false || axios.isCancel(error)) return false
  const method = error?.config?.method?.toLowerCase()
  if (!method || !RETRYABLE_METHODS.has(method)) return false

  const status = error?.response?.status
  if (status && RETRYABLE_STATUS_CODES.has(status)) return true

  const code = error?.code
  return code === 'ECONNABORTED' || !error?.response
}

const getRetryDelay = (retryCount: number): number => 300 * Math.pow(2, retryCount)

/* the wait before a retry ends at once when the request's signal aborts; nothing more is sent. */
const waitForRetry = (ms: number, config: any) => new Promise<void>((resolve, reject) => {
  const signal: AbortSignal | undefined = config?.signal
  const cancelled = () => new axios.CanceledError(undefined, config)
  if (signal?.aborted) { reject(cancelled()); return }
  const onAbort = () => { clearTimeout(timer); reject(cancelled()) }
  const timer = setTimeout(() => { signal?.removeEventListener?.('abort', onAbort); resolve() }, ms)
  signal?.addEventListener?.('abort', onAbort, { once: true })
})

apiConfigManager.addListener((config) => {
  api.defaults.baseURL = config.baseUrl
})

const isTauriRuntime = () => (
  typeof window !== 'undefined' &&
  ((window as any).__TAURI__ || (window as any).__TAURI_INTERNALS__)
)

// 打包后的桌面页在 tauri://localhost（macOS）或 http://tauri.localhost。
// 根路径 /api/v1 会打到壳页面，打不到本机后端。开发时 base 仍是 /api/v1，走 Vite 代理。
const mediaUrl = (path: string): string => {
  const base = apiConfigManager.getBaseUrl().replace(/\/$/, '')
  return `${base}${path.startsWith('/') ? path : `/${path}`}`
}

const resolveMediaUrl = async (path: string): Promise<string> => {
  if (isTauriRuntime() && !apiConfigManager.isReady()) {
    await apiConfigManager.waitForReady()
  }
  return mediaUrl(path)
}

const saveWithSystemDownload = async (
  url: string,
  properties: { project_id: string; artifact_type: string; export_id?: string },
) => {
  const saved = await observeOperation('media_download', properties, async () => {
    const { invoke } = await import('@tauri-apps/api/core')
    const result = await invoke<{ path: string; sizeBytes?: number; size_bytes?: number }>('save_local_download', { url })
    const size = result?.sizeBytes ?? result?.size_bytes ?? 0
    if (!size) throw new Error('Empty media response')
    return { ...result, size }
  }, (result, _startedAt, props) => {
    captureBusinessEvent('media_download_received', { ...props, size_bytes: result.size, legacy: true })
    captureBusinessEvent('media_download_saved', { ...props, download_mode: 'native', size_bytes: result.size, legacy: true })
  })
  const { message } = await import('antd')
  message.success(t('已保存到下载文件夹'))
  return saved
}

const saveBlobDownload = (data: Blob, filename: string) => {
  const downloadUrl = window.URL.createObjectURL(new Blob([data], { type: 'video/mp4' }))
  const link = document.createElement('a')
  link.href = downloadUrl
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  window.URL.revokeObjectURL(downloadUrl)
}

const filenameFromDisposition = (contentDisposition: string | undefined, fallback: string): string => {
  if (!contentDisposition) return fallback
  const filenameStarMatch = contentDisposition.match(/filename\*=UTF-8''([^;]+)/)
  if (filenameStarMatch) return decodeURIComponent(filenameStarMatch[1])
  const filenameMatch = contentDisposition.match(/filename="([^"]+)"/)
  return filenameMatch ? filenameMatch[1] : fallback
}

// 请求拦截器
api.interceptors.request.use(
  async (config) => {
    if (isTauriRuntime() && !apiConfigManager.isReady()) {
      // a cancelled request stops waiting for the desktop backend config at once.
      await apiConfigManager.waitForReady(undefined, config.signal as AbortSignal | undefined)
      if (config.signal?.aborted) throw new axios.CanceledError(undefined, undefined, config)
    }

    config.baseURL = apiConfigManager.getBaseUrl()
    // Refresh timing while preserving the retry budget across api.request(config).
    config.metadata = { ...config.metadata, startTime: Date.now() }
    return config
  },
  (error) => {
    errorHandler.handleError(error, 'RequestInterceptor')
    return Promise.reject(error)
  }
)

// 响应拦截器
api.interceptors.response.use(
  (response) => {
    // 记录请求耗时
    if (response.config.metadata?.startTime) {
      const duration = Date.now() - response.config.metadata.startTime
      if (duration > 5000) { // 超过5秒的请求
        console.warn(`Slow API request: ${response.config.url} took ${duration}ms`)
      }
    }
    
    return response.data
  },
  async (error) => {
    if (shouldRetry(error)) {
      const currentRetryCount = error.config?.metadata?.retryCount || 0
      if (currentRetryCount < MAX_RETRIES) {
        error.config.metadata = {
          ...(error.config.metadata || { startTime: Date.now() }),
          retryCount: currentRetryCount + 1,
        }
        await waitForRetry(getRetryDelay(currentRetryCount), error.config)
        return api.request(error.config)
      }
    }

    // 使用统一的错误处理器
    errorHandler.handleError(error, 'API')
    
    // 保持原有的错误对象结构，确保向后兼容
    if (error.response?.status === 429) {
      const message = error.response?.data?.detail || t("系统正在处理其他项目，请稍后再试")
      error.userMessage = message
    }
    else if (error.code === 'ECONNABORTED' || error.message?.includes('timeout')) {
      error.userMessage = t("请求超时，项目可能仍在后台处理中，请稍后查看项目状态")
    }
    else if (error.code === 'NETWORK_ERROR' || !error.response) {
      error.userMessage = t("网络连接失败，请检查网络连接")
    }
    else if (error.response?.status >= 500) {
      error.userMessage = t("服务器内部错误，请稍后重试")
    }
    
    return Promise.reject(error)
  }
)

export interface UploadFilesRequest {
  video_file: File
  srt_file?: File
  project_name: string
  video_category?: string
}

export interface VideoCategory {
  value: string
  name: string
  description: string
  icon: string
  color: string
}

export interface VideoCategoriesResponse {
  categories: VideoCategory[]
  default_category: string
}

export interface ProcessingStatus {
  status: 'processing' | 'completed' | 'error'
  current_step: number
  total_steps: number
  step_name: string
  progress: number
  error_message?: string
}

// B站相关接口类型
export interface BilibiliVideoInfo {
  title: string
  description: string
  duration: number
  uploader: string
  upload_date: string
  view_count: number
  like_count: number
  thumbnail: string
  url: string
}

export interface BilibiliDownloadRequest {
  url: string
  project_name: string
  video_category?: string
  browser?: string
}

export interface BilibiliDownloadTask {
  id: string
  url: string
  project_name: string
  video_category?: string
  browser?: string
  status: 'pending' | 'processing' | 'completed' | 'failed'
  progress: number
  error_message?: string
  video_info?: BilibiliVideoInfo
  project_id?: string
  created_at: string
  updated_at: string
}

// 设置相关API
export const settingsApi = {
  getOutputBranding: (): Promise<{ enabled: boolean }> => api.get('/settings/output-branding'),
  setOutputBranding: (enabled: boolean): Promise<{ enabled: boolean }> => api.put('/settings/output-branding', { enabled }),
  getOutputCaptions: (): Promise<{ enabled: boolean }> => api.get('/settings/output-captions'),
  setOutputCaptions: (enabled: boolean): Promise<{ enabled: boolean }> => api.put('/settings/output-captions', { enabled }),
  // 获取系统配置
  getSettings: (): Promise<any> => {
    return api.get('/settings')
  },

  // 更新系统配置
  updateSettings: (settings: any): Promise<any> => {
    return api.put('/settings/', settings)
  },

  // 测试API密钥
  testApiKey: (
    provider: string,
    apiKey: string,
    options: { baseUrl?: string; model?: string } = {}
  ): Promise<{ success: boolean; error?: string }> => {
    return observeOperation('provider_test', { provider }, () => api.post<unknown, { success: boolean; error?: string }>('/settings/test-api', {
      provider, 
      api_key: apiKey,
      base_url: options.baseUrl,
      model: options.model,
    }), (result) => { captureBusinessEvent('provider_test_finished', { provider, outcome: result.success ? 'success' : 'error', legacy: true }) })
  },

  // 云端提供商模型名单：内置常用 + 有密钥时实时拉取服务商 /models
  getAvailableModels: (
    params: { provider?: string; baseUrl?: string; apiKey?: string; refresh?: boolean } = {}
  ): Promise<{
    provider: string
    source: 'catalog' | 'live'
    reachable: boolean
    default_model: string
    models: string[]
    catalog: Record<string, string[]>
    vision_models?: string[]
    image_models?: string[]
    error?: string
  }> => {
    return api.get('/settings/available-models', {
      params: {
        provider: params.provider,
        base_url: params.baseUrl,
        api_key: params.apiKey,
        refresh: params.refresh ? true : undefined,
      },
    })
  },

  // 获取当前提供商信息
  getCurrentProvider: (): Promise<any> => {
    return api.get('/settings/current-provider')
  },

  // 本地 OpenAI 兼容服务（Ollama / LM Studio / vLLM）实际提供的模型列表
  listCompatibleModels: (
    params: { provider?: string; baseUrl?: string; apiKey?: string }
  ): Promise<{ reachable: boolean; base_url: string; models: string[]; error?: string }> => {
    return api.get('/settings/compatible-models', {
      params: { provider: params.provider, base_url: params.baseUrl, api_key: params.apiKey },
    })
  },

  // 检查桌面模式
  checkDesktopMode: (): Promise<{ is_desktop_mode: boolean; environment: any }> => {
    return api.get('/settings/desktop-mode')
  },

  getPrivacy: (): Promise<{ crash_reports: boolean }> => {
    return api.get('/settings/privacy')
  },

  updatePrivacy: (privacy: { crash_reports: boolean }): Promise<{ crash_reports: boolean }> => {
    return api.put('/settings/privacy', privacy)
  },
}

// 项目相关API
/** Bundled project with real media; creating it does not require a model key. */
export const exampleProjectApi = {
  info: () => api.get<unknown, { available: boolean; project_id: string | null }>('/example-project'),
  create: () => api.post<unknown, { project_id: string; name: string; resolution: 'created' | 'reused'; example_version: number }>('/example-project/create'),
}

export const projectApi = {
  // 获取视频分类配置
  getVideoCategories: async (): Promise<VideoCategoriesResponse> => {
    return api.get('/video-categories')
  },

  // 获取所有项目
  getProjects: async (): Promise<Project[]> => {
    const response = await api.get('/projects/')
    // 处理分页响应结构，返回items数组
    const projects = (response as any).items || response || []
    if (Array.isArray(projects)) projects.forEach(p => workflow.rememberProject(p.id, projectProperties(p)))
    return projects
  },

  // 获取单个项目
  getProject: async (id: string): Promise<Project> => {
    const project = await api.get<unknown, Project>(`/projects/${id}`)
    workflow.rememberProject(id, projectProperties(project))
    return project
  },

  // 上传文件并创建项目
  uploadFiles: async (data: UploadFilesRequest): Promise<Project> => {
    const formData = new FormData()
    formData.append('video_file', data.video_file)
    if (data.srt_file) {
      formData.append('srt_file', data.srt_file)
    }
    formData.append('project_name', data.project_name)
    if (data.video_category) {
      formData.append('video_category', data.video_category)
    }
    
    try {
      const project = await observeOperation('import', { source_type: 'upload' }, () => api.post<unknown, Project>('/projects/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }), (created, startedAt, props) => {
        workflow.rememberProject(created.id, { material_origin: 'user' })
        workflow.watch('project', created.id, undefined, startedAt)
        captureBusinessEvent('import_finished', { ...props, project_id: created.id, outcome: 'success', stage: 'upload_received', legacy: true })
      })
      trackVideoImported({
        source: 'upload',
        fileType: data.video_file?.type || undefined,
        sizeBytes: data.video_file?.size,
      })
      return project
    } catch (error: any) {
      trackProcessingFailed({
        stage: 'import',
        message: error?.message,
        code: error?.response?.status,
      })
      throw error
    }
  },

  // 删除项目
  deleteProject: async (id: string): Promise<void> => {
    await api.delete(`/projects/${id}`)
  },

  // 开始处理项目
  startProcessing: async (id: string): Promise<void> => {
    await observeOperation('processing', { project_id: id, action: 'start' }, () => api.post(`/projects/${id}/process`),
      (_result, startedAt) => workflow.watch('project', id, undefined, startedAt))
  },

  // 重试处理项目
  retryProcessing: async (id: string): Promise<void> => {
    await observeOperation('processing', { project_id: id, action: 'retry' }, () => api.post(`/projects/${id}/retry`),
      (_result, startedAt) => workflow.watch('project', id, undefined, startedAt))
  },

  // 获取处理状态
  getProcessingStatus: async (id: string): Promise<ProcessingStatus> => {
    return api.get(`/projects/${id}/status`)
  },

  // 获取项目日志
  getProjectLogs: async (id: string, lines: number = 50): Promise<{logs: Array<{timestamp: string, module: string, level: string, message: string}>}> => {
    return api.get(`/projects/${id}/logs?lines=${lines}`)
  },

  // 获取项目切片
  getClips: async (projectId: string): Promise<any[]> => {
    try {
      // 只从数据库获取数据，不再回退到文件系统
      console.log('🔍 Calling clips API for project:', projectId)
      const response = await api.get(`/clips/?project_id=${projectId}`)
      console.log('📦 Raw API response:', response)
      const clips = (response as any).items || response || []
      console.log('📋 Extracted clips:', clips.length, 'clips found')
      
      // 转换后端数据格式为前端期望的格式
      const convertedClips = clips.map((clip: any) => {
        // 转换秒数为时间字符串格式
        const formatSecondsToTime = (seconds: number) => {
          const hours = Math.floor(seconds / 3600)
          const minutes = Math.floor((seconds % 3600) / 60)
          const secs = Math.floor(seconds % 60)
          return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
        }
        
        // 获取metadata中的内容
        const metadata = clip.clip_metadata || {}
        
        return {
          id: clip.id,
          title: clip.title,
          generated_title: clip.title,
          start_time: formatSecondsToTime(clip.start_time),
          end_time: formatSecondsToTime(clip.end_time),
          duration: clip.duration || 0,
          final_score: clip.score || 0,
          recommend_reason: metadata.recommend_reason || '',
          outline: metadata.outline || '',
          // 只使用metadata中的content，避免使用description（可能是转写文本）
          content: metadata.content || [],
          chunk_index: metadata.chunk_index || 0
        }
      })
      
      console.log('✅ Converted clips:', convertedClips.length, 'clips')
      console.log('📄 First clip sample:', convertedClips[0])
      return convertedClips
    } catch (error) {
      console.error('❌ Failed to get clips:', error)
      return []
    }
  },

  // 获取项目合集
  getCollections: async (projectId: string): Promise<any[]> => {
    try {
      // 只从数据库获取数据，不再回退到文件系统
      const response = await api.get(`/collections/?project_id=${projectId}`)
      const collections = (response as any).items || response || []
      
      // 转换后端数据格式为前端期望的格式
      return collections.map((collection: any) => ({
        id: collection.id,
        collection_title: collection.name || collection.collection_title || '',
        collection_summary: collection.description || collection.collection_summary || '',
        clip_ids: collection.clip_ids || collection.metadata?.clip_ids || [],
        collection_type: collection.collection_type || 'ai_recommended',
        created_at: collection.created_at,
        project_id: collection.project_id,
        thumbnail_path: collection.thumbnail_path
      }))
    } catch (error) {
      console.error('Failed to get collections:', error)
      return []
    }
  },

  // 重启指定步骤
  restartStep: async (id: string, step: number): Promise<void> => {
    await observeOperation('processing', { project_id: id, action: 'restart_step', step }, () => api.post(`/projects/${id}/restart-step`, { step }),
      (_result, startedAt) => workflow.watch('project', id, undefined, startedAt))
  },

  // 更新切片信息
  updateClip: (projectId: string, clipId: string, updates: Partial<Clip>): Promise<Clip> => {
    return api.patch(`/projects/${projectId}/clips/${clipId}`, updates)
  },

  // 更新切片标题
  updateClipTitle: async (clipId: string, title: string): Promise<any> => {
    return api.patch(`/clips/${clipId}/title`, { title })
  },

  // 生成切片标题
  generateClipTitle: async (clipId: string): Promise<{clip_id: string, generated_title: string, success: boolean}> => {
    return api.post(`/clips/${clipId}/generate-title`)
  },

  // 创建合集
  createCollection: (projectId: string, collectionData: { collection_title: string, collection_summary: string, clip_ids: string[] }): Promise<Collection> => {
    return api.post(`/collections/`, {
      project_id: projectId,
      name: collectionData.collection_title,
      description: collectionData.collection_summary,
      clip_ids: collectionData.clip_ids,
      collection_type: 'manual'
    })
  },

  // 更新合集信息
  updateCollection: (_projectId: string, collectionId: string, updates: Partial<Collection>): Promise<Collection> => {
    return api.put(`/collections/${collectionId}`, updates)
  },

  // 重新排序合集切片
  reorderCollectionClips: (projectId: string, collectionId: string, clipIds: string[]): Promise<Collection> => {
    return api.patch(`/projects/${projectId}/collections/${collectionId}/reorder`, clipIds)
  },

  // 删除合集
  deleteCollection: (_projectId: string, collectionId: string): Promise<{message: string, deleted_collection: string}> => {
    return api.delete(`/collections/${collectionId}`)
  },

  // 生成合集标题
  generateCollectionTitle: (collectionId: string): Promise<{collection_id: string, generated_title: string, success: boolean}> => {
    return api.post(`/collections/${collectionId}/generate-title`)
  },

  // 更新合集标题
  updateCollectionTitle: (collectionId: string, title: string): Promise<{collection_id: string, title: string, success: boolean}> => {
    return api.put(`/collections/${collectionId}/title`, { title })
  },

  // 下载切片视频
  downloadClip: (_projectId: string, clipId: string): Promise<Blob> => {
    return observeDownload({ project_id: _projectId, artifact_type: 'clip' }, () => api.get<unknown, Blob>(`/files/projects/${_projectId}/clips/${clipId}`, {
      responseType: 'blob'
    }))
  },

  // 下载合集视频
  downloadCollection: (projectId: string, collectionId: string): Promise<Blob> => {
    return observeDownload({ project_id: projectId, artifact_type: 'collection' }, () => api.get<unknown, Blob>(`/files/projects/${projectId}/collections/${collectionId}`, {
      responseType: 'blob'
    }))
  },

  // 导出元数据
  exportMetadata: (projectId: string): Promise<Blob> => {
    return api.get(`/projects/${projectId}/export`, {
      responseType: 'blob'
    })
  },

  // 生成合集视频
  generateCollectionVideo: (projectId: string, collectionId: string) => {
    return api.post(`/projects/${projectId}/collections/${collectionId}/generate`)
  },

  downloadVideo: async (projectId: string, clipId?: string, collectionId?: string) => {
    let path = `/projects/${projectId}/download`
    if (clipId) {
      path += `?clip_id=${encodeURIComponent(clipId)}`
    } else if (collectionId) {
      path += `?collection_id=${encodeURIComponent(collectionId)}`
    }

    try {
      const url = await resolveMediaUrl(path)
      // 桌面端 <a download> 在 macOS WKWebView 里会被取消，改由壳写入「下载」文件夹。
      if (isTauriRuntime()) {
        const saved = await saveWithSystemDownload(url, {
          project_id: projectId,
          artifact_type: clipId ? 'clip' : collectionId ? 'collection' : 'original',
        })
        trackClipsExported({
          clipCount: 1,
          exportType: clipId ? 'clip' : collectionId ? 'collection' : 'project',
        })
        return saved
      }

      // blob 响应不走 api 拦截器，否则拿不到 Content-Disposition。
      const response = await observeMediaResponse({ project_id: projectId, artifact_type: clipId ? 'clip' : collectionId ? 'collection' : 'original' }, () => axios.get<Blob>(url, {
        responseType: 'blob',
        headers: {
          'Accept': 'application/octet-stream'
        }
      }))

      const filename = filenameFromDisposition(
        response.headers['content-disposition'],
        clipId ? `clip_${clipId}.mp4` : collectionId ? `collection_${collectionId}.mp4` : `project_${projectId}.mp4`,
      )
      saveBlobDownload(response.data, filename)

      trackClipsExported({
        clipCount: 1,
        exportType: clipId ? 'clip' : collectionId ? 'collection' : 'project',
      })
      return response.data
    } catch (error: any) {
      console.error('下载失败:', error)
      trackProcessingFailed({
        stage: 'export',
        message: error?.message,
        code: error?.response?.status,
      })
      throw error
    }
  },

  // 获取项目文件URL
  getProjectFileUrl: (projectId: string, filename: string): string => {
    return `${api.defaults.baseURL}/projects/${projectId}/files/${filename}`
  },

  // 获取项目视频URL
  getProjectVideoUrl: (projectId: string): string => {
    return `${api.defaults.baseURL}/projects/${projectId}/video`
  },

  // 获取切片视频URL。必须带上桌面端已经解析出的后端地址，不能用根路径。
  getClipVideoUrl: (projectId: string, clipId: string, _clipTitle?: string): string => {
    return mediaUrl(`/projects/${projectId}/clips/${encodeURIComponent(clipId)}`)
  },

  // 获取合集视频URL
  getCollectionVideoUrl: (projectId: string, collectionId: string): string => {
    return mediaUrl(`/files/projects/${projectId}/collections/${encodeURIComponent(collectionId)}`)
  },

  // 生成项目缩略图
  generateThumbnail: async (projectId: string): Promise<{success: boolean, thumbnail: string, message: string}> => {
    return api.post(`/projects/${projectId}/generate-thumbnail`)
  },

  startClipExport: async (
    projectId: string,
    clipId: string,
    body: { preset: string; subtitles?: boolean; title_card?: boolean }
  ): Promise<{ ok: boolean; job_id: string; status: string }> => {
    return observeOperation('publish_export', { project_id: projectId, preset: body.preset, subtitles: body.subtitles, title_card: body.title_card },
      () => api.post<unknown, { ok: boolean; job_id: string; status: string }>(`/projects/${projectId}/clips/${clipId}/export`, body),
      (job, startedAt) => { if (job.ok) workflow.watch('export', job.job_id, projectId, startedAt) })
  },

  getExportJob: async (projectId: string, jobId: string, signal?: AbortSignal): Promise<{
    job_id: string
    status: 'queued' | 'running' | 'completed' | 'failed'
    percent?: number
    error?: string
    result?: { path: string; title?: string; width?: number; height?: number; warnings?: string[] }
  }> => {
    return api.get(`/projects/${projectId}/exports/${jobId}`, { signal })
  },

  downloadExport: async (projectId: string, jobId: string) => {
    const url = await resolveMediaUrl(`/projects/${projectId}/exports/${encodeURIComponent(jobId)}/download`)
    if (isTauriRuntime()) {
      await saveWithSystemDownload(url, { project_id: projectId, export_id: jobId, artifact_type: 'publish_clip' })
      return
    }
    const response = await observeMediaResponse({ project_id: projectId, export_id: jobId, artifact_type: 'publish_clip' }, () => axios.get<Blob>(url, {
      responseType: 'blob',
      headers: { Accept: 'application/octet-stream' },
    }))
    const filename = filenameFromDisposition(response.headers['content-disposition'], `export_${jobId.slice(0, 8)}.mp4`)
    saveBlobDownload(response.data, filename)
  },
}

// 视频下载相关API
export const bilibiliApi = {
  // 解析B站视频信息
  parseVideoInfo: async (url: string, browser?: string): Promise<{success: boolean, video_info: BilibiliVideoInfo}> => {
    const formData = new FormData()
    formData.append('url', url)
    if (browser) {
      formData.append('browser', browser)
    }
    return api.post('/bilibili/parse', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
  },

  // 解析YouTube视频信息
  parseYouTubeVideoInfo: async (url: string, browser?: string): Promise<{success: boolean, video_info: BilibiliVideoInfo}> => {
    const formData = new FormData()
    formData.append('url', url)
    if (browser) {
      formData.append('browser', browser)
    }
    return api.post('/youtube/parse', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
  },

  // 创建B站下载任务
  createDownloadTask: async (data: BilibiliDownloadRequest): Promise<BilibiliDownloadTask> => {
    const task = await observeOperation('import', { source_type: 'bilibili' }, () => api.post<unknown, BilibiliDownloadTask>('/bilibili/download', data),
      (created, startedAt) => workflow.watch('bilibili', created.id, undefined, startedAt))
    trackVideoImported({ source: 'url', fileType: 'bilibili' })
    return task
  },

  // 创建YouTube下载任务
  createYouTubeDownloadTask: async (data: BilibiliDownloadRequest): Promise<BilibiliDownloadTask> => {
    const task = await observeOperation('import', { source_type: 'youtube' }, () => api.post<unknown, BilibiliDownloadTask>('/youtube/download', data),
      (created, startedAt) => workflow.watch('youtube', created.id, undefined, startedAt))
    trackVideoImported({ source: 'url', fileType: 'youtube' })
    return task
  },

  // 获取下载任务状态
  getTaskStatus: async (taskId: string): Promise<BilibiliDownloadTask> => {
    return api.get(`/bilibili/tasks/${taskId}`)
  },

  // 获取YouTube下载任务状态
  getYouTubeTaskStatus: async (taskId: string): Promise<BilibiliDownloadTask> => {
    return api.get(`/youtube/tasks/${taskId}`)
  },

  // 获取所有下载任务
  getAllTasks: async (): Promise<BilibiliDownloadTask[]> => {
    return api.get('/bilibili/tasks')
  },

  // 获取所有YouTube下载任务
  getAllYouTubeTasks: async (): Promise<BilibiliDownloadTask[]> => {
    return api.get('/youtube/tasks')
  }
}

// 系统状态相关API
export const systemApi = {
  // 获取系统状态
  getSystemStatus: (): Promise<{
    current_processing_count: number
    max_concurrent_processing: number
    total_projects: number
    processing_projects: string[]
  }> => {
    return api.get('/system/status')
  }
}

export interface WhisperRuntimeStatus {
  status: 'unknown' | 'not_installed' | 'installing' | 'installed' | 'error'
  progress: number
  message: string
  error_code?: string
  log_tail?: string
  platform_supported: boolean
  packages: string[]
}

export interface WhisperModel {
  name: string
  size: string
  sizeBytes: number
  description: string
  accuracy: string
  speed: string
  status: 'available' | 'downloading' | 'downloaded' | 'error' | 'not_found'
  downloadProgress?: number | null
  localPath?: string | null
  errorMessage?: string | null
  /** stable code; UI translates by code (8 locales).*/
  errorCode?: 'whisper_download_failed' | string | null
  source?: 'huggingface' | 'hf-mirror' | 'custom' | null
}

/** 200 installed: already on disk. 202 downloading: started in the background; poll the model status. */
export interface WhisperModelDownload {
  status: 'installed' | 'downloading'
  model: string
  message: string
}

export type WhisperModelSource = 'auto' | 'huggingface' | 'hf-mirror'

// 语音识别 / Whisper 运行时与模型管理
export const speechApi = {
  getRuntimeStatus: (config?: AxiosRequestConfig): Promise<WhisperRuntimeStatus> => api.get('/whisper/runtime-status', config),
  installRuntime: (config?: AxiosRequestConfig): Promise<{ started: boolean; message: string }> => api.post('/whisper/install', undefined, config),
  uninstallRuntime: (): Promise<{ success: boolean; message: string }> => api.post('/whisper/uninstall'),
  getModels: (config?: AxiosRequestConfig): Promise<WhisperModel[]> => api.get('/whisper-models', config),
  downloadModel: (model: string, config?: AxiosRequestConfig): Promise<WhisperModelDownload> => api.post('/whisper-models/download', { model }, config),
  deleteModel: (model: string): Promise<unknown> => api.delete(`/whisper-models/${model}`),
  /** E3: where Whisper models download from. auto probes huggingface.co and switches to hf-mirror when blocked. */
  getModelSource: (): Promise<{ source: WhisperModelSource; effective: WhisperModelSource }> => api.get('/whisper/model-source'),
  setModelSource: (source: WhisperModelSource): Promise<{ source: WhisperModelSource }> => api.put('/whisper/model-source', { source }),
}

export default api
