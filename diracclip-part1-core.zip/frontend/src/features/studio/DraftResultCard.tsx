import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import StudioDownloadLink from './StudioDownloadLink'
import { useNavigate } from 'react-router-dom'
import { Btn, fmtDuration } from '../../ui'
import { studioApi } from './api'
import { Draft, RenderJob, draftDuration, languages } from './types'
import { draftExportState, ExportStatus } from './draftExportState'

const statusLabels: Record<ExportStatus, string> = {
  draft: '草稿 · 待导出', queued: '排队中', rendering: '正在导出',
  ready: '已导出 · 可下载', failed: '导出失败', updated: '已修改 · 需重新导出',
}

export default function DraftResultCard({ projectId, draft, jobs, onEdit, onExport, onHistory, allowExport = true }: {
  projectId: string; draft: Draft; jobs: RenderJob[]
  onEdit: () => void; onExport: () => void; onHistory: () => void; allowExport?: boolean
}) {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const state = draftExportState(draft, jobs)
  const label = t(statusLabels[state.status])
  const completed = state.completed
  const thumbnail = studioApi.thumbnail(projectId, draft.id, draft.revision, completed?.job_id)
  const [failedThumbnail, setFailedThumbnail] = useState('')
  return <article className="ac-card">
    <button className={`ac-card-thumb studio-thumb${completed ? " studio-thumb--exported" : ""}`} onClick={onEdit} aria-label={t('预览 {{title}}', { title: draft.title })}>
      {failedThumbnail === thumbnail ? <span className="studio-thumbnail-fallback">{t("缩略图暂不可用 · 点击查看")}</span> : <img key={thumbnail} src={thumbnail} alt="" loading="lazy" onError={() => setFailedThumbnail(thumbnail)} />}
      <span className="play">▷</span>
      <span className="ac-tag ac-tag--tl">{t(draft.origin==='visual-promo'?'推广成片':draft.origin==='visual-highlight'?'精彩高光':'成片草稿')}</span>
      <span className="ac-tag ac-tag--br">{fmtDuration(draftDuration(draft))}</span>
    </button>
    <div className="ac-card-body">
      <h2 className="ac-card-title">{draft.title}</h2>
      <div className={`studio-output-state studio-output-state--${state.status}`} role="status">
        {label}{state.active ? ` · ${state.active.percent ?? 0}%` : ''}
      </div>
      <p className="studio-output-hint">{completed ? t('当前 V{{revision}} 成片画面', { revision: draft.revision }) : t('原片缩略图 · 包装效果以导出为准')}</p>
      <div className="ac-card-desc">{draft.hook||draft.scenes[0].evidence||t('保留原声与完整事件')}</div>
      {state.status==='failed' && <p className="studio-output-hint studio-error">{state.failure?.error || t('请重试导出，原草稿已保留')}</p>}
      {state.status==='ready' && state.failure && <p className="studio-output-hint">{t('本版曾有导出失败，已完成文件仍可下载。')}</p>}
      {state.previous && !completed && <button className="studio-link studio-output-hint" onClick={onHistory}>{t('查看已导出的 V{{revision}} 旧版', { revision: state.previous.revision })}</button>}
      <div className="ac-card-foot">
        <span className="meta">{draft.language === 'source' ? t('原语言') : languages.find(l=>l.value===draft.language)?.label ?? draft.language} · V{draft.revision} · {t('{{count}} 段', { count: draft.scenes.length })}</span>
        <div className="ac-card-actions">
          <Btn variant="text" onClick={onEdit}>{t('预览与修改')}</Btn>
          {completed && <Btn variant="text" onClick={() => navigate(`/project/${projectId}/publish/studio-${completed.job_id}`)}>{t('发布')}</Btn>}
          {completed ? <StudioDownloadLink className="studio-link" projectId={projectId} jobId={completed.job_id}/>
            : state.active ? <Btn variant="text" onClick={onHistory}>{t('查看进度')}</Btn>
            : allowExport ? <Btn variant="text" onClick={onExport}>{t(state.status==='failed'?'重试导出':'导出成片')}</Btn> : null}
        </div>
      </div>
    </div>
  </article>
}
