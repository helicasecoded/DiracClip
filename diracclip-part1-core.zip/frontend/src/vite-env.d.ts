/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** PostHog project API key（公开 key，可打包进前端）。未配置则禁用埋点。 */
  readonly VITE_PUBLIC_POSTHOG_KEY?: string
  /** PostHog 实例地址，US: https://us.i.posthog.com，EU: https://eu.i.posthog.com */
  readonly VITE_PUBLIC_POSTHOG_HOST?: string
  /** Sentry DSN（公开客户端 DSN）。未配置则崩溃上报 no-op。 */
  readonly VITE_PUBLIC_SENTRY_DSN?: string
  /** 打包时注入的应用版本，给 Sentry release 用。 */
  readonly VITE_APP_VERSION?: string
  /** Dev-only flag overrides, `name=value` comma separated. Ignored in production builds. */
  readonly VITE_FLAGS?: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}

declare module '*.jpg' {
  const content: string
  export default content
}

declare module '*.jpeg' {
  const content: string
  export default content
}

declare module '*.png' {
  const content: string
  export default content
}

declare module '*.svg' {
  const content: string
  export default content
}

declare module '*.webm?url' {
  const src: string
  export default src
}

declare module '*.mp4?url' {
  const src: string
  export default src
}

declare module '*.svg?react' {
  import React from 'react'
  const ReactComponent: React.FunctionComponent<React.SVGProps<SVGSVGElement>>
  export default ReactComponent
}